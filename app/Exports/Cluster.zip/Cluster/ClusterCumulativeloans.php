<?php
namespace App\Exports\Cluster;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Carbon\Carbon;


class ClusterCumulativeloans implements WithHeadings, ShouldAutoSize, WithEvents, WithTitle, FromCollection, WithColumnFormatting, WithMapping
{

    public $curdate = '';
    public $counter = 1;
    public function __construct()
    {
        $this->curdate = Carbon::now()->format('d-m-Y');
    }

    public function collection()
    {
        $user = Auth::user();
        $session_data = Session::get('cluster_export_session');
        // prd($session_data);

        $query = "SELECT
        cli.*,
        cl.uin,
        ag.agency_name,
        fedp.name_of_federation,
        clp.*,
        SUM(CAST(cli. federation_poorest_category AS INT) +
            CAST(cli.external_poorest_category AS INT) +
            CAST(cli.vi_poorest_category AS INT)+
            CAST(cli.federation_poor_category AS INT) +
            CAST(cli.external_poor_category AS INT)+
            CAST(cli.vi_poor_category AS INT) +
            CAST(cli.federation_medium AS INT)+
            CAST(cli.external_medium AS INT) +
            CAST(cli.vi_medium AS INT)+
            CAST(cli.federation_rich AS INT) +
            CAST(cli.external_rich AS INT)+
            CAST(cli.vi_rich AS INT)
            )
            AS total_no_of_loan_disbursed,
            SUM(CAST(cli. federation_poorest_category_amount AS INT) +
            CAST(cli.external_poorest_category_amount AS INT) +
            CAST(cli.vi_poorest_category_amount AS INT)+
            CAST(cli.federation_poor_category_amount AS INT) +
            CAST(cli.external_poor_category_amount AS INT)+
            CAST(cli.vi_poor_category_amount AS INT) +
            CAST(cli.federation_medium_amount AS INT)+
            CAST(cli.external_medium_amount AS INT) +
            CAST(cli.vi_medium_amount AS INT)+
            CAST(cli.federation_rich_amount AS INT) +
            CAST(cli.external_rich_amount AS INT)+
            CAST(cli.vi_rich_amount AS INT)
            )
            AS total_no_of_loan_ammount_disbursed ,

            SUM(CAST(cli. federation_poorest_category AS INT) +
            CAST(cli.federation_poor_category AS INT) +
            CAST(cli.federation_medium AS INT) +
            CAST(cli.federation_rich AS INT) )as cluster_total_loan_disburesd,

            SUM(CAST(cli. federation_poorest_category_amount AS INT) +
            CAST(cli.federation_poor_category_amount AS INT) +
            CAST(cli.federation_medium_amount AS INT) +
            CAST(cli.federation_rich_amount AS INT) )as cluster_total_loan_amount_disburesd ,

            SUM(CAST(cli. external_poorest_category AS INT) +
            CAST(cli.external_poor_category AS INT) +
            CAST(cli.external_medium AS INT) +
            CAST(cli.external_rich AS INT) )as external_total_loan_disburesd ,

            SUM(CAST(cli. external_poorest_category_amount AS INT) +
            CAST(cli.external_poor_category_amount AS INT) +
            CAST(cli.external_medium_amount AS INT) +
            CAST(cli.external_rich_amount AS INT) )as external_total_loan_amount_disburesd,

            SUM(CAST(cli. vi_poorest_category AS INT) +
            CAST(cli.vi_poor_category AS INT) +
            CAST(cli.vi_medium AS INT) +
            CAST(cli.vi_rich AS INT) )as vi_total_loan_disburesd ,

            SUM(CAST(cli. vi_poorest_category_amount AS INT) +
            CAST(cli.vi_poor_category_amount AS INT) +
            CAST(cli.vi_medium_amount AS INT) +
            CAST(cli.vi_rich_amount AS INT) ) as vi_total_loan_amount_disburesd




     FROM
         cluster_mst AS cl
          INNER JOIN cluster_profile AS clp
          ON cl.id = clp.cluster_sub_mst_id
          INNER JOIN federation_mst as fed
          on fed.uin = cl.federation_uin
          INNER JOIN cluster_inclusion as cli
          on cl.id = cli.cluster_sub_mst_id
          INNER JOIN federation_profile as fedp
          on fed.id = fedp.federation_sub_mst_id
          INNER JOIN agency AS ag
          ON fed.agency_id = ag.agency_id

          WHERE cl.is_deleted = 0";
          if(!empty($session_data['Search'])){
            if(!empty($session_data['agency'])){
                $agency = $session_data['agency'];
                $query .=" AND cl.agency_id = $agency  ";
             }
             if(!empty($session_data['cluster'])){
                $query .=" AND cl.uin = '" . $session_data['cluster'] . "' ";
             }
             if(!empty($session_data['federation'])){
                $query .=" AND fed.uin = '" . $session_data['federation'] . "' ";
             }

          }

        $query .=" group by cl.id  ";
        $cluster = DB::select($query);
        return collect($cluster);
    }

    public function map($res): array
    {


            return [
                $this->counter++,
                $res->uin,
                $res->name_of_cluster,
                $res->analysis_rating,
                $res->vo_code,
                $res->name_of_district,
                $res->name_of_state,
                $res->name_of_federation,
                $res->agency_name,


        (string)$res->visual_poorest_category,
        (string)$res->visual_poor_category,
        (string)$res->visual_medium_category,
        (string)$res->visual_rich_category,
        (string)$res->total_no_of_loan_disbursed,
        (string)$res->total_no_of_loan_ammount_disbursed,

        (string)$res->cluster_total_loan_disburesd,
        (string)$res->cluster_total_loan_amount_disburesd,

        (string)$res->federation_poorest_category,
        (string)$res->federation_poorest_category_amount,
        (string)$res->federation_poor_category,
        (string)$res->federation_poor_category_amount,
        (string)$res->federation_medium,
        (string)$res->federation_medium_amount,
        (string)$res->federation_rich,
        (string)$res->federation_rich_amount,


        (string)$res->external_total_loan_disburesd,
        (string)$res->external_total_loan_amount_disburesd,

        (string)$res->external_poorest_category,
        (string)$res->external_poorest_category_amount,
        (string)$res->external_poor_category,
        (string)$res->external_poor_category_amount,
        (string)$res->external_medium,
        (string)$res->external_medium_amount,
        (string)$res->external_rich,
        (string)$res->external_rich_amount,

        (string)$res->vi_total_loan_disburesd,
        (string)$res->vi_total_loan_amount_disburesd,

        (string)$res->vi_poorest_category,
        (string)$res->vi_poorest_category_amount,
        (string)$res->vi_poor_category,
        (string)$res->vi_poor_category_amount,
        (string)$res->vi_medium,
        (string)$res->vi_medium_amount,
        (string)$res->vi_rich,
        (string)$res->vi_rich_amount,

            ];
    }

    public function columnFormats(): array
    {
        return [

        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $event->sheet->getStyle('A1:AS1')->applyFromArray([
                    'font' => [
                        'bold' => true
                    ],
                    'fill' => [
                        'color' => ['argb' => '#CCCCCC' ]
                    ]
                ]);
            },
        ];
    }

    public function headings(): array
    {
        return [

            ['S.No',
            'UIN',
            'Name Of Cluster',
            'Risk Rating',
            'NRLM Code ',
            'District Name',
            'State Name',
            'Federation name',
            'Agency Name',


            'Has Cluster prepared an  Integrated cluster plan based on family/SHG plans ? (yes or no)',
            'If Yes - Date Cluster Plan was approved',
            'Date it was submitted to Federation',
            'Total Income on Cluster in last 12 months',
            'Total Expense of the Cluster in the last 12 months',
            'Is Cluster covering Operational cost through its own income ( Yes or No)',
            'No. of days taken to approve loan application at cluster level',
            'Average monthly loans in last 12 months',
            'Time taken from approval to cash in hand',
            'Does group prepare a monthly progress report and submit to federation ( yes or no)',
            'If yes, date last submitted'

            ]
        ];
    }

    public function title(): string
    {
        return 'Cluster CRecovery - Cumulative loans';
    }
}
