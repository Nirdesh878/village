<?php
namespace App\Exports\Cluster;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Carbon\Carbon;


class ClusterObservation implements WithHeadings, ShouldAutoSize, WithEvents, WithTitle, FromCollection, WithColumnFormatting, WithMapping
{

    public $curdate = '';
    public $counter = 1;
    public function __construct()
    {
        $this->curdate = Carbon::now()->format('d-m-Y');
    }

    public function collection()
    {
        $user = Auth::user();
        $session_data = Session::get('cluster_export_session');
        // prd($session_data);

        $query = "SELECT
        clp.*,
        cl.uin,
        ag.agency_name,
        fedp.name_of_federation

     FROM
         cluster_mst AS cl
          INNER JOIN cluster_profile AS clp
          ON cl.id = clp.cluster_sub_mst_id
          INNER JOIN federation_mst as fed
          on fed.uin = cl.federation_uin
          INNER JOIN federation_profile as fedp
          on fed.id = fedp.federation_sub_mst_id
          INNER JOIN agency AS ag
          ON fed.agency_id = ag.agency_id

          WHERE cl.is_deleted = 0";
          if(!empty($session_data['Search'])){
            if(!empty($session_data['agency'])){
                $agency = $session_data['agency'];
                $query .=" AND cl.agency_id = $agency  ";
             }
             if(!empty($session_data['cluster'])){
                $query .=" AND cl.uin = '" . $session_data['cluster'] . "' ";
             }
             if(!empty($session_data['federation'])){
                $query .=" AND fed.uin = '" . $session_data['federation'] . "' ";
             }

          }


        $cluster = DB::select($query);
        return collect($cluster);
    }

    public function map($res): array
    {


            return [
                $this->counter++,
                $res->uin,
                $res->name_of_cluster,
                $res->analysis_rating,
                $res->vo_code,
                $res->name_of_district,
                $res->name_of_state,
                $res->name_of_federation,
                $res->agency_name,

        (string)$res->cluster_observation_meeting,
        (string)$res->cluster_observation_president,
        (string)$res->cluster_members_at_time_creation,
        (string)$res->total_SHGs,
        (string)$res->total_members,
        (string)$res->president,
        (string)$res->secretary,
        (string)$res->treasure,
        (string)$res->book_keeper_name,
        (string)$res->date_of_appointment,
        (string)$res->account_opening_date,
        (string)$res->name_of_the_bank,
        (string)$res->name_of_the_contact_person,
        (string)$res->designation,
        (string)$res->contact_number



            ];
    }

    public function columnFormats(): array
    {
        return [

        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $event->sheet->getStyle('A1:Z1')->applyFromArray([
                    'font' => [
                        'bold' => true
                    ],
                    'fill' => [
                        'color' => ['argb' => '#CCCCCC' ]
                    ]
                ]);
            },
        ];
    }

    public function headings(): array
    {
        return [

            ['S.No',
            'UIN',
            'Name Of Cluster',
            'Risk Rating',
            'NRLM Code ',
            'District Name',
            'State Name',
            'Federation name',
            'Agency Name',


            'Who attended the meeting? - No of members',
            'Were all office bearers and leaders present?',
            'Did Cluster leaders understand purpose of meeting?',
            'What was quality of discussion?',
            'Did Cluster leaders & members understand vision of the cluster ?',
            'Do they understand benefits of being part of group? Explain benefits',
            'Does cluster have set practice of how repayments and savings are collected? Any Penalties?',
            'What are those practices?',
            'Does Cluster include any members who are the most poor and vulnerable?',
            'if yes, What is cluster policy on most vulnerable memebrs? ',
            'Are books of accounts managed by book-keeper only or others are aware of information as well?',
            'Any highlights?',
            'Any unique features of this Cluster?',
            'What are the unique rules/practices?',
            'Important Higlights (1)',
            'Important highlights (2)',
            'Important highlights (3)',
            'Important highlights (4)',
            'Important highlights (5)',

            ]
        ];
    }

    public function title(): string
    {
        return 'Cluster Observation';
    }
}
