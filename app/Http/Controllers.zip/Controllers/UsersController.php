<?php

namespace App\Http\Controllers;

use App\Exports\DartTeam;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserMapping;
use App\Rules\CheckDeleted;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use PDF;

class UsersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->curdate = Carbon::now()->format('d-m-Y');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $data = [];
        $user = Auth::User();

        if($user->u_type == 'M' || $user->u_type == 'QA'){
            return redirect('qualitycheck')->with('error', 'You do not have access to this page.');
         }
        $user_details = Auth::User();
        $u_type = $user_details->u_type;
        $user_id = $user_details->id;
        if (!empty($request->get('Search'))) {
            Session::put('user_filter_session', $request->all());
        }
        if (!empty($request->get('clear'))) {
            $request->session()->forget('user_filter_session');
        }
        if ($request->ajax()) {
            $session_data = Session::get('user_filter_session');
            $start = (int) $request->post('start');
            $limit = (int) $request->post('length');
            $txt_search = $request->post('search')['value'];

            $query = DB::table('users as a')
                ->leftjoin('agency as b', 'a.agency_id', '=', 'b.agency_id')
                ->select('a.*', 'b.agency_name');
            if ($u_type == 'A') {
                $query->where('a.u_type', '!=', 'CEO');
                $query->where('a.u_type', '!=', 'A');

            }
            if (!empty($session_data['Search'])) {
                if (!empty($session_data['user_type'])) {
                    if ($session_data['user_type'] != '') {
                        $query->where('a.u_type', '=', "" . $session_data['user_type'] . "");
                    }
                }

            }
            if ($txt_search != '') {
                $query->Where(function ($query) use ($txt_search) {
                    $query->orwhere('a.name', 'like', '%' . $txt_search . '%');
                    $query->orwhere('a.email', 'like', '%' . $txt_search . '%');
                });
            }

            $query->where('a.is_deleted', '=', 0);
            $total = $query->count();
            $user = $query->orderBy('a.created_at', 'desc')
                ->limit($limit)
                ->offset($start)
                ->get()->toArray();
            $query = "SELECT COUNT(u_type) as count FROM `users` a WHERE a.u_type = 'CEO'  AND a.is_deleted = 0";
            $u_ceo = DB::select($query);
            $u_count = $u_ceo[0]->count;

            // $super_admin = count()
            foreach ($user as $users) {
                if ($users->u_type == 'M') {
                    $user_type = 'District Manager';
                }
                if ($users->u_type == 'QA') {
                    $user_type = 'Quality Analyst';
                }
                if ($users->u_type == 'F') {
                    $user_type = 'FACILITATOR';
                }
                if ($users->u_type == 'A') {
                    $user_type = 'Admin';
                }
                if ($users->u_type == 'CEO') {
                    $user_type = 'Super-Admin';
                }

                $row = [];
                $row[] = ++$start;
                $row[] = $users->name;
                $row[] = $users->email;
                $row[] = $user_type;
                if($user_details->u_type == 'CEO'){
                $row[] = $users->password_show;
                }
                $row[] = $users->status_inex == 'internal' ? 'Internal' : 'External';

                $row[] = change_date_month_name_char($users->created_at);
                $row[] = change_date_month_name_char($users->updated_at);
                $row[] = $users->status == 'A' ? '<span class="status-active">Active</span>' : '<span class="status-inactive">InActive</span>';

                $btns = '';

                if ($users->u_type != 'CEO') {
                    $btns .= '<a class="btn btn-primary btn-link btn-sm" rel="tooltip" title="Edit" data-original-title="Edit" href="' . route('users.edit', $users->id) . '" style="padding:0px;margin:0px"><i class="c-white-500 ti-pencil"></i></a>';
                    $btns .= ' <a href="javascript:;" class="btn btn-danger btn-link btn-sm" rel="tooltip" title="Remove" onclick="fn_delete(\'' . $users->id . '\')" title="Delete User"  style="padding:0px;margin:0px"><i class="c-white-500 ti-trash"></i></a>';
                } else {
                    $btns .= '<a class="btn btn-primary btn-link btn-sm" rel="tooltip" title="Edit" data-original-title="Edit" href="' . route('users.edit', $users->id) . '" style="padding:0px;margin:0px"><i class="c-white-500 ti-pencil"></i></a>';
                    if ($u_count > 1) {
                        $btns .= ' <a href="javascript:;" class="btn btn-danger btn-link btn-sm" rel="tooltip" title="Remove" onclick="fn_delete(\'' . $users->id . '\')" title="Delete User"  style="padding:0px;margin:0px"><i class="c-white-500 ti-trash"></i></a>';
                    }
                }
                $row[] = $btns;
                $data[] = $row;
            }

            $output = array(
                "draw" => $request->post('draw'),
                "recordsTotal" => $total,
                "recordsFiltered" => $total,
                "data" => $data,
            );
            echo json_encode($output);
            exit;
        }
        return view('users.list')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [];
        $user = Auth::User();
        $u_type = $user->u_type;

        $data['agency'] = DB::table('agency')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['gender'] = DB::table('mst_gender')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();

        $query = "SELECT * from mst_roles a WHERE a.is_deleted = 0 ";

        if ($u_type == 'A') {
            $query .= "AND a.roles_slug !='CEO' ";
            $query .= "AND a.roles_slug !='A' ";
        }
        $query .= " ORDER BY a.position ASC";
        $data['roles'] = DB::select($query);

        $data['users'] = DB::table('users')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        return view('users.add')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // prd($request->all());
        $view = 'users.add';

        /* Check post either add or update */
        if ($request->isMethod('post')) {
            try {
                $validation_arr = [
                    'name' => ['required'],
                    'gender' => ['required'],
                    //'email' => ['required', 'unique:users'],
                    'email' => ['required', new CheckDeleted],
                    'mobile' => ['required'],
                    'address' => ['required'],
                    'city' => ['required'],
                    'pincode' => ['required'],
                    'u_type' => ['required'],
                    'status_inex' => ['required'],
                    // 'delete_inex' => ['required'],
                    'status' => ['required'],
                    'password' => ['required', 'string', 'min:8', 'confirmed'],
                ];

                $validator = Validator::make($request->all(), $validation_arr);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                $result = DB::transaction(function () use ($request) {

                    $temp_rand = '';

                    $user = Auth::User();

                    $user_details = new User();
                    // prd($user_details);
                    if ($request->post('agency_id') != '') {
                        $agency_id_save = implode(',', $request->post('agency_id'));

                        $user_details->agency_id = $agency_id_save;
                    }
                    if ($request->post('agency_dm') != '') {
                        $agency_id_save = implode(',', $request->post('agency_dm'));

                        $user_details->agency_id = $agency_id_save;
                    }

                    $user_details->name = $request->post('name');
                    $user_details->gender = $request->post('gender');
                    $user_details->email = $request->post('email');
                    $user_details->mobile = $request->post('mobile');
                    $user_details->adress = $request->post('address');
                    $user_details->city = $request->post('city');
                    $user_details->pincode = $request->post('pincode');
                    $user_details->u_type = $request->post('u_type');
                    $user_details->parent_id = $request->post('parent_id');
                    $user_details->status_inex = $request->post('status_inex');
                    $user_details->delete_inex = $request->post('delete_inex') ?? '';
                    $user_details->status = $request->post('status');
                    $temp_rand = $request->post('name');
                    $query = "Select role_short_name,id from mst_roles where is_deleted=0 and roles_slug='" . $request->post('u_type') . "'";
                    $result = DB::select($query);

                    $uin = 'IN' . $result[0]->role_short_name . '' . rand(1000000, 9999999);
                    $user_details->uin = $uin;
                    $user_details->roles_c = $result[0]->id;

                    $user_details->tkn = substr(md5(mt_rand()), 0, 16);
                    $query = "Select gender_short_name,id from mst_gender where is_deleted=0 and gender_short_name='" . $request->post('gender') . "'";
                    $result = DB::select($query);
                    $user_details->gender_c = $result[0]->id;
                    $user_details->created_by = $user->id;
                    $user_details->created_at = date('Y-m-d H:i:s');

                    if ($request->post('password') != '') {
                        $user_details->password = Hash::make($request->post('password'));
                        $user_details->password_show = $request->post('password');
                    }
                    $result = $user_details->save();





                    if ($user_details->u_type == 'M' || $user_details->u_type == 'F') {
                        $country = $request->post('country');
                        $state = $request->post('state');
                        $district_id = $request->post('district');

                        if (count($state) > 0) {
                            foreach ($state as $key => $value) {
                                if (!empty($district_id[$key])) {
                                    $dist_str = implode(",", $district_id[$key]);
                                } else {
                                    $dist_str = '';
                                }

                                $user_location = new UserMapping();
                                $user_location->user_id = $user_details->id;
                                $user_location->country_id = $country;
                                $user_location->state_id = $value;
                                $user_location->district_id = $dist_str;
                                $user_location->is_deleted = 0;
                                $user_location->created_by = $user->id;
                                $user_location->created_at = date('Y-m-d H:i:s');
                                $result = $user_location->save();

                            }

                        }

                    }
                    if ($user_details->u_type == 'A' || $user_details->u_type == 'QA' || $user_details->u_type == 'CEO') {
                        $admin_country = $request->post('admin_country');
                        if ($admin_country != '') {
                            $user_location = new UserMapping();
                            $user_location->user_id = $user_details->id;
                            $user_location->country_id = $admin_country;
                            $result = $user_location->save();
                        }
                    }
                    if ($result) {
                        return true;
                    }
                });
                if ($result == 1) {
                    return redirect('users')->with(['message' => 'User saved successfully.']);
                }
            } catch (\Exception$e) {
                prd($e->getMessage());
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
        }

        return view($view);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        $data['agency'] = DB::table('agency')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['gender'] = DB::table('mst_gender')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['roles'] = DB::table('mst_roles')
            ->orderBy('position', 'ASC')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['users_mappings'] = DB::table('user_location_relation')
            ->where('is_deleted', '=', 0)
            ->where('user_id', '=', $user->id)
            ->get()->toArray();
        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['states'] = DB::table('states')
            ->where('is_deleted', '=', 0)
            ->where('country_id', '=', $data['users_mappings'][0]->country_id)
            ->get()->toArray();
            $query = "SELECT GROUP_CONCAT(distinct(agency_id)) as agency from users where parent_id =
            $user->id and u_type = 'F' and is_deleted = 0";
            $data['fac_agency'] = DB::select($query);
            // prd($data['fac_agency']);

        $query="SELECT
        a.*
        FROM
            (
            SELECT
                a.agency_id AS agency_id,
                a.name AS fac_name,
                sh.shgName AS task_name,
                t.assignment_id AS task_id,
                t.assignment_type AS task_type
            FROM
                users AS a
            INNER JOIN shg_mst AS b
            ON
                a.agency_id = b.agency_id
            INNER JOIN shg_profile AS sh
            ON
                b.id = sh.shg_sub_mst_id
            INNER JOIN task_assignment AS t
            ON
                b.id = t.assignment_id
            WHERE
                a.id = $user->id AND a.u_type = 'F' AND t.status = 'P' AND t.assignment_type = 'SH' AND b.is_deleted = 0
            UNION
        SELECT
            a.agency_id AS agency_id,
            a.name AS fac_name,
            clus.name_of_cluster AS task_name,
            t.assignment_id AS task_id,
            t.assignment_type AS task_type
        FROM
            users AS a
        INNER JOIN cluster_mst AS b
        ON
            a.agency_id = b.agency_id
        INNER JOIN cluster_profile AS clus
        ON
            b.id = clus.cluster_sub_mst_id
        INNER JOIN task_assignment AS t
        ON
            b.id = t.assignment_id
        WHERE
            a.id = $user->id AND a.u_type = 'F' AND t.status = 'P' AND t.assignment_type = 'CL' AND b.is_deleted = 0
        UNION
        SELECT
            a.agency_id AS agency_id,
            a.name AS fac_name,
            fed.name_of_federation AS task_name,
            t.assignment_id AS task_id,
            t.assignment_type AS task_type
        FROM
            users AS a
        INNER JOIN federation_mst AS b
        ON
            a.agency_id = b.agency_id
        INNER JOIN federation_profile AS fed
        ON
            b.id = fed.federation_sub_mst_id
        INNER JOIN task_assignment AS t
        ON
            b.id = t.assignment_id
        WHERE
            a.id = $user->id AND a.u_type = 'F' AND t.status = 'P' AND t.assignment_type = 'FD' AND b.is_deleted = 0
                UNION
                SELECT
            a.agency_id AS agency_id,
            a.name AS fac_name,
            CONCAT(fm.fp_member_name, t.task_a1) AS task_name,
            t.assignment_id AS task_id,
            t.assignment_type AS task_type
        FROM
            users AS a
        INNER JOIN family_mst AS b
        ON
            a.agency_id = b.agency_id
        INNER JOIN family_profile AS fm
        ON
            b.id = fm.family_sub_mst_id
        INNER JOIN task_assignment AS t
        ON
            b.id = t.assignment_id
        WHERE
            a.id = $user->id AND a.u_type = 'F' AND t.status = 'P' AND t.assignment_type = 'FM' AND b.is_deleted = 0 AND(task_a1 = 'P1' OR task_a1 = 'P2')
        )a";

        // $query="SELECT
        // SUM(case when a.assignment_type = 'CL'  then 1 ELSE 0 END) AS cluster,
        // SUM(case when a.assignment_type = 'FD'  then 1 ELSE 0 END) AS federation,
        // SUM(case when a.assignment_type = 'FM'  then 1 ELSE 0 END) AS family,
        // SUM(case when a.assignment_type = 'SH'  then 1 ELSE 0 END) AS shg
        //  FROM task_assignment a
        //  join task_qa_assignment b
        //  on a.user_id = b.user_id
        //  where a.user_id = $user->id and STATUS = 'P'";
        // $data['pending_tasks'] = DB::select($query);

        $query="SELECT COUNT(a.id) as federation FROM  (SELECT fd.id
        FROM task_assignment AS t
        INNER JOIN federation_mst AS fd
        ON fd.id = t.assignment_id
        INNER JOIN federation_sub_mst AS fed
        ON fd.id = fed.federation_mst_id
        WHERE t.user_id = $user->id AND t.assignment_type = 'FD' AND ((fed.dm_a !='V' OR fed.qa_a !='V') OR (fed.dm_r !='V' OR fed.qa_r !='V')) GROUP BY t.assignment_id) AS a";
        $data['fed_pending_tasks'] = DB::select($query);

        $query="SELECT COUNT(a.id) as cluster FROM  (SELECT c.id
        FROM task_assignment AS t
        INNER JOIN cluster_mst AS c
        ON c.id = t.assignment_id
        INNER JOIN cluster_sub_mst AS cl
        ON c.id = cl.cluster_mst_id
        WHERE t.user_id = $user->id AND t.assignment_type = 'CL' AND ((cl.dm_a !='V' OR cl.qa_a !='V') OR (cl.dm_r !='V' OR cl.qa_r !='V')) GROUP BY t.assignment_id) AS a";
        $data['clus_pending_tasks'] = DB::select($query);

        $query="SELECT COUNT(a.id) as shg FROM  (SELECT s.id
        FROM task_assignment AS t
        INNER JOIN shg_mst AS s
        ON s.id = t.assignment_id
        INNER JOIN shg_sub_mst AS sh
        ON s.id = sh.shg_mst_id
        WHERE t.user_id = $user->id AND t.assignment_type = 'SH' AND ((sh.dm_a !='V' OR sh.qa_a !='V') OR (sh.dm_r !='V' OR sh.qa_r !='V')  ) GROUP BY t.assignment_id) AS a";
        $data['shg_pending_tasks'] = DB::select($query);

        $query="SELECT COUNT(a.id) as family FROM  (SELECT f.id
        FROM task_assignment AS t
        INNER JOIN family_mst AS f
        ON f.id = t.assignment_id
        INNER JOIN family_sub_mst AS fm
        ON f.id = fm.family_mst_id
        WHERE t.user_id = $user->id AND t.assignment_type = 'FM' AND ((fm.dm_p1 !='V' OR fm.dm_p2 !='V') OR  (fm.qa_p1 !='V' OR  fm.qa_p2 !='V') OR (fm.dm_r !='V' OR  fm.qa_r !='V'))   GROUP BY t.assignment_id) AS a";
        $data['family_pending_tasks'] = DB::select($query);

        $data['edit'] = 1;
        return view('users.edit', compact('user'))->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Users  $users
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, User $user)
    {
        $view = 'users.edit';
        // prd($request->all());
        /* Check post either add or update */
        if ($request->isMethod('PATCH')) {
            try {

                $validation_arr = [
                    'name' => ['required'],
                    'gender' => ['required'],
                    // 'email' => ['required', new CheckDeleted],
                    // 'email' => 'unique:users,email,' . $user->id,
                    'email'=>['required','email',Rule::unique('users','email')->ignore($request->input('id'))->where('is_deleted',0)],
                    'mobile' => ['required'],
                    'adress' => ['required'],
                    'city' => ['required'],
                    'pincode' => ['required'],
                    'u_type' => ['required'],
                    'status_inex' => ['required'],
                    'status' => ['required'],
                    'password' => ['required', 'string', 'min:8', 'confirmed'],
                ];

                $validator = Validator::make($request->all(), $validation_arr);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                $result = DB::transaction(function () use ($request, $user) {
                    $login_user = Auth::User();
                    $user_details = User::find($user->id);
                    if($request->post('u_type') == 'M'){
                        if ($request->post('agency_dm') != '' || $request->post('agency_hide_name') !='') {
                            $agency_ids ='';
                            if(!empty($request->post('agency_dm'))){
                              $agency_ids= implode(',', $request->post('agency_dm'));
                            }
                            $hide_agency = $request->post('agency_hide_name');
                            if($agency_ids !=''){
                                $user_details->agency_id = $agency_ids.','.$hide_agency;
                            }
                            else{
                                $user_details->agency_id = $hide_agency;

                            }

                        }
                    }
                    else{
                        if ($request->post('agency_id') != '') {
                            $agency_id_save = implode(',', $request->post('agency_id'));
                            $user_details->agency_id = $agency_id_save;
                        }
                    }


                    // die("end");
                    $user_details->name = $request->post('name');
                    $user_details->gender = $request->post('gender');
                    $user_details->email = $request->post('email');
                    $user_details->mobile = $request->post('mobile');
                    $user_details->adress = $request->post('adress');
                    $user_details->city = $request->post('city');
                    $user_details->pincode = $request->post('pincode');
                    $user_details->u_type = $request->post('u_type');
                    $user_details->parent_id = $request->post('parent_id');
                    $user_details->status_inex = $request->post('status_inex');
                    $user_details->delete_inex = $request->post('delete_inex') ?? '';
                    $user_details->status = $request->post('status');
                    // $user_details->device = $request->post('device') ?? '';
                    $user_details->updated_by = $login_user->id;
                    $user_details->updated_at = date('Y-m-d H:i:s');

                    $query = "Select role_short_name,id from mst_roles where is_deleted=0 and roles_slug='" . $user_details->u_type . "'";
                    $result = DB::select($query);
                    $user_details->roles_c = $result[0]->id;

                    $query = "Select gender_short_name,id from mst_gender where is_deleted=0 and gender_short_name='" . $user_details->gender . "'";
                    $result = DB::select($query);
                    $user_details->gender_c = $result[0]->id;

                    if ($request->post('password') != '') {
                        $user_details->password = Hash::make($request->post('password'));
                        $user_details->password_show = $request->post('password');
                    }
                    $result = $user_details->save();



                    if ($user_details->u_type == 'M' || $user_details->u_type == 'F') {
                        $country = $request->post('country');
                        $state = $request->post('state');
                        $district_id = $request->post('district');
                        if (count($state) > 0) {
                            UserMapping::where('user_id', '=', $request->post('id'))->delete();
                            foreach ($state as $key => $value) {
                                if (!empty($district_id[$key])) {
                                    $dist_str = implode(",", $district_id[$key]);
                                } else {
                                    $dist_str = '';
                                }

                                $user_location = new UserMapping();
                                $user_location->user_id = $user_details->id;
                                $user_location->country_id = $country;
                                $user_location->state_id = $value;
                                $user_location->district_id = $dist_str;
                                $user_location->is_deleted = 0;
                                $user_location->created_by = $user->id;
                                $user_location->created_at = date('Y-m-d H:i:s');
                                $result = $user_location->save();
                            }
                        }

                    }
                    if ($user_details->u_type == 'A' || $user_details->u_type == 'QA' || $user_details->u_type == 'CEO') {
                        $admin_country = $request->post('admin_country');
                        if ($admin_country != '') {
                            UserMapping::where('user_id', '=', $request->post('id'))->delete();
                            $user_location = new UserMapping();
                            $user_location->user_id = $user_details->id;
                            $user_location->country_id = $admin_country;
                            $result = $user_location->save();
                        }
                    }
                    if ($result) {
                        return true;
                    }

                });

                if ($result == 1) {
                    return redirect('users')->with(['message' => 'User updated successfully.']);
                }

            } catch (\Exception$e) {
                prd($e->getMessage());
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
        }

        return view($view);
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Users  $users
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        try {
            if ($user->id != '') {
                $user_details = User::find($user->id);
                $user_details->is_deleted = 1;
                $user_details->save();
                UserMapping::where('user_id', '=', $user->id)->update(['is_deleted' => 1]);
                // $user_details = UserMapping::where('user_id', '=', $user->id);
                // prd($user_details);
                // $user_details->is_deleted = 1;
                // $user_details->save();
                $data['message'] = 'User Deleted Successfully';
                echo json_encode($data);
            } else {
                $data['message'] = 'Invalid Request';
                echo json_encode($data);
            }
        } catch (\Exception$e) {
            print_r($e->getMessage());
        }
    }

    public function export(Request $request)
    {
        return Excel::download(new DartTeam(), 'DartTeam_' . pdf_date() . '.xlsx');
    }
    public function export_usersPdf()
    {

        $session_data = Session::get('user_filter_session');
        $query = "SELECT a.*
        from
        users a
        WHERE
        is_deleted  = 0";
        if (!empty($session_data['Search'])) {
            if (!empty($session_data['user_type'])) {
                if ($session_data['user_type'] != '') {
                    $query .= " AND a.u_type  = '" . $session_data['user_type'] . "'";
                }
            }
        }
        $data = DB::select($query);
        view()->share('data', $data);
        $pdf_doc = PDF::loadView('pdf.usersPdf', $data)->setPaper('a3', 'landscape');

        return $pdf_doc->download('Users_PDF' . pdf_date() . '.pdf');
    }
    public function get_agency_demography(Request $request)
    {
        if (request()->ajax()) {
            if ($request->get('agency_id') != '') {
                $agency_id = $request->get('agency_id');
                DB::enableQueryLog();
                $federation_list = DB::table('agency as a')
                    ->join('countries as s', 's.id', '=', 'a.country')
                    ->join('states as b', 'b.id', '=', 'a.state')
                    ->leftjoin('district as c', 'c.id', '=', 'a.district')
                    ->where('a.is_deleted', '=', 0)
                    ->where('a.agency_id', '=', $agency_id)
                    ->select('c.name as name_of_district', 'b.name as name_of_state', 's.name as name_of_country', 'b.id as state_id', 'c.id as district_id', 's.id as country_id')
                    ->get()->toArray();
                $aa = DB::getQueryLog();
                $state_id = $federation_list[0]->state_id;
                if (!empty($federation_list)) {
                    $res['country_option'] = "<option value='" . $federation_list[0]->country_id . "'>" . $federation_list[0]->name_of_country . "</option>";
                    $res['state_option'] = "<option value='" . $federation_list[0]->state_id . "'>" . $federation_list[0]->name_of_state . "</option>";
                    $district_list = DB::table('district as a')
                        ->where('a.is_deleted', '=', 0)
                        ->where('a.state_id', '=', $state_id)
                        ->select('a.id', 'a.name')
                        ->orderBy('a.name')
                        ->get()->toArray();
                    $res['district_option'] = '';
                    foreach ($district_list as $district) {
                        $select = '';
                        if (!empty($federation_list[0]->district_id)) {
                            if ($federation_list[0]->district_id == $district->id) {
                                $select = 'Selected';
                            }
                        } else {
                            $select = '';
                        }
                        $res['district_option'] .= '<option value="' . $district->id . '" ' . $select . ' >' . $district->name . '</option>';
                    }

                    return Response::json($res);
                }
            }
        }
        return Response::json([]);
    }
}
