<?php

namespace App\Http\Controllers;

use App\Exports\FamilyExport;
use App\Http\Controllers\API\SqlLibController;
use App\Http\Controllers\Controller;
// use App\Http\Controllers\stdClass;
use App\Models\Family;
use App\Models\FamilyAgricultureProductionNextYear;
use App\Models\FamilyAgricultureProductionThisYear;
use App\Models\FamilyAnalysisNextYear;
use App\Models\FamilyAnalysisThisYear;
use App\Models\FamilyAssets;
use App\Models\FamilyAssetsGadgets;
use App\Models\FamilyAssetsLiveStock;
use App\Models\FamilyAssetsMachinery;
use App\Models\FamilyAssetsVehicle;
use App\Models\FamilyBusinessInvestmentPlan;
use App\Models\FamilyChallenges;
use App\Models\FamilyConcent;
use App\Models\FamilyExpenditureNextYear;
use App\Models\FamilyExpenditureThisYear;
use App\Models\FamilyFixedInvestment;
use App\Models\FamilyGoals;
use App\Models\FamilyIncomeFromBusiness;
use App\Models\FamilyIncomeNextYear;
use App\Models\FamilyIncomeThisYear;
use App\Models\FamilyLoanApprovel;
use App\Models\familyLoanDisbursement;
use App\Models\FamilyLoanOutstanding;
use App\Models\FamilyLoanRepayment;
use App\Models\FamilyObservationNextYear;
use App\Models\FamilyObservationThisYear;
use App\Models\FamilyObservationThisYearMember;
use App\Models\FamilyProfile;
use App\Models\FamilyRating;
use App\Models\FamilySavings;
use App\Models\FamilySavingsSource;
use App\Models\FamilySavingsSourceOther;
use App\Models\FamilyShgmemberCommitment;
use App\Models\FamilySubMst;
use App\Models\FamilyYearlyOperationalExpenses;
use App\Models\FcsnodeMst;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use PDF;
use \stdClass;
use App\Rules\CheckFamily;
use App\Rules\CheckFamilySpouse;
use Illuminate\Support\Facades\Session;
use App\Models\TaskQaAssignment;
use App\Models\TaskAssignment;



class FamilyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->curdate = Carbon::now()->format('d-m-Y');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {


        $data = [];
        $user = Auth::User();
        // save_login_log();
        $user = Auth::User();
        if($user->u_type == 'QA'){
            return redirect('qualitycheck')->with('error', 'You do not have access to this page.');
        }



        $user_geo = DB::table('user_location_relation')
            ->where('user_id', $user->id)
            ->where('is_deleted', '=', 0)
            ->orderBy('country_id')
            ->get()->toArray();
        $fac_list = DB::table('users')
            ->where('parent_id', $user->id)
            ->where('is_deleted', '=', 0)
            ->select(DB::raw('group_concat(users.id) AS ids'))
            ->get()->toArray();
        $list = $fac_list[0]->ids;
        if ($request->ajax()) {

            $start = (int) $request->post('start');
            $limit = (int) $request->post('length');
            $txt_search = $request->post('search')['value'];




            $query = " SELECT
                    z.*,
                    d.agency_name,
                    e.name AS country_name,
                    f.name AS state_name,
                    g.name AS district_name,
                    Y.uin,
                    Y.id AS ids,
                    Y.status,
                    Y.created_at as created,
                    Y.cluster_uin,
                    h.name_of_federation,
                    b.name_of_cluster,
                    j.shgName,
                    X.status AS family_status,
                    X.analytics,
                    X.rating,
                    X.locked,
                    X.flag,
                    X.dm_p1,
                    X.dm_p2,
                    X.qa_p1,
                    X.qa_p2,
                    X.qa_r,
                    X.dm_r,
                    X.locked,
                    X.updated_at,
                    X.status_flag,
                    X.recalled,
                    X.family_flag,
                    X.family_status
                FROM
                    family_mst AS Y
                INNER JOIN family_sub_mst AS X
                ON
                    Y.id = X.family_mst_id
                INNER JOIN family_profile AS z
                ON
                    X.id = z.family_sub_mst_id
                INNER JOIN shg_mst AS i
                ON
                    i.uin = Y.shg_uin
                INNER JOIN shg_sub_mst AS w
                ON
                    i.id = w.shg_mst_id
                INNER JOIN shg_profile AS j
                ON
                    j.shg_sub_mst_id = w.id
                LEFT JOIN cluster_mst AS a
                ON
                    i.cluster_uin = a.uin
                LEFT JOIN cluster_sub_mst AS v
                ON
                    a.id = v.cluster_mst_id
                LEFT JOIN cluster_profile AS b
                ON
                    b.cluster_sub_mst_id = v.id
                INNER JOIN federation_mst AS c
                ON
                    i.federation_uin = c.uin
                INNER JOIN federation_sub_mst AS u
                ON
                    c.id = u.federation_mst_id
                INNER JOIN federation_profile AS h
                ON
                    h.federation_sub_mst_id = u.id
                INNER JOIN agency AS d
                ON
                    Y.agency_id = d.agency_id
                LEFT JOIN countries AS e
                ON
                    z.fp_country_id = e.id
                LEFT JOIN states AS f
                ON
                    z.fp_state_id = f.id
                LEFT JOIN district AS g
                ON
                    z.fp_district_id = g.id";


            $query .= " WHERE
                    Y.is_deleted = 0";
                    if ($user->u_type == 'M') {
                        // $query .= " AND (Y.created_by = $user->id OR z.fp_district IN($district_list)) ";
                        if($user_geo[0]->district_id == ''){
                            $district_list = 0;
                        } else{

                            $district_list = $user_geo[0]->district_id;
                        }

                        $state_id = $user_geo[0]->state_id;

                        $query .= " AND (CASE WHEN Y.created_by > 1 THEN 1 ELSE 0 END = 1 AND Y.created_by = $user->id AND  Y.is_deleted = 0";
                        if ($txt_search != '') {
                            $query .= " AND (z.fp_member_name like '%$txt_search%' ";
                            $query .= " or j.shgName like '%$txt_search%' ";
                            $query .= " or b.name_of_cluster like '%$txt_search%' ";
                            $query .= " or h.name_of_federation like '%$txt_search%' ";
                            $query .= " or SUBSTRING(Y.uin, LENGTH(Y.uin) - 3) LIKE '%$txt_search%' )";

                        }
                        $query .= " )
                        OR
                        (CASE WHEN Y.created_by < 2 THEN 1 ELSE 0 END = 1 AND (z.fp_district_id IN ($district_list) OR z.fp_state_id = $state_id ) AND  Y.is_deleted = 0";
                        if ($txt_search != '') {
                            $query .= " AND (z.fp_member_name like '%$txt_search%' ";
                            $query .= " or j.shgName like '%$txt_search%' ";
                            $query .= " or b.name_of_cluster like '%$txt_search%' ";
                            $query .= " or h.name_of_federation like '%$txt_search%' ";
                            $query .= " or SUBSTRING(Y.uin, LENGTH(Y.uin) - 3) LIKE '%$txt_search%' )";

                        }

                        $query .= " )";
                    }
                    if($user->u_type != 'M'){
                        if ($txt_search != '') {
                            $query .= " AND (z.fp_member_name like '%$txt_search%' ";
                            $query .= " or j.shgName like '%$txt_search%' ";
                            $query .= " or b.name_of_cluster like '%$txt_search%' ";
                            $query .= " or h.name_of_federation like '%$txt_search%' ";
                            $query .= " or SUBSTRING(Y.uin, LENGTH(Y.uin) - 3) LIKE '%$txt_search%' )";
                        }

                    }
            $familys = DB::select($query);
            $total = count($familys);
            // prd();
            $query .= " ORDER BY
                    X.updated_at
                DESC,Y.id DESC
                LIMIT $limit OFFSET $start";
            $familys = DB::select($query);

            foreach ($familys as $family) {
                if($family->family_flag == 0){
                    if ($family->dm_p1 == 'V' && $family->qa_p1 == 'V' && $family->dm_p2 == 'V' && $family->qa_p2 == 'V' && $family->locked == 1) {
                        $visit = 'Locked';
                    } elseif ($family->dm_p1 == 'V' && $family->dm_p2 == 'V' && $family->qa_p1 == 'V' && $family->qa_p2 == 'V') {
                        $visit = 'Initial Rating';
                    } elseif ($family->dm_p1 == 'V' && $family->dm_p2 == 'V') {
                        $visit = 'Analytics Complete';
                    } else if (($family->dm_p1 == 'P' && $family->dm_p2 == 'P')) {
                        $visit = 'Both Visit Completed';
                    } else if (($family->dm_p1 == 'V' && $family->dm_p2 == 'P' )) {
                        $visit = 'Both Visit Completed';
                    } else if ($family->dm_p2 == 'R' && $family->dm_p1 == 'V' && $family->flag == 1) {
                        $visit = 'Second Visit Rejected';
                    } else if ($family->dm_p1 == 'P' or $family->dm_p1 == 'V') {
                        $visit = 'Second Visit Pending ';
                    } else if ($family->dm_p1 == 'R' && $family->flag == 1) {
                        $visit = 'First Visit Rejected';
                    } elseif ($family->dm_p1 == 'N') {
                        $visit = 'First Visit Pending';
                    } elseif ($family->recalled == 1) {
                        $visit = 'Recalled';
                    } else {
                        $visit = 'Created';
                    }
                }else{
                    $visit = family_status($family->family_status);
                }

                $row = [];
                $row[] = ++$start;
                $row[] = $family->uin;
                $row[] = $family->fp_member_name;
                $row[] = $family->shgName;
                $row[] = ($family->name_of_cluster != '' or $family->name_of_cluster == 'NULL') ? $family->name_of_cluster : '-';
                $row[] = $family->name_of_federation;
                $row[] = $visit;
                $row[] = change_date_month_name_char($family->created);
                $row[] = change_date_month_name_char($family->updated_at);
                $row[] = $family->locked == 1 ? 'Yes' : 'No';
                $row[] = $family->status == 'A' ? '<span class="status-active">Active</span>' : '<span class="status-inactive">InActive</span>';
                $btns = '';
                if ($user->u_type != 'M') {
                    $btns .= '<a class="btagencyn btn-primary btn-link btn-sm" rel="tooltip" title="Edit" data-original-title="Edit" href="' . route('family.edit', $family->ids) . '" style="padding:0px;margin:0px"><i class="c-white-500 ti-pencil"></i></a>';
                    $btns .= '<a class="btn btn-success btn-link btn-sm" rel="tooltip" title="View" data-original-title="View" href="' . route('family.show', $family->ids) . '" style="padding:0px;margin-left:5px"><i class="c-white-500 ti-eye"></i></a>';
                    $btns .= ' <a href="javascript:;" class="btn btn-danger btn-link btn-sm" rel="tooltip" title="Remove" onclick="fn_delete(\'' . $family->ids . '\')" title="Delete User"  style="padding:0px;margin:0px"><i class="c-white-500 ti-trash"></i></a>';
                } elseif ($user->u_type == 'M') {

                        if ($family->status_flag == 1) {
                            $btns .= '<a class="btagencyn btn-primary btn-link btn-sm" rel="tooltip" title="Edit" data-original-title="Edit"  style="padding:0px;margin:0px;opacity: 0.3;"><i class="c-white-500 ti-pencil"></i></a>';
                            $btns .= '<a class="btn btn-success btn-link btn-sm" rel="tooltip" title="View" data-original-title="View"  style="padding:0px;margin-left:5px;opacity: 0.3;"><i class="c-white-500 ti-eye"></i></a>';
                            if($user->delete_inex != 'D'){
                            $btns .= ' <a href="javascript:;" class="btn btn-danger btn-link btn-sm" rel="tooltip" title="Remove"  title="Delete User"  style="padding:0px;margin:0px;opacity: 0.3;"><i class="c-white-500 ti-trash"></i></a>';
                            }
                        } else {
                            $btns .= '<a class="btagencyn btn-primary btn-link btn-sm" rel="tooltip" title="Edit" data-original-title="Edit" href="' . route('family.edit', $family->ids) . '" style="padding:0px;margin:0px"><i class="c-white-500 ti-pencil"></i></a>';
                            $btns .= '<a class="btn btn-success btn-link btn-sm" rel="tooltip" title="View" data-original-title="View" href="' . route('family.show', $family->ids) . '" style="padding:0px;margin-left:5px"><i class="c-white-500 ti-eye"></i></a>';
                            if($user->delete_inex != 'D'){
                            $btns .= ' <a href="javascript:;" class="btn btn-danger btn-link btn-sm" rel="tooltip" title="Remove" onclick="fn_delete(\'' . $family->ids . '\')" title="Delete User"  style="padding:0px;margin:0px"><i class="c-white-500 ti-trash"></i></a>';
                            }
                        }
                }




                $row[] = $btns;
                $data[] = $row;
            }

            $output = array(
                "draw" => $request->post('draw'),
                "recordsTotal" => $total,
                "recordsFiltered" => $total,
                "data" => $data,
            );
            echo json_encode($output);
            exit;
        }
        return view('family.list')->with($data);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [];

        $user = Auth::User();
        $user_geo = DB::table('user_location_relation')
            ->select(DB::raw('GROUP_CONCAT(state_id) as state_ids'))
            ->where('user_id', $user->id)
            ->where('is_deleted', '=', 0)
            ->orderBy('country_id')
            ->get()->toArray();
        $states_id = $user_geo[0]->state_ids;
        $query = "SELECT * from agency WHERE is_deleted = 0";
        if ($user->u_type == 'M') {

            // $query .= " AND state in ($states_id)";
            $query .= " AND agency_id in ($user->agency_id)";

        }
        $data['agency'] = DB::select($query);
        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['gender'] = DB::table('mst_gender')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['caste'] = DB::table('mst_caste')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        return view('family.add')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        $view = 'family.list';
        if ($request->isMethod('post')) {
            try {
                $validation_arr = [
                    'agency_id' => ['required'],
                    'federation_id' => ['required'],
                    'shg_uin2' => ['required'],
                    'country' => ['required'],
                    'state' => ['required'],
                    'fp_spouse_name' => ['required' , new CheckFamilySpouse],
                    'fp_village' => ['required'],
                    'fp_member_name' => ['required' , new CheckFamily],
                    'fp_contact_no'=>['required'],
                ];

                $validator = Validator::make($request->all(), $validation_arr);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                $result = DB::transaction(function () use ($request) {
                    $temp_rand = '';

                    $user = Auth::User();

                    $fp_spouse_name = $request->post('fp_spouse_name');
                    $fp_village = $request->post('fp_village');
                    $fp_name = $request->post('fp_member_name');
                    $shg_name = $request->post('shg_uin2');
                    $fp_contact_no = $request->post('fp_contact_no');

                    if (count($shg_name) > 0) {

                        foreach ($shg_name as $key => $value) {
                            $family_mst = new Family();
                            $country_code = strtoupper(getCountryCodeByID($request->post('country')));
                            $state_code = strtoupper(getStateCodeByID($request->post('state')));
                            $district_code = strtoupper(substr(getName('district', 'name', $request->post('district')), 0, 2));
                            $uin = checkAndGenerateUIN($country_code, $state_code, $district_code, 'family_mst', 'FM');

                            $family_mst->uin = $uin;
                            $temp_rand = $request->post('agency_id');
                            $family_mst->agency_id = $temp_rand;
                            $family_mst->status = 'A';
                            $family_mst->federation_uin = $request->post('federation_id');
                            $family_mst->cluster_uin = $request->post('cluster_uin');
                            $family_mst->shg_uin = $value;
                            $family_mst->tkn = substr(md5(mt_rand()), 0, 16);
                            $family_mst->uin = $uin;
                            $family_mst->created_by = $user->id;
                            $shg_uin = $value;
                            $cluster_uin = $request->post('cluster_uin');
                            $federation_uin = $request->post('federation_id');
                            $pid = 0; // define
                            if ($request->post('cluster_uin') != '') {
                                $qry = "SELECT * FROM fcsnode_mst WHERE uin IN('" . $request->post('shg_uin') . "','" . $request->post('cluster_uin') . "','" . $request->post('federation_id') . "')";
                            } else {
                                $qry = "SELECT * FROM fcsnode_mst WHERE uin IN('" . $request->post('shg_uin') . "','" . $request->post('federation_id') . "')";
                            }

                            $data = DB::select($qry);
                            if (!empty($data)) {
                                foreach ($data as $data2) {
                                    $data2 = (array) $data2;
                                    if ($data2['uin'] == $shg_uin) {
                                        $family_mst->shg_uin = $data2['uin'];
                                        $pid = $data2['id'];
                                    }
                                    if ($family_mst->cluster_uin != '') {
                                        if ($data2['uin'] == $cluster_uin) {
                                            $family_mst->cluster_uin = $data2['uin'];
                                        }
                                    }
                                    if ($data2['uin'] == $federation_uin) {
                                        $family_mst->federation_uin = $data2['uin'];
                                    }
                                }
                            }

                            $result = $family_mst->save();

                            $Family_Profile = array(
                                'family_sub_mst_id' => $family_mst->id,
                                'fp_member_name' => $fp_name[$key],
                                'fp_spouse_name' => $fp_spouse_name[$key],
                                'fp_country_id' => $request->post('country'),
                                'fp_state_id' => $request->post('state'),
                                'fp_district_id' => $request->post('district'),
                                'fp_country' => getName('countries', 'name', $request->post('country')),
                                'fp_state' => getName('states', 'name', $request->post('state')),
                                'fp_district' => getName('district', 'name', $request->post('district')),
                                'fp_village' => $fp_village[$key],
                                'created_by' => $user->id,
                                'fp_age' => '',
                                'fp_gender' => '',
                                'fp_caste' => '',
                                'fp_caste_c' => '',
                                'fp_gender_c' => '',
                                'fp_contact_no' => $fp_contact_no[$key],
                                'fp_aadhar_no' => '',
                                'fp_pan' => '',
                                'fp_block' => '',
                                'created_at' => date('Y-m-d H:i:s'),
                            );
                            $result = $this->Submaster($family_mst->id, $pid, $uin, $temp_rand, $Family_Profile);
                        }
                        if ($result) {
                            return true;
                        }
                    }
                });
                if ($result) {
                    return redirect('family')->with(['message' => 'Family saved successfully.']);
                }
            } catch (\Exception $e) {
                prd($e->getMessage());
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
        }

        return view($view);
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Family  $family
     * @return \Illuminate\Http\Response
     */
    public function show(Family $family, Request $request)
    {


        $data['pre_url'] = (url()->previous());
        $user = Auth::user();
        $data['family_ids'] = $family->id;
        $data['dm_id'] = $user->id;
        $data['u_type'] = $user->u_type;
        $data['agency_id'] = $family->agency_id;
        $data['task_type'] = $request->get('task_type');
        $data['quality_check'] = ($request->get('task_id') == null) ? 0 : 1;
        $quality_check_id = $request->get('task_id');
        $t_q_a = DB::table('task_qa_assignment as y')
            ->select('y.*')
            ->where('y.assignment_id', '=', $family->id)
            ->where('y.assignment_type', '=', 'FM')
            ->where('y.id', '=', $quality_check_id)
            ->orderBy('id', 'DESC')
            ->limit(1)
            ->get()->toArray();
        $diff = 0;
        if (!empty($t_q_a)) {
            if ($t_q_a[0]->task_a1 == 'P2' && $t_q_a[0]->qa_status == 'V') {
                $date1 = date('Y-m-d');
                $date2 = $t_q_a[0]->quality_date;
                $date2 = date("Y-m-d", strtotime($date2));
                $date3 = date_create($date1);
                $date4 = date_create($date2);
                $diff = date_diff($date4, $date3);
                $diff = $diff->format("%a");
            }
        }
        // prd($t_q_a[0]->qa_status);
        $data['diff'] = $diff;
        $data['task_id'] = $request->get('task_id') ?? ($t_q_a[0]->id) ?? null;
        $data['user_id'] = $request->get('user_id') ?? ($t_q_a[0]->user_id) ?? null;
        $data['qa_status'] = $t_q_a[0]->qa_status ?? null;
        $data['qa_remark'] = $t_q_a[0]->remark ?? null;
        $data['qa_readonly'] = ($data['qa_status'] == 'R' || $data['qa_status'] == 'V') ? 'readonly' : '';
        $data['quality_status'] = $t_q_a[0]->quality_status ?? null;
        $data['quality_remark'] = $t_q_a[0]->quality_remark ?? null;

        $quality_remark = $data['quality_remark'];

        $data['manager_date'] = $t_q_a[0]->manger_date ?? null;
        $data['quality_date'] = $t_q_a[0]->quality_date ?? null;
        $data['qa_readonly1'] = ($data['quality_status'] == 'R' || $data['quality_status'] == 'V') ? 'readonly' : '';
        $data['agency'] = DB::table('agency as a')
            ->select('a.agency_name')
            ->where('is_deleted', '=', 0)
            ->where('a.agency_id', '=', $family->agency_id)
            ->get()->toArray();

        $query = "Select * from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);
        $data['family_business'] = $result[0]->family_buisness;
        $data['task_status'] = $result[0]->dm_p1;
        $data['task_status_qa_p1'] = $result[0]->qa_p1;
        $data['dm_p2_status'] = $result[0]->dm_p2;
        $data['family_flag'] = $result[0]->family_flag;
        $data['qa_p2_status'] = $result[0]->qa_p2;
        $data['analytics_st'] = $result[0]->analytics;
        $data['rating_st'] = $result[0]->rating;
        $data['manager_status'] = $result[0]->qa_status;
        $data['mst_id'] = $result[0]->id;
        $data['locked'] = $result[0]->locked;
        $data['family_profile'] = DB::table('family_profile as y')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('z.is_deleted', '=', 0)
            ->where('x.id', '=', $result[0]->id)
            ->get()->toArray();
        $query_1 = "Select b.shgName from shg_mst a inner join shg_sub_mst c on a.id=c.shg_mst_id inner join shg_profile b on c.id=b.shg_sub_mst_id where a.is_deleted=0 and a.uin='$family->shg_uin' ";
        $data['shg_profile'] = DB::select($query_1);

        $query_1 = "Select b.name_of_cluster from cluster_mst a inner join cluster_sub_mst c on a.id=c.cluster_mst_id inner join cluster_profile b on c.id=b.cluster_sub_mst_id where a.is_deleted=0 and a.uin='$family->cluster_uin' ";
        $data['clusterprofile'] = DB::select($query_1);

        $query_2 = "Select b.name_of_federation from federation_mst a inner join federation_sub_mst c on a.id=c.federation_mst_id inner join federation_profile b on c.id=b.federation_sub_mst_id where a.is_deleted=0 and a.uin='$family->federation_uin' ";
        $data['fed_profile'] = DB::select($query_2);

        $data['agriculture_production_next_year'] = DB::table('family_agriculture_production_next_year as a')
            ->groupBy('a.production_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.production_type', DB::raw('SUM(a.total_sale_value) AS total_sale_value_ny'), DB::raw('group_concat(a.id) AS id_ny'))
            ->orderBy('a.production_type', 'ASC')->get()->toArray();
        $data['agriculture_production_this_year'] = DB::table('family_agriculture_production_this_year as a')
            ->groupBy('a.production_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.production_type', DB::raw('"ny_total"'), DB::raw('"ny_id"'), DB::raw('SUM(a.total_sale_value) AS total_sale_value_cy'), DB::raw('group_concat(a.id) AS id_cy'))
            ->orderBy('a.production_type', 'ASC')->get()->toArray();

        $fm_id = $result[0]->id;
        // Aggriculture production this year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as cy_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_this_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Agriculture'";
        $data['aggriculture_this'] = DB::select($query);

        // Aggriculture production next year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as ny_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_next_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Agriculture'";
        $data['aggriculture_next'] = DB::select($query);

        // Live stock production this year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as cy_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_this_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Live Stock'";
        $data['live_this'] = DB::select($query);

        // Live stock production next year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as ny_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_next_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Live Stock'";
        $data['live_next'] = DB::select($query);

        // Horticultural production this year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as cy_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_this_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Horticultural'";
        $data['Horticultural_this'] = DB::select($query);

        // Horticultural production next year
        $query = "SELECT
            production_type,
            coalesce(SUM(production_per_year),0) as ny_total,
            coalesce(group_concat(id),0) as id
        FROM
            `family_agriculture_production_next_year`
        WHERE
            family_sub_mst_id = $fm_id AND production_type = 'Horticultural'";
        $data['Horticultural_next'] = DB::select($query);

        $data['agri_type'] = array('Agriculture', 'Horticultural', 'Live Stock');

        $data['assets'] = DB::table('family_assets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_gadgets'] = DB::table('family_assets_gadgets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_live_stock'] = DB::table('family_assets_live_stock as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupBy('a.animal_Types')
            ->get()->toArray();

        $data['assets_machinery'] = DB::table('family_assets_machinery as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupby('a.machinery_Types')
            ->get()->toArray();

        $data['assets_vehicle'] = DB::table('family_assets_vehicle as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupBy('a.vehicle_Types')
            ->get()->toArray();

        $data['business_investment_plan'] = DB::table('family_business_investment_plan as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_approvel'] = DB::table('family_loan_approvel as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['gov_program'] = DB::table('family_gov_liveilhood_program as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $manager_id = 0;
        if (!empty($data['loan_approvel'])) {
            $manager_id = $data['loan_approvel'][0]->manager_id;
        }
        $query = "Select name from users where id = " . $manager_id . " ";
        $data['manager'] = DB::select($query);

        $data['loan_disbursement'] = DB::table('family_loan_disbursement as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['family_member_info'] = DB::table('family_member_information as a')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $challenge_type = array(
            'Describe Action to address the challenge',
            'Who would be responsible for action. Specify name',
            'When would action be completed (date)',
            'Is there any support from project office needed to complete action',
            'What kind of support is needed',
            'Was action completed by expected date (Y/N/NA)',
            'Has action been changed/revised during last visit (Y/N)',
            'Facilitator to fill which is the revised/changed action',
        );

        $data['challenges'] = DB::table('family_challenges as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        foreach ($challenge_type as $key1 => $val) {
            $data['challenges_action'][$key1]['name'] = $val;
            foreach ($data['challenges'] as $key => $val1) {
                $temp = json_decode($val1->ch_actions);
                if (!empty($temp)) {
                    if ($key1 == 0) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_describe_action;
                        continue;
                    }
                    if ($key1 == 1) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_responsible;
                        continue;
                    }
                    if ($key1 == 2) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_action_completed;
                        continue;
                    }
                    if ($key1 == 3) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_SHG_Cluster_complete;
                        continue;
                    }
                    if ($key1 == 4) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_support_needed;
                        continue;
                    }
                    if ($key1 == 5) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_expected_date;
                        continue;
                    }
                    if ($key1 == 6) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_changed_rating;
                        continue;
                    }
                    if ($key1 == 7) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_facilitator;
                        continue;
                    }
                }
            }
        }
        $data['photos_first_year'] = DB::table('family_upload_photos_videos as a')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $data['photos_second_year'] = DB::table('family_image_nextyear as a')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        if (!empty($data['photos'][0]->photos_videos_name)) {
            $raw_png3 = implode(array_map('chr', json_decode($data['photos'][0]->photos_videos_name)));
            $name3 = 'photo_' . $result[0]->id . '.jpg';
            $fb1 = fopen('./signature/' . $name3, 'wb');
            fwrite($fb1, $raw_png3);
            $data['photos'][0]->photos_videos_name = $name3;
        }

        $data['concent'] = DB::table('family_concent as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();



        if (!empty($data['concent'][0]->signature_of_facilitatorPic)) {
            if ($data['concent'][0]->signature_of_facilitatorPic != '\"\"') {
                $raw_png1 = implode(array_map('chr', json_decode($data['concent'][0]->signature_of_facilitatorPic)));
                $name1 = 'fac_' . $result[0]->id . '.png';
                $fb1 = fopen('./newsignature/' . $name1, 'wb');
                fwrite($fb1, $raw_png1);
                $data['concent'][0]->signature_of_facilitatorPic = $name1;
            }


        }
        if (!empty($data['concent'][0]->signature_of_participantPic)) {
            if ($data['concent'][0]->signature_of_participantPic != '\"\"') {
                $raw_png2 = implode(array_map('chr', json_decode($data['concent'][0]->signature_of_participantPic)));
                $name2 = 'par_' . $result[0]->id . '.png';
                $fb2 = fopen('./newsignature/' . $name2, 'wb');
                fwrite($fb2, $raw_png2);
                $data['concent'][0]->signature_of_participantPic = $name2;
            }


         }


        $data['expenditure_next_year'] = DB::table('family_expenditure_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->orderBy('a.e_cat')
            ->get()->toArray();
        $data['expen_next'] = array('Normal Expenditure', 'Social Expenditure', 'Wasteful Expenditure', 'Loan Expenditure');

        $data['expenditure_this_year'] = DB::table('family_expenditure_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->orderBy('a.e_cat')
            ->get()->toArray();

        $data['expenditure_next_year_new'] = DB::table('family_expenditure_next_year as a')
            ->groupBy('a.e_cat')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.e_cat', DB::raw('SUM(a.e_total_amount) AS e_total_amount_ny'), DB::raw('group_concat(a.id) AS id_ny'))
            ->orderBy('a.e_cat', 'ASC')->get()->toArray();
        $data['expenditure_this_year_new'] = DB::table('family_expenditure_this_year as a')
            ->groupBy('a.e_cat')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.e_cat', DB::raw('"ny_total"'), DB::raw('"ny_id"'), DB::raw('SUM(a.e_total_amount) AS e_total_amount_cy'), DB::raw('group_concat(a.id) AS id_cy'))
            ->orderBy('a.e_cat', 'ASC')->get()->toArray();

        // Normal Expenditure this year
        $query = "SELECT
            e_cat,
            COALESCE(SUM(e_total_amount),0) as cy_total,
            COALESCE(GROUP_CONCAT(id),0) as id
        FROM
            `family_expenditure_this_year`
        WHERE
            family_sub_mst_id = $fm_id AND e_cat = 'Normal Expenditure' ";
        $data['normal_exp_this'] = DB::select($query);

        // Normal Expenditure next year

        $query = "SELECT
            e_cat,
            COALESCE(SUM(e_total_amount),0) as ny_total,
            COALESCE(GROUP_CONCAT(id),0) as id
        FROM
            `family_expenditure_next_year`
        WHERE
            family_sub_mst_id = $fm_id AND e_cat = 'Normal Expenditure' ";
        $data['normal_exp_next'] = DB::select($query);

        // social Expenditure this year
        $query = "SELECT
                    e_cat,
                    COALESCE(SUM(e_total_amount),0) as cy_total,
                    COALESCE(GROUP_CONCAT(id),0) as id
                FROM
                    `family_expenditure_this_year`
                WHERE
                    family_sub_mst_id = $fm_id AND e_cat = 'Social Expenditure' ";
        $data['social_exp_this'] = DB::select($query);

        // social Expenditure next year

        $query = "SELECT
                    e_cat,
                    COALESCE(SUM(e_total_amount),0) as ny_total,
                    COALESCE(GROUP_CONCAT(id),0) as id
                FROM
                    `family_expenditure_next_year`
                WHERE
                    family_sub_mst_id = $fm_id AND e_cat = 'Social Expenditure' ";
        $data['social_exp_next'] = DB::select($query);

        // Wasteful Expenditure this year
        $query = "SELECT
                e_cat,
                COALESCE(SUM(e_total_amount),0) as cy_total,
                COALESCE(GROUP_CONCAT(id),0) as id
            FROM
                `family_expenditure_this_year`
            WHERE
                family_sub_mst_id = $fm_id AND e_cat = 'Wasteful Expenditure' ";
        $data['waste_exp_this'] = DB::select($query);



        // Wasteful Expenditure next year

        $query = "SELECT
                e_cat,
                COALESCE(SUM(e_total_amount),0) as ny_total,
                COALESCE(GROUP_CONCAT(id),0) as id
            FROM
                `family_expenditure_next_year`
            WHERE
                family_sub_mst_id = $fm_id AND e_cat = 'Wasteful Expenditure' ";
        $data['waste_exp_next'] = DB::select($query);

        $query = "SELECT
        e_cat,
        COALESCE(SUM(e_total_amount),0) as cy_total,
        COALESCE(GROUP_CONCAT(id),0) as id
        FROM
        `family_expenditure_this_year`
        WHERE
        family_sub_mst_id = $fm_id AND e_cat = 'Production/Business Expenses' ";
        $data['prod_exp_this'] = DB::select($query);

        $query = "SELECT
        e_cat,
        COALESCE(SUM(e_total_amount),0) as ny_total,
        COALESCE(GROUP_CONCAT(id),0) as id
        FROM
        `family_expenditure_next_year`
        WHERE
        family_sub_mst_id = $fm_id AND e_cat = 'Production/Business Expenses' ";
        $data['prod_exp_next'] = DB::select($query);

        $query = "SELECT
                COALESCE(SUM(a.sum), 0) AS saving_total
            FROM
                (
                SELECT
                    a.s_last_saved_amt AS SUM
                FROM
                    family_savings_source AS a
                WHERE
                    a.family_sub_mst_id = $fm_id
                UNION ALL
            SELECT
                b.last_saved_amt AS SUM
            FROM
                family_savings_source_other AS b
            WHERE
                b.family_sub_mst_id = $fm_id
            ) a";

        $data['saving_total'] = DB::select($query);



        $data['fixed_investment'] = DB::table('family_fixed_investment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['goals'] = DB::table('family_goals as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_next_year'] = DB::table('family_income_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_this_year'] = DB::table('family_income_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['fixed_income'] = DB::table('family_other_income_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->where('a.flag', '=', 1)
            ->get()->toArray();

        $income_id = $result[0]->id;

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_this_year` WHERE family_sub_mst_id = $income_id AND flag = 1";
        $data['fixed_income'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_this_year` WHERE family_sub_mst_id = $income_id AND flag = 2";
        $data['casual_income'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_this_year` WHERE family_sub_mst_id = $income_id AND flag = 3";
        $data['trade_income'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_this_year` WHERE family_sub_mst_id = $income_id AND flag = 4";
        $data['pension_income'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_this_year` WHERE family_sub_mst_id = $income_id AND flag = 5";
        $data['other_income'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_next_year` WHERE family_sub_mst_id = $income_id AND flag = 1";
        $data['fixed_income_next'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_next_year` WHERE family_sub_mst_id = $income_id AND flag = 2";
        $data['casual_income_next'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_next_year` WHERE family_sub_mst_id = $income_id AND flag = 3";
        $data['trade_income_next'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_next_year` WHERE family_sub_mst_id = $income_id AND flag = 4";
        $data['pension_income_next'] = DB::select($query);

        $query = "SELECT GROUP_CONCAT(id) as ids FROM `family_other_income_next_year` WHERE family_sub_mst_id = $income_id AND flag = 5";
        $data['other_income_next'] = DB::select($query);

        $data['loan_outstanding_budget'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.family_sub_mst_id as id', DB::raw('SUM(a.current_year_interest) AS cy_value'), DB::raw('SUM(a.lo_next_year) AS ny_value'))
            ->get()->toArray();

        $query = "SELECT lo_next_year FROM family_loan_outstanding WHERE family_sub_mst_id = 78";
        $abcd = DB::select($query);

        $data['loan_outstanding'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $loan_id = $result[0]->id;

        $query = "SELECT SUM(lo_principle_amount)as principle,SUM(overdue)as overdue,SUM(lo_next_year) AS next,SUM(total_paid_interest) as cumulative ,SUM(current_year_interest) as total_paid   FROM `family_loan_outstanding` WHERE family_sub_mst_id = $loan_id";
        $data['loan_total'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next ,COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'SHG Loan' and family_sub_mst_id= $loan_id";
        $data['Shg_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'SHG Loan' and family_sub_mst_id= $loan_id";
        $data['Shg_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next ,COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'Money Lenders Loan' and family_sub_mst_id= $loan_id";
        $data['money_loan'] = DB::select($query);


        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Money Lenders Loan' and family_sub_mst_id= $loan_id";
        $data['money_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next,COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'Bank Loan' and family_sub_mst_id= $loan_id";
        $data['bank_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Bank Loan' and family_sub_mst_id= $loan_id";
        $data['bank_loan_de'] = DB::select($query);

        // prd($data['bank_loan_de']);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next , COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'NBFC Loan' and family_sub_mst_id= $loan_id";
        $data['nbfc_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'NBFC Loan' and family_sub_mst_id= $loan_id";
        $data['nbfc_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next , COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'Cluster Loan' and family_sub_mst_id= $loan_id";
        $data['cluster_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Cluster Loan' and family_sub_mst_id= $loan_id";
        $data['cluster_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next , COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'Federation Loan' and family_sub_mst_id= $loan_id";
        $data['fed_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Federation Loan' and family_sub_mst_id= $loan_id";
        $data['fed_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next , COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'MFI Loan' and family_sub_mst_id= $loan_id";
        $data['mfi_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'MFI Loan' and family_sub_mst_id= $loan_id";
        $data['mfi_loan_de'] = DB::select($query);

        $query = "SELECT COALESCE(GROUP_CONCAT(id),0) as id, COALESCE(SUM(lo_principle_amount),0) as total_principle, COALESCE(SUM(overdue),0) as overdue,COALESCE(SUM(lo_next_year),0) as loan_next , COALESCE(SUM(total_paid_interest),0) as cumulative , COALESCE(SUM(current_year_interest),0) as total_paid FROM family_loan_outstanding where lo_type = 'Other Private Loan' and family_sub_mst_id= $loan_id";
        $data['other_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Other Private Loan' and family_sub_mst_id= $loan_id";
        $data['other_loan_de'] = DB::select($query);
        $cols = ['lo_type', 'lo_principle_amount', 'lo_purpose', 'lo_interest_type', 'lo_interest_rate', 'lo_no_of_tenure', 'lo_start_date', 'lo_last_Repayment_to_paid', 'lo_data_collection_date', 'current_year_principal', 'current_year_interest', 'total_paid_principal', 'total_paid_interest', 'overdue', 'lo_next_year', 'lo_tenure_mode'];
        $indexArr = ['Money Lenders Loan', 'Bank Loan', 'SHG Loan', 'Cluster Loan', 'Federation Loan', 'Other Private Loan', 'VI Loan'];
        $col0 = '';
        $col1 = '';
        $col2 = '';
        $col3 = '';
        $col4 = '';
        $col5 = '';
        $col6 = '';
        $row = [];
        $checkColumns = array_column($data['loan_outstanding'], 'lo_type');

        $nokey = array_diff_key($indexArr, $checkColumns);

        $sum_a = 0;
        for ($colkey = 1; $colkey < count($cols); $colkey++) {
            $colval = array_column($data['loan_outstanding'], $cols[$colkey]);
            foreach ($indexArr as $key11 => $value11) {
                if (in_array($value11, $checkColumns)) {
                    $currentindex = array_search($value11, $checkColumns);
                    $row[$colkey - 1][] = '<td>' . $colval[$currentindex] . '</td>';
                } else {

                    $row[$colkey - 1][] = '<td>-</td>';
                }
            }
        }

        $sum = 0;

        foreach ($row[0] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum += (float) $a;
        }
        $data['sum_1'] = $sum;

        $sum1 = 0;
        foreach ($row[8] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum1 += (float) $a;
        }
        $data['sum_2'] = $sum1;

        $sum3 = 0;
        foreach ($row[9] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum3 += (float) $a;
        }
        $data['sum_3'] = $sum3;

        $sum10 = 0;
        foreach ($row[10] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum10 += (float) $a;
        }
        $data['sum_10'] = $sum10;

        $sum11 = 0;
        foreach ($row[11] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum11 += (float) $a;
        }
        $data['sum_11'] = $sum11;

        $sum12 = 0;
        foreach ($row[12] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum12 += (float) $a;
        }
        $data['sum_12'] = $sum12;

        $sum13 = 0;
        foreach ($row[13] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum13 += (float) $a;
        }
        $data['sum_13'] = $sum13;
        foreach ($row[4] as $key => $value) {

            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $arr14 = str_replace('<td>', '', str_replace('</td>', '', $row[14][$key]));
            $val = "";
            if ($arr14 == 0) {
                $val = "- Months";
            }
            if ($arr14 == 1) {
                $val = "- Year";
            }
            if ($arr14 == "-") {
                $val = "";
            }
            $res = $a . $val;
            $data['loan_mode'][] = $res;
        }

        $data['loan_outstanding_pivot'] = $row;

        $data['loan_repayment'] = DB::table('family_loan_repayment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $loan_repayment = $data['loan_repayment'];
        $data['loan_duration'] = '';
        $data['loan_tenure'] = '';

        if (!empty($loan_repayment[0]->tenure_mode)) {
            if ($loan_repayment[0]->tenure_mode == 1) {
                $data['loan_tenure'] = 12 * $loan_repayment[0]->loan_tenure;
            } else {
                $data['loan_tenure'] = $loan_repayment[0]->loan_tenure;
            }

            if ($loan_repayment[0]->tenure_mode == 1) {
                $data['loan_duration'] = $loan_repayment[0]->loan_tenure . 'Year';
            } else {
                $data['loan_duration'] = $loan_repayment[0]->loan_tenure . 'Month';
            }
        }

        $data['observation_next_year'] = DB::table('family_observation_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['observation_this_year'] = DB::table('family_observation_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $query = "SELECT

                GROUP_CONCAT(
            CASE WHEN husband = 1 THEN 'Husband' ELSE ''
                END,
                IF(wife = 1, ',', ''),
                CASE WHEN wife = 1 THEN 'Wife' ELSE ''
            END,
            IF(son = 1, ',', ''),
            CASE WHEN son = 1 THEN 'Son' ELSE ''
            END,
            IF(daughter = 1, ',', ''),
            CASE WHEN daughter = 1 THEN 'Daughter' ELSE ''
            END,
            IF(other_family_member != '', ',', ''),
            other_family_member
            ) as participate_family
            FROM
                `family_observation_this_year_member`
             where family_sub_mst_id = " . $result[0]->id . " ";
        $data['observation_this_year_member'] = DB::select($query);

        $data['rating'] = DB::table('family_rating as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['savings'] = DB::table('family_savings as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['savings_source'] = DB::table('family_savings_source as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $saving_type = array('Compulsory', 'Voluntary');

        if (count($data['savings_source']) == 0) {
            $arr = array(
                "0" => array('id' => 1, 'family_sub_mst_id' => 1, 's_type' => 'Compulsory', 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 0, 's_last_saved_amt' => 0, 's_total_saving' => 0, 'is_deleted' => '', 'created_at' => '', 'updated_at' => ''),

                "1" => array('id' => 1, 'family_sub_mst_id' => 1, 's_type' => 'Voluntary', 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 0, 's_last_saved_amt' => 0, 's_total_saving' => 0, 'is_deleted' => '', 'created_at' => '', 'updated_at' => ''),
            );
        }

        if (count($data['savings_source']) == 1) {
            $arr = array(
                "0" => array(
                    'id' => $data['savings_source'][0]->id,
                    'family_sub_mst_id' => $data['savings_source'][0]->family_sub_mst_id,
                    's_type' => ($data['savings_source'][0]->s_type == 'Compulsory' ? 'Compulsory' : 'Voluntary'),
                    's_contribute_regular' => ($data['savings_source'][0]->s_contribute_regular != '' ? $data['savings_source'][0]->s_contribute_regular : 'N/A'),
                    's_started_from' => ($data['savings_source'][0]->s_started_from != '' ? $data['savings_source'][0]->s_started_from : 'N/A'),
                    's_saving_per_month' => ($data['savings_source'][0]->s_saving_per_month != '' ? $data['savings_source'][0]->s_saving_per_month : 0),
                    's_last_saved_amt' => ($data['savings_source'][0]->s_last_saved_amt != '' ? $data['savings_source'][0]->s_last_saved_amt : 0),
                    's_total_saving' => ($data['savings_source'][0]->s_total_saving != '' ? $data['savings_source'][0]->s_total_saving : 0),
                    'is_deleted' => $data['savings_source'][0]->is_deleted,
                    'created_at' => $data['savings_source'][0]->created_at,
                    'updated_at' => $data['savings_source'][0]->updated_at,
                ),

                "1" => array('id' => 0, 'family_sub_mst_id' => 0, 's_type' => ($data['savings_source'][0]->s_type == 'Compulsory' ? 'Voluntary' : 'Compulsory'), 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 0, 's_last_saved_amt' => 0, 's_total_saving' => 0, 'is_deleted' => 'N/A', 'created_at' => 'N/A', 'updated_at' => 'N/A'),
            );
        }

        if (count($data['savings_source']) == 2) {
            $arr = array(
                "0" => array('id' => $data['savings_source'][0]->id, 'family_sub_mst_id' => $data['savings_source'][0]->family_sub_mst_id, 's_type' => $data['savings_source'][0]->s_type, 's_contribute_regular' => $data['savings_source'][0]->s_contribute_regular, 's_started_from' => $data['savings_source'][0]->s_started_from, 's_saving_per_month' => $data['savings_source'][0]->s_saving_per_month, 's_last_saved_amt' => $data['savings_source'][0]->s_last_saved_amt, 's_total_saving' => $data['savings_source'][0]->s_total_saving, 'is_deleted' => $data['savings_source'][0]->is_deleted, 'created_at' => $data['savings_source'][0]->created_at, 'updated_at' => $data['savings_source'][0]->updated_at),

                "1" => array('id' => $data['savings_source'][1]->id, 'family_sub_mst_id' => $data['savings_source'][1]->family_sub_mst_id, 's_type' => $data['savings_source'][1]->s_type, 's_contribute_regular' => $data['savings_source'][1]->s_contribute_regular, 's_started_from' => $data['savings_source'][1]->s_started_from, 's_saving_per_month' => $data['savings_source'][1]->s_saving_per_month, 's_last_saved_amt' => $data['savings_source'][1]->s_last_saved_amt, 's_total_saving' => $data['savings_source'][1]->s_total_saving, 'is_deleted' => $data['savings_source'][1]->is_deleted, 'created_at' => $data['savings_source'][1]->created_at, 'updated_at' => $data['savings_source'][1]->updated_at),
            );
        }

        $data['savings_source'] = $arr;

        $data['savings_source_other'] = DB::table('family_savings_source_other as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['shgmember_commitment'] = DB::table('family_shgmember_commitment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_approvel'] = DB::table('family_loan_approvel as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_disbursement'] = DB::table('family_loan_disbursement as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['yearly_operational_expenses'] = DB::table('family_yearly_operational_expenses as a')
            ->groupBy('a.expenses_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.expenses_type', DB::raw('SUM(a.totalamount) AS YearExpense'), DB::raw('group_concat(a.id) AS id'))
            ->orderBy('a.expenses_type', 'ASC')->get()->toArray();

        $data['income_from_business'] = DB::table('family_income_from_business as a')
            ->groupBy('a.income_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.income_type', DB::raw('SUM(a.totalamount) AS YearIncome'), DB::raw('group_concat(a.id) AS id'))
            ->orderBy('a.income_type', 'ASC')->get()->toArray();





        $ID = $result[0]->id;

        //Fixed Assests
        $query_fixed_investment = "select sum(totalamount) as total_fixed_investment from family_fixed_investment where family_sub_mst_id=$ID";
        $result_fixed_investment = DB::select($query_fixed_investment);
        $total_fixed_investment = $result_fixed_investment[0]->total_fixed_investment;
        $data['fixed_assets'] = $total_fixed_investment;

        //1st Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='1st year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);

        //operational cost
        $first_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['first_year_total_salesamts'] = $first_year_total_salesamts;

        //1st year Loan Repayment And 1st Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);

        //1st Year Interest Amount  ---- Interest Repayment
        $first_year_total_interestamts_fyear = 0;
        $first_year_total_loanamts_fyear = 0;
        $data['first_year_total_interestamts_fyear'] = 0;
        $data['first_year_total_loanamts_fyear'] = 0;
        if (!empty($result_Loan_Repayment)) {
            $first_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_fyear;
            $data['first_year_total_interestamts_fyear'] = $first_year_total_interestamts_fyear;
            //1st Year Loan Amount --- Loan Repayment
            $first_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_fyear;
            $data['first_year_total_loanamts_fyear'] = $first_year_total_loanamts_fyear;
        }

        //1st Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='1st year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $first_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //1st Year payable amount= 1st year total loan amount + 1st year total interest amount
        $first_year_payableamt = (float) $first_year_total_interestamts_fyear + (float) $first_year_total_loanamts_fyear;
        $data['first_year_total_incomeamts'] = $first_year_total_incomeamts;

        //1st Year expense amount= total sales amount + total payable amount
        //Profit and Loss 1st Year
        $first_year_expansesamt = $first_year_total_salesamts + $first_year_payableamt; // Total
        $data['first_year_expansesamt'] = $first_year_expansesamt;
        $tv_1profit = $first_year_total_incomeamts - $first_year_expansesamt;
        $data['tv_1profit'] = $tv_1profit;
        if ($tv_1profit > 0) {
            $data['show1'] = 'green_text';
        } else {
            $data['show1'] = 'red_text';
        }

        //2nd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='2nd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $scnd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['scnd_year_total_salesamts'] = $scnd_year_total_salesamts;

        //2nd year Loan Repayment And 2nd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        $scnd_year_total_interestamts_fyear = 0;
        $scnd_year_total_loanamts_fyear = 0;
        $data['scnd_year_total_interestamts_fyear'] = 0;
        $data['scnd_year_total_loanamts_fyear'] = 0;
        if (!empty($result_Loan_Repayment)) {
            //2nd Year Interest Amount  ---- Interest Repayment
            $scnd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_syear;
            $data['scnd_year_total_interestamts_fyear'] = $scnd_year_total_interestamts_fyear;
            //2nd Year Loan Amount --- Loan Repayment
            $scnd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_syear;
            $data['scnd_year_total_loanamts_fyear'] = $scnd_year_total_loanamts_fyear;
        }

        //2nd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='2nd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $scnd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //2nd Year payable amount= 2nd year total loan amount + 2nd year total interest amount
        $scnd_year_payableamt = (float) $scnd_year_total_interestamts_fyear + (float) $scnd_year_total_loanamts_fyear;
        $data['scnd_year_total_incomeamts'] = $scnd_year_total_incomeamts;

        //2nd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 2nd Year
        $scnd_year_expansesamt = $scnd_year_total_salesamts + $scnd_year_payableamt; // Total
        $data['scnd_year_expansesamt'] = $scnd_year_expansesamt;
        $tv_2profit = $scnd_year_total_incomeamts - $scnd_year_expansesamt;
        $data['tv_2profit'] = $tv_2profit;
        if ($tv_2profit > 0) {
            $data['show2'] = 'green_text';
        } else {
            $data['show2'] = 'red_text';
        }

        //3rd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='3rd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $trd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['trd_year_total_salesamts'] = $trd_year_total_salesamts;

        //3rd year Loan Repayment And 3rd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        $trd_year_total_interestamts_fyear = 0;
        $trd_year_total_loanamts_fyear = 0;
        $data['trd_year_total_interestamts_fyear'] = 0;
        $data['trd_year_total_loanamts_fyear'] = 0;
        if (!empty($result_Loan_Repayment)) {
            //3rd Year Interest Amount  ---- Interest Repayment
            $trd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_thyear;
            $data['trd_year_total_interestamts_fyear'] = $trd_year_total_interestamts_fyear;
            //3rd Year Loan Amount --- Loan Repayment
            $trd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_thyear;
            $data['trd_year_total_loanamts_fyear'] = $trd_year_total_loanamts_fyear;
        }
        //3rd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='3rd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $trd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //3rd Year payable amount= 3rd year total loan amount + 3rd year total interest amount
        $trd_year_payableamt = (float) $trd_year_total_interestamts_fyear + (float) $trd_year_total_loanamts_fyear;
        $data['trd_year_total_incomeamts'] = $trd_year_total_incomeamts;

        //3rd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 3rd Year
        $trd_year_expansesamt = $trd_year_total_salesamts + $trd_year_payableamt; // Total
        $data['trd_year_expansesamt'] = $trd_year_expansesamt;
        $tv_3profit = $trd_year_total_incomeamts - $trd_year_expansesamt;
        $data['tv_3profit'] = $tv_3profit;
        if ($tv_3profit > 0) {
            $data['show3'] = 'green_text';
        } else {
            $data['show3'] = 'red_text';
        }

        $query = "SELECT
                a.*,
                b.name ,
                c.fp_member_name
                FROM
                    `family_remarks` AS a
                LEFT JOIN users AS b
                ON
                    a.user_id = b.id
                LEFT JOIN family_profile AS c
                ON
                    a.family_id = c.family_sub_mst_id
                WHERE
                    a.family_id = $ID
                    ORDER BY a.updated_at DESC
                    ";
        $data['remarks'] = DB::select($query);
        $family_id = $ID;


        $analysis =  analysis($family_id);
        $grd_total_cy = $analysis['grand_total_cy'];
        $query = "UPDATE family_profile set analysis_rating= '$grd_total_cy' WHERE family_sub_mst_id=$family_id";
        $result = DB::update($query);


        return view('family.view', compact('family'))->with($data)->with($analysis);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Family  $family
     * @return \Illuminate\Http\Response
     */
    public function edit(Family $family)
    {

        $data['family_profile'] = DB::table('family_profile as y')
            ->select('y.*', 'z.id as id', 'y.id as profile_id')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('z.is_deleted', '=', 0)
            ->where('x.family_mst_id', '=', $family->id)
            ->get()->toArray();
        $data['agency'] = DB::table('agency')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['gender'] = DB::table('mst_gender')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['caste'] = DB::table('mst_caste')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();
        $data['edit'] = 1;
        return view('family.edit', compact('family'))->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Family  $family
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Family $family)
    {
        $view = 'family.edit';

        /* Check post either add or update */
        if ($request->isMethod('PATCH')) {
            try {
                $validation_arr = [
                    'agency_id' => ['required'],
                    'federation_id' => ['required'],
                    'shg_uin' => ['required'],
                    'country' => ['required'],
                    'state' => ['required'],
                    'status' => ['required'],
                    'fp_spouse_name' => ['required'],
                    'fp_village' => ['required'],
                    'fp_member_name' => ['required'],
                ];

                $validator = Validator::make($request->all(), $validation_arr);
                if ($validator->fails()) {
                    return redirect()->back()->withErrors($validator)->withInput();
                }
                $result = DB::transaction(function () use ($request, $family) {

                    $user = Auth::User();
                    if ($request->post('id') > 0) {
                        $family_mst = Family::find($request->post('id'));
                        $family_mst->updated_by = $user->id;
                    } else {

                        return redirect('family')->with(['message' => 'Family id does not exist.']);
                        exit();
                    }
                    $family_mst->status = $request->post('status');
                    $family_mst->federation_uin = $request->post('federation_id');
                    $family_mst->cluster_uin = $request->post('cluster_uin');
                    $family_mst->shg_uin = $request->post('shg_uin');
                    $family_mst->created_by = $user->id;
                    $family_mst->srlm_code = $request->post('srlm_code');
                    $shg_uin = $request->post('shg_uin');
                    $cluster_uin = $request->post('cluster_uin');
                    $federation_uin = $request->post('federation_id');
                    $pid = 0;
                    $family_sub_mst_id = $request->post('family_sub_mst_id');

                    $qry = "SELECT * FROM family_profile WHERE family_sub_mst_id=$family_sub_mst_id";
                    $family_profile_data = DB::select($qry);
                    $family_profile = $family_profile_data[0];

                    $SqlLib = new SqlLibController();
                    $agency = $SqlLib->Agency();

                    $agency_id = $family_mst->agency_id;
                    $nuincd = $family_mst->uin;
                    if ($request->post('cluster_uin') != '') {
                        $qry = "SELECT * FROM fcsnode_mst WHERE uin IN('" . $request->post('shg_uin') . "','" . $request->post('cluster_uin') . "','" . $request->post('federation_id') . "')";
                    } else {
                        $qry = "SELECT * FROM fcsnode_mst WHERE uin IN('" . $request->post('shg_uin') . "','" . $request->post('federation_id') . "')";
                    }
                    $data = DB::select($qry);
                    if (!empty($data)) {
                        foreach ($data as $data2) {
                            $data2 = (array) $data2;
                            if ($data2['uin'] == $shg_uin) {
                                $family_mst->shg_uin = $data2['uin'];
                                $pid = $data2['id'];
                            }

                            if ($data2['uin'] == $cluster_uin) {
                                $family_mst->cluster_uin = $data2['uin'];
                            }

                            if ($data2['uin'] == $federation_uin) {
                                $family_mst->federation_uin = $data2['uin'];
                            }
                        }
                    }

                    $result = $family_mst->save();
                    FcsnodeMst::where([['uin', '=', $nuincd]])->update(['pid' => $pid]);
                    if ($family_mst->id > 0) {
                        $profile_id = $request->post('profile_id');
                        $user_details = FamilyProfile::find($profile_id);
                        $user_details->fp_member_name = $request->post('fp_member_name');
                        $user_details->fp_age = $request->post('fp_age');
                        $user_details->fp_gender = $request->post('fp_gender');
                        $user_details->fp_caste = $request->post('fp_caste');
                        $user_details->fp_contact_no = $request->post('fp_contact_no');
                        $user_details->fp_aadhar_no = $request->post('fp_aadhar_no');
                        $user_details->fp_pan = $request->post('fp_pan');
                        $user_details->fp_spouse_name = $request->post('fp_spouse_name');
                        $user_details->fp_country_id = $request->post('country');
                        $user_details->fp_state_id = $request->post('state');
                        $user_details->fp_district_id = $request->post('district');
                        $user_details->fp_country = getName('countries', 'name', $request->post('country'));
                        $user_details->fp_state = getName('states', 'name', $request->post('state'));
                        $user_details->fp_district = getName('district', 'name', $request->post('district'));
                        $user_details->fp_block = $request->post('fp_block');
                        $user_details->fp_village = $request->post('fp_village');

                        if ($user_details->fp_gender != '') {
                            $query = "select id from mst_gender where gender_slug = '" . $user_details->fp_gender . "' ";
                            $result = DB::select($query);
                            $user_details->fp_gender_c = $result[0]->id;
                        }

                        if ($user_details->fp_caste != '') {
                            $query_caste = "select id from mst_caste where caste_slug = '" . $user_details->fp_caste . "' ";
                            $result_caste = DB::select($query_caste);

                            $result_caste = $result_caste[0]->id;
                        }

                        $user_details->updated_by = $user->id;
                        $user_details->updated_at = date('Y-m-d H:i:s');
                        $result = $user_details->save();
                    }

                    if ($result) {
                        return true;
                    }
                });
                if ($result) {
                    return redirect('family')->with(['message' => 'Family updated successfully.']);
                }
            } catch (\Exception $e) {
                prd($e->getMessage());
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
        }

        return view($view);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Family  $family
     * @return \Illuminate\Http\Response
     */
    public function destroy(Family $family)
    {
        try {
            if ($family->id != '') {
                $user_details = Family::find($family->id);
                $user_details->is_deleted = 1;
                $user_details->save();

                TaskQaAssignment::where('assignment_id', $family->id)->where('assignment_type', 'FM')->update(['is_deleted' => 1]);
                TaskAssignment::where('assignment_id', $family->id)->where('assignment_type', 'FM')->update(['is_deleted' => 1]);
                $data['message'] = 'Family Deleted Successfully';
                echo json_encode($data);
            } else {
                $data['message'] = 'Invalid Request';
                echo json_encode($data);
            }
        } catch (\Exception $e) {
            print_r($e->getMessage());
        }
    }
    public function submaster($family_mst_id, $pid, $nuincd, $agency_id, $Family_Profile)
    {

        //Manage relation of eaech
        $modelnw = new FcsnodeMst();
        $modelnw->pid = $pid;
        $modelnw->uin = $nuincd;
        $modelnw->type = 'I';
        $modelnw->agency_id = $agency_id;
        $modelnw->tkn = substr(md5(mt_rand()), 0, 16);
        $modelnw->created_at = date('Y-m-d H:i:s');
        $modelnw->save();

        $modeln = new FamilySubMst();
        $modeln->family_mst_id = $family_mst_id;
        $modeln->created_at = date('Y-m-d H:i:s');
        $modeln->family_flag = 1;
        $modeln->family_status = 1;
        $modeln->save();
        $family_sub_mst_id = $modeln->id;

        $model_profile = new FamilyProfile();
        $model_profile->family_sub_mst_id = $family_sub_mst_id;
        $model_profile->fp_member_name = (trim($Family_Profile['fp_member_name']));
        $model_profile->fp_age = (int) (trim($Family_Profile['fp_age']));
        $model_profile->fp_gender = (trim($Family_Profile['fp_gender']));
        $model_profile->fp_caste = (trim($Family_Profile['fp_caste']));
        $model_profile->fp_gender_c = (trim($Family_Profile['fp_gender_c']));
        $model_profile->fp_caste_c = (trim($Family_Profile['fp_caste_c']));
        $model_profile->fp_contact_no = (trim($Family_Profile['fp_contact_no']));
        $model_profile->fp_aadhar_no = (trim($Family_Profile['fp_aadhar_no']));
        $model_profile->fp_pan = (trim($Family_Profile['fp_pan']));
        $model_profile->fp_village = (trim($Family_Profile['fp_village']));
        $model_profile->fp_block = (trim($Family_Profile['fp_block']));
        $model_profile->fp_district = (trim($Family_Profile['fp_district']));
        $model_profile->fp_state = (trim($Family_Profile['fp_state']));
        $model_profile->fp_country_id = (trim($Family_Profile['fp_country_id']));
        $model_profile->fp_district_id = (trim($Family_Profile['fp_district_id']));
        $model_profile->fp_state_id = (trim($Family_Profile['fp_state_id']));
        $model_profile->fp_country = (trim($Family_Profile['fp_country']));
        $model_profile->fp_spouse_name = (trim($Family_Profile['fp_spouse_name']));
        $model_profile->created_at = (trim($Family_Profile['created_at']));
        $model_profile->created_by = (trim($Family_Profile['created_by']));
        $model_profile->fp_contact_no = (trim($Family_Profile['fp_contact_no']));
        $model_profile->save();

        $model_concent = new FamilyConcent();
        $model_concent->family_sub_mst_id = $family_sub_mst_id;
        $model_concent->created_at = date('Y-m-d H:i:s');
        $model_concent->save();

        $model_assets = new FamilyAssets();
        $model_assets->family_sub_mst_id = $family_sub_mst_id;
        $model_assets->created_at = date('Y-m-d H:i:s');
        $model_assets->save();

        $model_assets_live_stock = new FamilyAssetsLiveStock();
        $model_assets_live_stock->family_sub_mst_id = $family_sub_mst_id;
        $model_assets_live_stock->created_at = date('Y-m-d H:i:s');
        $model_assets_live_stock->save();

        $model_assets_vehicle = new FamilyAssetsVehicle();
        $model_assets_vehicle->family_sub_mst_id = $family_sub_mst_id;
        $model_assets_vehicle->created_at = date('Y-m-d H:i:s');
        $model_assets_vehicle->save();

        $model_assets_machinery = new FamilyAssetsMachinery();
        $model_assets_machinery->family_sub_mst_id = $family_sub_mst_id;
        $model_assets_machinery->created_at = date('Y-m-d H:i:s');
        $model_assets_machinery->save();

        $model_assets_gadgets = new FamilyAssetsGadgets();
        $model_assets_gadgets->family_sub_mst_id = $family_sub_mst_id;
        $model_assets_gadgets->created_at = date('Y-m-d H:i:s');
        $model_assets_gadgets->save();

        $model_goals = new FamilyGoals();
        $model_goals->family_sub_mst_id = $family_sub_mst_id;
        $model_goals->created_at = date('Y-m-d H:i:s');
        $model_goals->save();

        $model_agriculture_production_this_year = new FamilyAgricultureProductionThisYear();
        $model_agriculture_production_this_year->family_sub_mst_id = $family_sub_mst_id;
        $model_agriculture_production_this_year->created_at = date('Y-m-d H:i:s');
        $model_agriculture_production_this_year->save();

        $model_agriculture_production_next_year = new FamilyAgricultureProductionNextYear();
        $model_agriculture_production_next_year->family_sub_mst_id = $family_sub_mst_id;
        $model_agriculture_production_next_year->created_at = date('Y-m-d H:i:s');
        $model_agriculture_production_next_year->save();

        $model_savings = new FamilySavings();
        $model_savings->family_sub_mst_id = $family_sub_mst_id;
        $model_savings->created_at = date('Y-m-d H:i:s');
        $model_savings->save();

        $model_savings_source = new FamilySavingsSource();
        $model_savings_source->family_sub_mst_id = $family_sub_mst_id;
        $model_savings_source->created_at = date('Y-m-d H:i:s');
        $model_savings_source->save();

        $model_savings_source = new FamilySavingsSourceOther();
        $model_savings_source->family_sub_mst_id = $family_sub_mst_id;
        $model_savings_source->created_at = date('Y-m-d H:i:s');
        $model_savings_source->save();

        $model_loan_outstanding = new FamilyLoanOutstanding();
        $model_loan_outstanding->family_sub_mst_id = $family_sub_mst_id;
        $model_loan_outstanding->created_at = date('Y-m-d H:i:s');
        $model_loan_outstanding->save();

        $model_income_this_year = new FamilyIncomeThisYear();
        $model_income_this_year->family_sub_mst_id = $family_sub_mst_id;
        $model_income_this_year->created_at = date('Y-m-d H:i:s');
        $model_income_this_year->save();

        $model_income_next_year = new FamilyIncomeNextYear();
        $model_income_next_year->family_sub_mst_id = $family_sub_mst_id;
        $model_income_next_year->created_at = date('Y-m-d H:i:s');
        $model_income_next_year->save();

        $model_expenditure_this_year = new FamilyExpenditureThisYear();
        $model_expenditure_this_year->family_sub_mst_id = $family_sub_mst_id;
        $model_expenditure_this_year->created_at = date('Y-m-d H:i:s');
        $model_expenditure_this_year->save();

        $model_expenditure_next_year = new FamilyExpenditureNextYear();
        $model_expenditure_next_year->family_sub_mst_id = $family_sub_mst_id;
        $model_expenditure_next_year->created_at = date('Y-m-d H:i:s');
        $model_expenditure_next_year->save();

        $model_analysis_this_year = new FamilyAnalysisThisYear();
        $model_analysis_this_year->family_sub_mst_id = $family_sub_mst_id;
        $model_analysis_this_year->created_at = date('Y-m-d H:i:s');
        $model_analysis_this_year->save();

        $model_analysis_next_year = new FamilyAnalysisNextYear();
        $model_analysis_next_year->family_sub_mst_id = $family_sub_mst_id;
        $model_analysis_next_year->created_at = date('Y-m-d H:i:s');
        $model_analysis_next_year->save();

        $model_challenges = new FamilyChallenges();
        $model_challenges->family_sub_mst_id = $family_sub_mst_id;
        $model_challenges->created_at = date('Y-m-d H:i:s');
        $model_challenges->save();

        $model_observation_this_year = new FamilyObservationThisYear();
        $model_observation_this_year->family_sub_mst_id = $family_sub_mst_id;
        $model_observation_this_year->created_at = date('Y-m-d H:i:s');
        $model_observation_this_year->save();

        $model_observation_next_year = new FamilyObservationNextYear();
        $model_observation_next_year->family_sub_mst_id = $family_sub_mst_id;
        $model_observation_next_year->created_at = date('Y-m-d H:i:s');
        $model_observation_next_year->save();

        $model_observation_this_year_member = new FamilyObservationThisYearMember();
        $model_observation_this_year_member->family_sub_mst_id = $family_sub_mst_id;
        $model_observation_this_year_member->created_at = date('Y-m-d H:i:s');
        $model_observation_this_year_member->save();

        $model_business_investment_Plan = new FamilyBusinessInvestmentPlan();
        $model_business_investment_Plan->family_sub_mst_id = $family_sub_mst_id;
        $model_business_investment_Plan->created_at = date('Y-m-d H:i:s');
        $model_business_investment_Plan->save();

        $model_shgmember_commitment = new FamilyShgmemberCommitment();
        $model_shgmember_commitment->family_sub_mst_id = $family_sub_mst_id;
        $model_shgmember_commitment->created_at = date('Y-m-d H:i:s');
        $model_shgmember_commitment->save();

        $model_fixed_investment = new FamilyFixedInvestment();
        $model_fixed_investment->family_sub_mst_id = $family_sub_mst_id;
        $model_fixed_investment->created_at = date('Y-m-d H:i:s');
        $model_fixed_investment->save();

        $model_yearly_operational_expenses = new FamilyYearlyOperationalExpenses();
        $model_yearly_operational_expenses->family_sub_mst_id = $family_sub_mst_id;
        $model_yearly_operational_expenses->created_at = date('Y-m-d H:i:s');
        $model_yearly_operational_expenses->save();

        $model_income_from_business = new FamilyIncomeFromBusiness();
        $model_income_from_business->family_sub_mst_id = $family_sub_mst_id;
        $model_income_from_business->created_at = date('Y-m-d H:i:s');
        $model_income_from_business->save();

        $model_loan_repayment = new FamilyLoanRepayment();
        $model_loan_repayment->family_sub_mst_id = $family_sub_mst_id;
        $model_loan_repayment->created_at = date('Y-m-d H:i:s');
        $model_loan_repayment->save();

        $model_rating = new familyLoanDisbursement();
        $model_rating->family_sub_mst_id = $family_sub_mst_id;
        $model_rating->created_at = date('Y-m-d H:i:s');
        $model_rating->save();

        $model_rating = new FamilyLoanApprovel();
        $model_rating->family_sub_mst_id = $family_sub_mst_id;
        $model_rating->created_at = date('Y-m-d H:i:s');
        $model_rating->save();

        $model_rating = new FamilyRating();
        $model_rating->family_sub_mst_id = $family_sub_mst_id;
        $model_rating->rating = json_encode(array());
        $model_rating->created_at = date('Y-m-d H:i:s');
        $model_rating->save();
        return true;
    }

    public function loan_disbursement(Request $request)
    {

        $sub_mst_id = $request->get('id');
        $get_loan = $request->get('glon');
        $loan_date = $request->get('ldte');
        $loan_amount = $request->get('lamt');
        $loan_purpose = $request->get('lpur');
        $loan_mode = $request->get('lmod');
        $loan_duration = $request->get('ldur');
        $loan_installments = $request->get('lint');

        try {
            if ($sub_mst_id > 0) {
                $qry = "SELECT id FROM family_loan_disbursement WHERE family_sub_mst_id=$sub_mst_id";
                $family_profile_data = DB::select($qry);
                $id = $family_profile_data[0]->id;
                $user = Auth::User();
                $user_details = familyLoanDisbursement::find($id);
                $user_details->get_loan = $get_loan;
                $user_details->disbursement_date = $loan_date;
                $user_details->loan_amount = $loan_amount;
                $user_details->loan_purpose = $loan_purpose;
                $user_details->repayment_mode = $loan_mode;
                $user_details->loan_duration = $loan_duration;
                $user_details->no_installments = $loan_installments;
                $user_details->quality_id = $user->id;

                $user_details->save();
                $data['message'] = 'Task Updated successfully';
                $data['result'] = 1;
                echo json_encode($data);
            } else {
                $data['message'] = 'Invalid Request';
                $data['result'] = 0;
                echo json_encode($data);
            }
        } catch (\Exception $e) {
            print_r($e->getMessage());
        }
        exit;
    }
    public function loan_approvel(Request $request)
    {

        $sub_mst_id = $request->get('id');
        $get_verified = $request->get('gver');
        $uloan_amount = $request->get('ulam');
        $uloan_purpose = $request->get('ulpur');
        $uloan_mode = $request->get('ulmod');
        $uloan_duration = $request->get('uldur');

        $uloan_installments = $request->get('ulint');

        try {
            if ($sub_mst_id > 0) {
                $qry = "SELECT id FROM family_loan_approvel WHERE family_sub_mst_id=$sub_mst_id";
                $family_profile_data = DB::select($qry);
                $id = $family_profile_data[0]->id;
                $user = Auth::User();
                $user_details = FamilyLoanApprovel::find($id);
                $user_details->get_verified = $get_verified;
                $user_details->uloan_amount = $uloan_amount;
                $user_details->uloan_purpose = $uloan_purpose;
                $user_details->urepayment_mode = $uloan_mode;
                $user_details->uloan_duration = $uloan_duration;
                $user_details->uloan_installments = $uloan_installments;
                $user_details->manager_id = $user->id;
                $user_details->date = date('d-m-Y');

                $user_details->save();
                $data['message'] = 'Task Updated successfully';
                $data['result'] = 1;
                echo json_encode($data);
            } else {
                $data['message'] = 'Invalid Request';
                $data['result'] = 0;
                echo json_encode($data);
            }
        } catch (\Exception $e) {
            print_r($e->getMessage());
        }
        exit;
    }
    public function exportPDF($family_id)
    {

        $data['pre_url'] = (url()->previous());
        $user = Auth::user();
        $family = family::find($family_id);
        $data['family'] = $family;
        $data['family_ids'] = $family->id;

        $query = "Select id,qa_status from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);

        $ID = $result[0]->id;
        $data['business_investment_plan'] = DB::table('family_business_investment_plan as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $data['family_profile'] = DB::table('family_profile as y')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('y.is_deleted', '=', 0)
            ->where('x.id', '=', $result[0]->id)
            ->get()->toArray();
        $query_1 = "Select b.shgName from shg_mst a inner join shg_sub_mst c on a.id=c.shg_mst_id inner join shg_profile b on c.id=b.shg_sub_mst_id where a.is_deleted=0 and a.uin='$family->shg_uin' ";
        $data['shg_profile'] = DB::select($query_1);

        $query_1 = "Select b.name_of_cluster from cluster_mst a inner join cluster_sub_mst c on a.id=c.cluster_mst_id inner join cluster_profile b on c.id=b.cluster_sub_mst_id where a.is_deleted=0 and a.uin='$family->cluster_uin' ";
        $data['clusterprofile'] = DB::select($query_1);

        $query_2 = "Select b.name_of_federation from federation_mst a inner join federation_sub_mst c on a.id=c.federation_mst_id inner join federation_profile b on c.id=b.federation_sub_mst_id where a.is_deleted=0 and a.uin='$family->federation_uin' ";
        $data['fed_profile'] = DB::select($query_2);

        $data['fixed_investment'] = DB::table('family_fixed_investment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $data['loan_repayment'] = DB::table('family_loan_repayment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        //1st Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='1st year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $first_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['first_year_total_salesamts'] = $first_year_total_salesamts;

        //1st year Loan Repayment And 1st Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //1st Year Interest Amount  ---- Interest Repayment
        $first_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_fyear;
        $data['first_year_total_interestamts_fyear'] = $first_year_total_interestamts_fyear;
        //1st Year Loan Amount --- Loan Repayment
        $first_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_fyear;
        $data['first_year_total_loanamts_fyear'] = $first_year_total_loanamts_fyear;

        //1st Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='1st year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $first_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //1st Year payable amount= 1st year total loan amount + 1st year total interest amount
        $first_year_payableamt = (float) $first_year_total_interestamts_fyear + (float) $first_year_total_loanamts_fyear;
        $data['first_year_total_incomeamts'] = $first_year_total_incomeamts;

        //1st Year expense amount= total sales amount + total payable amount
        //Profit and Loss 1st Year
        $first_year_expansesamt = $first_year_total_salesamts + $first_year_payableamt; // Total
        $data['first_year_expansesamt'] = $first_year_expansesamt;
        $tv_1profit = $first_year_total_incomeamts - $first_year_expansesamt;
        $data['tv_1profit'] = $tv_1profit;
        if ($tv_1profit > 0) {
            $data['show1'] = 'green';
        } else {
            $data['show1'] = 'red';
        }

        //2nd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='2nd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $scnd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['scnd_year_total_salesamts'] = $scnd_year_total_salesamts;

        //2nd year Loan Repayment And 2nd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //2nd Year Interest Amount  ---- Interest Repayment
        $scnd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_syear;
        $data['scnd_year_total_interestamts_fyear'] = $scnd_year_total_interestamts_fyear;
        //2nd Year Loan Amount --- Loan Repayment
        $scnd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_syear;
        $data['scnd_year_total_loanamts_fyear'] = $scnd_year_total_loanamts_fyear;

        //2nd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='2nd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $scnd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //2nd Year payable amount= 2nd year total loan amount + 2nd year total interest amount
        $scnd_year_payableamt = (float) $scnd_year_total_interestamts_fyear + (float) $scnd_year_total_loanamts_fyear;
        $data['scnd_year_total_incomeamts'] = $scnd_year_total_incomeamts;

        //2nd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 2nd Year
        $scnd_year_expansesamt = $scnd_year_total_salesamts + $scnd_year_payableamt; // Total
        $data['scnd_year_expansesamt'] = $scnd_year_expansesamt;
        $tv_2profit = $scnd_year_total_incomeamts - $scnd_year_expansesamt;
        $data['tv_2profit'] = $tv_2profit;
        if ($tv_2profit > 0) {
            $data['show2'] = 'green';
        } else {
            $data['show2'] = 'red';
        }

        //3rd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='3rd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $trd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['trd_year_total_salesamts'] = $trd_year_total_salesamts;

        //3rd year Loan Repayment And 3rd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //3rd Year Interest Amount  ---- Interest Repayment
        $trd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_thyear;
        $data['trd_year_total_interestamts_fyear'] = $trd_year_total_interestamts_fyear;
        //3rd Year Loan Amount --- Loan Repayment
        $trd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_thyear;
        $data['trd_year_total_loanamts_fyear'] = $trd_year_total_loanamts_fyear;

        //3rd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='3rd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $trd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //3rd Year payable amount= 3rd year total loan amount + 3rd year total interest amount
        $trd_year_payableamt = (float) $trd_year_total_interestamts_fyear + (float) $trd_year_total_loanamts_fyear;
        $data['trd_year_total_incomeamts'] = $trd_year_total_incomeamts;

        //3rd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 3rd Year
        $trd_year_expansesamt = $trd_year_total_salesamts + $trd_year_payableamt; // Total
        $data['trd_year_expansesamt'] = $trd_year_expansesamt;
        $tv_3profit = $trd_year_total_incomeamts - $trd_year_expansesamt;
        $data['tv_3profit'] = $tv_3profit;
        if ($tv_3profit > 0) {
            $data['show3'] = 'green';
        } else {
            $data['show3'] = 'red';
        }
        $query = "Select * from family_yearly_operational_expenses where is_deleted=0 and family_sub_mst_id = $ID ORDER BY expenses_type ";
        $data['yearly_operational_expenses'] = DB::select($query);

        $query = "SELECT unit_type,name_of_item,GROUP_CONCAT(ifnull(income_type,'') ORDER BY income_type) as income_type,GROUP_CONCAT(totalamount ORDER BY income_type) as totalamount FROM ( SELECT unit_type,name_of_item,income_type,SUM(totalamount) as totalamount FROM family_income_from_business WHERE family_sub_mst_id=$ID GROUP BY name_of_item,income_type)a GROUP BY name_of_item";
        $data['income_business'] = DB::select($query);

        $query = "SELECT name_of_business,name_of_item,GROUP_CONCAT(expenses_type ORDER BY expenses_type) as expenses_type ,GROUP_CONCAT(totalamount ORDER BY expenses_type) as totalamount FROM ( SELECT name_of_business,name_of_item,expenses_type,SUM(totalamount) as totalamount FROM family_yearly_operational_expenses WHERE family_sub_mst_id=$ID GROUP BY name_of_item,expenses_type)a GROUP BY name_of_item";
        $data['yearly_expenses'] = DB::select($query);

        $query = "SELECT a.qa_status,a.remark FROM task_qa_assignment a WHERE assignment_id = $ID LIMIT 1";
        $data['manager'] = DB::select($query);

        view()->share('data', $data);
        $pdf_doc = PDF::loadView('pdf.familyBusinessplanPdf', $data)->setPaper('a4', 'landscape');
        return $pdf_doc->stream('Family_Business_Plan' . $family->uin . pdf_date() . '.pdf');
    }

    public function export_familyloanPDF($family_id)
    {

        $data['pre_url'] = (url()->previous());
        $user = Auth::user();
        $family = family::find($family_id);
        $data['family'] = $family;
        $data['family_ids'] = $family->id;

        $query = "Select id,qa_status from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);

        $data['family_profile'] = DB::table('family_profile as y')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('y.is_deleted', '=', 0)
            ->where('x.id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_approvel'] = DB::table('family_loan_approvel as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $query = "Select name from users where id = " . $data['loan_approvel'][0]->manager_id . " ";
        $data['manager'] = DB::select($query);

        $data['loan_disbursement'] = DB::table('family_loan_disbursement as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_repayment'] = DB::table('family_loan_repayment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['business_investment_plan'] = DB::table('family_business_investment_plan as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        view()->share('data', $data);
        $pdf_doc = PDF::loadView('pdf.familyloanPdf', $data)->setPaper('a4', 'landscape');
        return $pdf_doc->stream('Family_loan_Details' . $family->uin . '_' . pdf_date() . '.pdf');
    }

    public function family_table(Request $request)
    {

        $data = [];
        $user = Auth::User();
        $user_geo = DB::table('user_location_relation')
            ->where('user_id', $user->id)
            ->where('is_deleted', '=', 0)
            ->orderBy('country_id')
            ->get()->toArray();

        $data = [];
        if ($request->ajax()) {
            $start = (int) $request->post('start');
            $limit = (int) $request->post('length');

            $query = " SELECT
            z.fp_member_name,
            X.id,
            z.created_at,
            Y.uin
                FROM
                    family_mst AS Y
                INNER JOIN family_sub_mst AS X
                ON
                    Y.id = X.family_mst_id
                INNER JOIN family_profile AS z
                ON
                    X.id = z.family_sub_mst_id

                WHERE
                    Y.is_deleted = 0 ";
            if ($user->u_type == 'M') {
                $query .= " AND Y.created_by = $user->id";
            }

            $familys = DB::select($query);
            $total = count($familys);
            $query .= " ORDER BY
                    z.created_at
                DESC
                LIMIT $limit OFFSET $start";
            $familys = DB::select($query);
            foreach ($familys as $family) {

                $row = [];
                $row[] = ++$start;
                $row[] = $family->fp_member_name;
                $row[] = $family->uin;
                $btns = '';
                $data[] = $row;
            }

            $output = array(
                "draw" => $request->post('draw'),
                "recordsTotal" => $total,
                "recordsFiltered" => $total,
                "data" => $data,
            );
            echo json_encode($output);
            exit;
        }
        $data['agency'] = DB::table('agency')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();

        return view('family.add')->with($data);
    }
    public function family_table_two(Request $request)
    {

        $data = [];
        $user = Auth::User();
        $user_geo = DB::table('user_location_relation')
            ->where('user_id', $user->id)
            ->where('is_deleted', '=', 0)
            ->orderBy('country_id')
            ->get()->toArray();
        $data = [];
        if ($request->ajax()) {
            $country = $request->post('country');
            $state = $request->post('state');
            $district = $request->post('district');
            $agency = $request->post('agency_id');
            $federation = $request->post('federation_id');
            $cluster_id = $request->post('cluster_id');
            $shg_id = $request->post('shg_id');
            $start = (int) $request->post('start');
            $limit = (int) $request->post('length');

            $query = " SELECT
            z.fp_member_name,
            X.id,
            Y.uin
                FROM
                    family_mst AS Y
                INNER JOIN family_sub_mst AS X
                ON
                    Y.id = X.family_mst_id
                INNER JOIN family_profile AS z
                ON
                    X.id = z.family_sub_mst_id

                WHERE
                    Y.is_deleted = 0 ";
            if ($user->u_type == 'M') {
                $query .= " AND Y.created_by = $user->id";
            }
            if (!empty($agency)) {
                if (!empty($agency)) {

                    $query .= " AND Y.agency_id = '" . $agency . "' ";
                }

                if (!empty($country)) {

                    $query .= " AND z.fp_country_id = '" . $country . "' ";
                }
                if (!empty($state)) {

                    $query .= " AND z.fp_state_id = '" . $state . "' ";
                }
                if (!empty($district)) {

                    $query .= " AND z.fp_district_id = '" . $district . "' ";
                }
                if (!empty($federation)) {

                    $query .= " AND Y.federation_uin = '" . $federation . "' ";
                }
                if (!empty($cluster_id)) {

                    $query .= " AND Y.cluster_uin = '" . $cluster_id . "' ";
                }
                if (!empty($shg_id)) {

                    $query .= " AND Y.shg_uin = '" . $shg_id . "' ";
                }
            }
            // prd($query);
            $familys = DB::select($query);
            $total = count($familys);

            foreach ($familys as $family) {

                $row = [];
                $row['sn'] = ++$start;

                $row['family_name'] = $family->fp_member_name;
                $row['uin'] = $family->uin;

                $btns = '';

                $data[] = $row;
            }
            $output = array(
                "draw" => $request->post('draw'),
                "recordsTotal" => $total,
                "recordsFiltered" => $total,
                "data" => $data,
            );
            echo json_encode($data);
            exit;
        }

        $data['agency'] = DB::table('agency')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();

        return view('family.add')->with($data);
    }
    public function export_familyConsentPdf($family_id)
    {
        $data['pre_url'] = (url()->previous());
        $user = Auth::user();

        $family = family::find($family_id);
        $data['family'] = $family;
        $query = "Select id,qa_status from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);
        $data['id'] = $result[0]->id;
        $data['mst_id'] = $result[0]->id;
        $data['concent'] = DB::table('family_concent as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $data['profile'] = DB::table('family_mst as a')
            ->where('is_deleted', '=', 0)
            ->where('a.id', '=', $result[0]->id)
            ->get()->toArray();

        view()->share('data', $data);
        $pdf_doc = PDF::loadView('pdf.familyConsentPdf', $data)->setPaper('a4', 'landscape');

        return $pdf_doc->stream('Family_Consent_Form' . $family->uin . '_' . pdf_date() . '.pdf');
    }

    public function family_loan_applicationPdf($family_id)
    {
        $data['pre_url'] = (url()->previous());
        $user = Auth::user();

        $family = family::find($family_id);
        $data['family'] = $family;
        $data['family_ids'] = $family->id;
        $query = "Select id,qa_status from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);

        $id = $result[0]->id;

        $data['family_profile'] = DB::table('family_profile as y')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('y.is_deleted', '=', 0)
            ->where('x.id', '=', $result[0]->id)
            ->get()->toArray();

        $query_1 = "Select b.shgName from shg_mst a inner join shg_sub_mst c on a.id=c.shg_mst_id inner join shg_profile b on c.id=b.shg_sub_mst_id where a.is_deleted=0 and a.uin='$family->shg_uin' ";
        $data['shg_profile'] = DB::select($query_1);

        $query_1 = "Select b.name_of_cluster from cluster_mst a inner join cluster_sub_mst c on a.id=c.cluster_mst_id inner join cluster_profile b on c.id=b.cluster_sub_mst_id where a.is_deleted=0 and a.uin='$family->cluster_uin' ";
        $data['clusterprofile'] = DB::select($query_1);

        $query_2 = "Select b.name_of_federation from federation_mst a inner join federation_sub_mst c on a.id=c.federation_mst_id inner join federation_profile b on c.id=b.federation_sub_mst_id where a.is_deleted=0 and a.uin='$family->federation_uin' ";
        $data['fed_profile'] = DB::select($query_2);

        $query = "Select * from family_agriculture_production_this_year where is_deleted=0 and family_sub_mst_id =$id ";
        $data['agriculture_production_this_year'] = DB::select($query);

        $query = "Select * from family_agriculture_production_next_year where is_deleted=0 and family_sub_mst_id =$id ";
        $data['agriculture_production_next_year'] = DB::select($query);

        $data['shgmember_commitment'] = DB::table('family_shgmember_commitment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets'] = DB::table('family_assets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_gadgets'] = DB::table('family_assets_gadgets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_live_stock'] = DB::table('family_assets_live_stock as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_machinery'] = DB::table('family_assets_machinery as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_vehicle'] = DB::table('family_assets_vehicle as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['business_investment_plan'] = DB::table('family_business_investment_plan as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $challenge_type = array(
            'Describe Action to address the challenge',
            'Who would be responsible for action. Specify name',
            'When would action be completed (date)',
            'Is there any support from project office needed to complete action',
            'What kind of support is needed',
            'Was action completed by expected date (Y/N/NA)',
            'Has action been changed/revised during last visit (Y/N)',
            'Facilitator to fill which is the revised/changed action',
        );

        $data['challenges'] = DB::table('family_challenges as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        foreach ($challenge_type as $key1 => $val) {
            $data['challenges_action'][$key1]['name'] = $val;
            foreach ($data['challenges'] as $key => $val1) {
                $temp = json_decode($val1->ch_actions);
                if (!empty($temp)) {
                    if ($key1 == 0) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_describe_action;
                        continue;
                    }
                    if ($key1 == 1) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_responsible;
                        continue;
                    }
                    if ($key1 == 2) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_action_completed;
                        continue;
                    }
                    if ($key1 == 3) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_SHG_Cluster_complete;
                        continue;
                    }
                    if ($key1 == 4) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_support_needed;
                        continue;
                    }
                    if ($key1 == 5) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_expected_date;
                        continue;
                    }
                    if ($key1 == 6) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_changed_rating;
                        continue;
                    }
                    if ($key1 == 7) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_facilitator;
                        continue;
                    }
                }
            }
        }

        $data['expenditure_next_year'] = DB::table('family_expenditure_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->orderBy('a.e_cat')
            ->get()->toArray();
        $data['expen_next'] = array('Normal Expenditure', 'Social Expenditure', 'Wasteful Expenditure', 'Loan Expenditure');

        $data['expenditure_this_year'] = DB::table('family_expenditure_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->orderBy('a.e_cat')
            ->get()->toArray();

        $data['goals'] = DB::table('family_goals as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_next_year'] = DB::table('family_income_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_this_year'] = DB::table('family_income_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_outstanding_budget'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.family_sub_mst_id as id', DB::raw('SUM(a.current_year_interest) AS cy_value'), DB::raw('SUM(a.lo_next_year) AS ny_value'))
            ->get()->toArray();

        $data['loan_outstanding'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)

            ->get()->toArray();

        $data['loan_repayment'] = DB::table('family_loan_repayment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_from_business'] = DB::table('family_income_from_business as a')
            ->groupBy('a.income_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.income_type', DB::raw('SUM(a.totalamount) AS YearIncome'), DB::raw('group_concat(a.id) AS id'))
            ->orderBy('a.income_type', 'ASC')->get()->toArray();

        $data['analysis_next_year'] = DB::table('family_analysis_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['analysis_this_year'] = DB::table('family_analysis_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['savings'] = DB::table('family_savings as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();
        //  pr($data['savings']);

        $data['savings_source'] = DB::table('family_savings_source as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();

        $data['savings_source_other'] = DB::table('family_savings_source_other as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();

        $query = "SELECT SUM(s_saving_per_month) as saving_amount FROM family_savings_source WHERE family_sub_mst_id=$id AND s_type = 'Voluntary'";
        $data['voluntary_saving'] = DB::select($query);

        $query = "SELECT SUM(s_saving_per_month) as saving_amount FROM family_savings_source WHERE family_sub_mst_id=$id AND s_type = 'Compulsory'";
        $data['compulsory_saving'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_this_year WHERE family_sub_mst_id=$id AND e_cat ='Normal Expenditure'";
        $data['normal_expenditure'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_this_year WHERE family_sub_mst_id=$id AND e_cat ='Social Expenditure'";
        $data['social_expenditure'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_this_year WHERE family_sub_mst_id=$id AND e_cat ='Wasteful Expenditure'";
        $data['wasteful_expenditure'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_next_year WHERE family_sub_mst_id=$id AND e_cat ='Normal Expenditure'";
        $data['normal_expenditure_next'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_next_year WHERE family_sub_mst_id=$id AND e_cat ='Social Expenditure'";
        $data['social_expenditure_next'] = DB::select($query);

        $query = "SELECT SUM(e_total_amount) as e_total_amount FROM family_expenditure_next_year WHERE family_sub_mst_id=$id AND e_cat ='Wasteful Expenditure'";
        $data['wasteful_expenditure_next'] = DB::select($query);

        $query = "SELECT SUM(current_year_interest) as this_year , SUM(lo_next_year) as next_year FROM family_loan_outstanding WHERE family_sub_mst_id=$id";
        $data['loan_expenditure'] = DB::select($query);

        $query = "Select * from family_loan_outstanding where is_deleted=0 and family_sub_mst_id =$id";
        $data['family_loan_outstanding_this'] = DB::select($query);

        $query = "Select * from family_loan_outstanding where is_deleted=0 and family_sub_mst_id =$id";
        $data['family_loan_outstanding'] = DB::select($query);

        $query = "Select * from family_income_from_business where is_deleted=0 and family_sub_mst_id =$id ";
        $data['income_from_business'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding WHERE lo_type = 'SHG Loan' AND family_sub_mst_id = $id";
        $data['shg_loan'] = DB::select($query);

        $data['shg_loan_amount'] = 0;
        $data['shg_overdue'] = 0;
        if (!empty($data['shg_loan'])) {
            $data['shg_loan_amount'] = $data['shg_loan'][0]->lo_principle_amount;
            $data['shg_overdue'] = $data['shg_loan'][0]->overdue;
        }
        $query = "SELECT * FROM family_loan_outstanding WHERE lo_type = 'Bank Loan' AND family_sub_mst_id = $id";
        $data['bank_loan'] = DB::select($query);
        $data['bank_loan_amount'] = 0;
        $data['bank_overdue'] = 0;
        if (!empty($data['bank_loan'])) {
            $data['bank_loan_amount'] = $data['bank_loan'][0]->lo_principle_amount;
            $data['bank_overdue'] = $data['bank_loan'][0]->overdue;
        }

        $query = "SELECT * FROM family_loan_outstanding WHERE lo_type = 'Cluster Loan' AND family_sub_mst_id = $id";
        $data['cluster_loan'] = DB::select($query);

        $data['cluster_loan_amount'] = 0;
        $data['cluster_overdue'] = 0;
        if (!empty($data['cluster_loan'])) {
            $data['cluster_loan_amount'] = $data['cluster_loan'][0]->lo_principle_amount;
            $data['cluster_overdue'] = $data['cluster_loan'][0]->overdue;
        }

        $query = "SELECT * FROM family_loan_outstanding WHERE lo_type = 'Other Private Loan' AND family_sub_mst_id = $id";
        $data['other_loan'] = DB::select($query);

        $data['other_loan_amount'] = 0;
        $data['other_overdue'] = 0;
        if (!empty($data['other_loan'])) {
            $data['other_loan_amount'] = $data['other_loan'][0]->lo_principle_amount;
            $data['other_overdue'] = $data['other_loan'][0]->overdue;
        }

        $query = "SELECT * FROM family_loan_outstanding WHERE lo_type = 'NBFC Loan' AND family_sub_mst_id = $id";
        $data['nbfc_loan'] = DB::select($query);

        $data['nbfc_loan_amount'] = 0;
        $data['nbfc_overdue'] = 0;

        if (!empty($data['nbfc_loan'])) {
            $data['nbfc_loan_amount'] = $data['nbfc_loan'][0]->lo_principle_amount;
            $data['nbfc_overdue'] = $data['nbfc_loan'][0]->overdue;
        }

        $data['loan_outstanding'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();

        $loan_id = $result[0]->id;

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'SHG Loan' and family_sub_mst_id=$loan_id";
        $data['Shg_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Money Lenders Loan' and family_sub_mst_id=$loan_id";
        $data['money_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Bank Loan' and family_sub_mst_id=$loan_id";
        $data['Bank_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'VI Loan' and family_sub_mst_id=$loan_id";
        $data['vi_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Cluster Loan' and family_sub_mst_id=$loan_id";
        $data['cluster_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Federation Loan' and family_sub_mst_id=$loan_id";
        $data['fed_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Other Private Loan' and family_sub_mst_id=$loan_id";
        $data['other_loan'] = DB::select($query);

        $cols = ['lo_type', 'lo_principle_amount', 'lo_purpose', 'lo_interest_type', 'lo_interest_rate', 'lo_no_of_tenure', 'lo_start_date', 'lo_last_Repayment_to_paid', 'lo_data_collection_date', 'current_year_principal', 'current_year_interest', 'total_paid_principal', 'total_paid_interest', 'overdue', 'lo_next_year', 'lo_tenure_mode'];
        $indexArr = ['Money Lenders Loan', 'Bank Loan', 'SHG Loan', 'Cluster Loan', 'Federation Loan', 'Other Private Loan', 'VI Loan'];
        $col0 = '';
        $col1 = '';
        $col2 = '';
        $col3 = '';
        $col4 = '';
        $col5 = '';
        $col6 = '';
        $row = [];
        $checkColumns = array_column($data['loan_outstanding'], 'lo_type');
        $nokey = array_diff_key($indexArr, $checkColumns);
        $sum_a = 0;
        for ($colkey = 1; $colkey < count($cols); $colkey++) {
            $colval = array_column($data['loan_outstanding'], $cols[$colkey]);

            foreach ($indexArr as $key11 => $value11) {

                if (in_array($value11, $checkColumns)) {
                    $currentindex = array_search($value11, $checkColumns);
                    $row[$colkey - 1][] = '<td>' . $colval[$currentindex] . '</td>';
                } else {

                    $row[$colkey - 1][] = '<td>-</td>';
                }
            }
        }

        $sum = 0;
        foreach ($row[0] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum += (float) $a;
        }
        $data['sum_1'] = $sum;

        $sum1 = 0;
        foreach ($row[8] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum1 += (float) $a;
        }
        $data['sum_2'] = $sum1;

        $sum3 = 0;
        foreach ($row[9] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum3 += (float) $a;
        }
        $data['sum_3'] = $sum3;

        $sum10 = 0;
        foreach ($row[10] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum10 += (float) $a;
        }
        $data['sum_10'] = $sum10;

        $sum11 = 0;
        foreach ($row[11] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum11 += (float) $a;
        }
        $data['sum_11'] = $sum11;

        $sum12 = 0;
        foreach ($row[12] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum12 += (float) $a;
        }
        $data['sum_12'] = $sum12;

        $sum13 = 0;
        foreach ($row[13] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));
            $sum13 += (float) $a;
        }
        $data['sum_13'] = $sum13;

        foreach ($row[4] as $key => $value) {

            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $arr14 = str_replace('<td>', '', str_replace('</td>', '', $row[14][$key]));
            $val = "";
            if ($arr14 == 0) {
                $val = "-Months";
            }
            if ($arr14 == 1) {
                $val = "-Year";
            }
            if ($arr14 == "-") {
                $val = "";
            }
            $res = $a . $val;
            $data['loan_mode'][] = $res;
        }

        $data['loan_outstanding_pivot'] = $row;

        $data['t_q_a'] = DB::table('task_qa_assignment as y')
            ->select('qa_status', 'remark', 'created_at')
            ->where('y.assignment_id', '=', $family->id)
            ->where('y.assignment_type', '=', 'FM')
            ->orderBy('id', 'ASC')
            ->get()->toArray();

        $data['observation_next_year'] = DB::table('family_observation_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();

        $data['observation_this_year'] = DB::table('family_observation_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $id)
            ->get()->toArray();

        $query = "SELECT

                GROUP_CONCAT(
            CASE WHEN husband = 1 THEN 'Husband' ELSE ''
                END,
                IF(wife = 1, ',', ''),
                CASE WHEN wife = 1 THEN 'Wife' ELSE ''
            END,
            IF(son = 1, ',', ''),
            CASE WHEN son = 1 THEN 'Son' ELSE ''
            END,
            IF(daughter = 1, ',', ''),
            CASE WHEN daughter = 1 THEN 'Daughter' ELSE ''
            END,
            IF(other_family_member != '', ',', ''),
            other_family_member
            ) as participate_family
            FROM
                `family_observation_this_year_member`
             where family_sub_mst_id = " . $id . " ";
        $data['observation_this_year_member'] = DB::select($query);





        $file_name = $data['family_profile'][0]->fp_member_name;
        $analysis = analysis($family_id);

        $viewData = array_merge($data, $analysis);

        view()->share('viewdata', $viewData);
        $pdf_doc = PDF::loadView('pdf.familyloanApplicationPdf', $viewData)->setPaper('a3', 'landscape');
        return $pdf_doc->stream($file_name . '_' . $family->uin . '_' . pdf_date() . '.pdf');
    }
    public function export(Request $request)
    {

        return Excel::download(new FamilyExport(), 'FamilyExport_' . pdf_date() . '.xlsx');
    }

    public function familyPDF(Request $request)
    {
        $data=[];
        $user = Auth::user();
        $user_geo = DB::table('user_location_relation')
        ->where('user_id', $user->id)
        ->where('is_deleted', '=', 0)
        ->orderBy('country_id')
        ->get()->toArray();
        // ini_set('memory_limit', '256M');
        $query = "SELECT
                *
            FROM
                (
                SELECT
                    z.*,
                    d.agency_name,
                    e.name AS country_name,
                    f.name AS state_name,
                    g.name AS district_name,
                    Y.uin,
                    Y.id AS ids,
                    Y.status,
                    Y.created_at AS created,
                    Y.cluster_uin,
                    h.name_of_federation,
                    b.name_of_cluster,
                    j.shgName,
                    X.status AS family_status,
                    X.analytics,
                    X.rating,
                    X.flag,
                    X.dm_p1,
                    X.dm_p2,
                    X.qa_p1,
                    X.qa_p2,
                    X.qa_r,
                    X.dm_r,
                    X.locked,
                    X.updated_at AS updated,
                    X.family_mst_id
                FROM
                    family_mst AS Y
                INNER JOIN family_sub_mst AS X
                ON
                    Y.id = X.family_mst_id
                INNER JOIN family_profile AS z
                ON
                    X.id = z.family_sub_mst_id
                INNER JOIN shg_mst AS i
                ON
                    i.uin = Y.shg_uin
                INNER JOIN shg_sub_mst AS w
                ON
                    i.id = w.shg_mst_id
                INNER JOIN shg_profile AS j
                ON
                    j.shg_sub_mst_id = w.id
                LEFT JOIN cluster_mst AS a
                ON
                    i.cluster_uin = a.uin
                LEFT JOIN cluster_sub_mst AS v
                ON
                    a.id = v.cluster_mst_id
                LEFT JOIN cluster_profile AS b
                ON
                    b.cluster_sub_mst_id = v.id
                INNER JOIN federation_mst AS c
                ON
                    i.federation_uin = c.uin
                INNER JOIN federation_sub_mst AS u
                ON
                    c.id = u.federation_mst_id
                INNER JOIN federation_profile AS h
                ON
                    h.federation_sub_mst_id = u.id
                INNER JOIN agency AS d
                ON
                    Y.agency_id = d.agency_id
                LEFT JOIN countries AS e
                ON
                    z.fp_country_id = e.id
                LEFT JOIN states AS f
                ON
                    z.fp_state_id = f.id
                LEFT JOIN district AS g
                ON
                    z.fp_district_id = g.id
                WHERE
                    Y.is_deleted = 0";
        if ($user->u_type == 'M') {
            // $query .= " AND (Y.created_by = $user->id OR z.fp_district IN($district_list)) ";
            if($user_geo[0]->district_id == ''){
                $district_list = 0;
            } else{

                $district_list = $user_geo[0]->district_id;
            }

            $state_id = $user_geo[0]->state_id;

            $query .= " AND (CASE WHEN Y.created_by > 1 THEN 1 ELSE 0 END = 1 AND Y.created_by = $user->id AND  Y.is_deleted = 0 )
               OR
            (CASE WHEN Y.created_by < 2 THEN 1 ELSE 0 END = 1 AND (z.fp_district_id IN ($district_list) OR z.fp_state_id = $state_id ) AND  Y.is_deleted = 0)";



        }
        $query .= ") a
            LEFT JOIN(
                SELECT
                    *
                FROM
                    (
                    SELECT
                        assignment_type,
                        assignment_id,
                        SUBSTRING_INDEX(
                            GROUP_CONCAT(user_id
                        ORDER BY
                            id
                        DESC
                            ),
                            ',',
                            1
                        ) AS user_id
                    FROM
                        task_assignment
                    WHERE
                        assignment_type = 'FM'
                    GROUP BY
                        assignment_id
                ) a
            INNER JOIN(
                SELECT
                    b.id,
                    b.name
                FROM
                    users b
                WHERE
                    b.is_deleted = 0 AND b.roles_c = 3
            ) b
            ON
                a.user_id = b.id
            ) b
            ON
                a.ids = b.assignment_id
            ORDER BY
                a.updated
            DESC
                ";


        $data = DB::select($query);
        view()->share('data', $data);
        $pdf_doc = PDF::loadView('pdf.familyDetail', $data)->setPaper('a3', 'landscape');



        return $pdf_doc->stream('Family_PDF_' . pdf_date() . '.pdf');
        return view('pdf.familyDetail')->with($data);

    }

    public function export_mainPDF($family_id)
    {
        $data['pre_url'] = (url()->previous());
        $user = Auth::user();

        $family = family::find($family_id);
        $data['family'] = $family;
        $data['family_ids'] = $family->id;
        $data['uin'] = $family->uin;
        $query = "Select id,qa_status from family_sub_mst where family_mst_id=$family->id";
        $result = DB::select($query);
        $ID = $result[0]->id;

        $data['family_profile'] = DB::table('family_profile as y')
            ->join('family_sub_mst as x', 'y.family_sub_mst_id', '=', 'x.id')
            ->join('family_mst as z', 'z.id', '=', 'x.family_mst_id')
            ->where('y.is_deleted', '=', 0)
            ->where('x.id', '=', $result[0]->id)
            ->get()->toArray();

        $query_1 = "Select b.shgName from shg_mst a inner join shg_sub_mst c on a.id=c.shg_mst_id inner join shg_profile b on c.id=b.shg_sub_mst_id where a.is_deleted=0 and a.uin='$family->shg_uin' ";
        $data['shg_profile'] = DB::select($query_1);

        $query_1 = "Select b.name_of_cluster from cluster_mst a inner join cluster_sub_mst c on a.id=c.cluster_mst_id inner join cluster_profile b on c.id=b.cluster_sub_mst_id where a.is_deleted=0 and a.uin='$family->cluster_uin' ";
        $data['clusterprofile'] = DB::select($query_1);

        $query_2 = "Select b.name_of_federation from federation_mst a inner join federation_sub_mst c on a.id=c.federation_mst_id inner join federation_profile b on c.id=b.federation_sub_mst_id where a.is_deleted=0 and a.uin='$family->federation_uin' ";
        $data['fed_profile'] = DB::select($query_2);

        $query = "SELECT
                    a.crop,
                    a.production_quantity_type,
                    a.no_of_season,
                    a.production_per_year,
                    a.total_sale_value,
                    a.sold_in_year,
                    a.price_per_unit,
                    a.consumption,
                    a.price_per_unit,
                    b.total_sale_value AS total_next
                FROM
                    family_agriculture_production_this_year a
                LEFT JOIN family_agriculture_production_next_year b ON
                    a.family_sub_mst_id = b.family_sub_mst_id AND a.crop = b.crop
                WHERE
                    a.family_sub_mst_id = $ID AND a.production_type = 'Agriculture'
                UNION
                SELECT
                    crop,
                    production_quantity_type,
                    no_of_season,
                    production_per_year,
                    '0' AS total_sale_value,
                    sold_in_year,
                    price_per_unit,
                    consumption,
                    price_per_unit,
                    total_sale_value AS total_next
                FROM
                    family_agriculture_production_next_year
                WHERE
                    family_sub_mst_id = $ID AND production_type = 'Agriculture' AND crop NOT IN(
                    SELECT
                        crop
                    FROM
                        family_agriculture_production_this_year
                    WHERE
                        family_sub_mst_id = $ID AND production_type = 'Agriculture'
                );";

        $data['agriculture'] = DB::select($query);
        $query = "SELECT
                    a.crop,
                    a.production_quantity_type,
                    a.no_of_season,
                    a.production_per_year,
                    a.total_sale_value,
                    a.sold_in_year,
                    a.price_per_unit,
                    a.consumption,
                    a.price_per_unit,
                    b.total_sale_value AS total_next
                FROM
                    family_agriculture_production_this_year a
                LEFT JOIN family_agriculture_production_next_year b ON
                    a.family_sub_mst_id = b.family_sub_mst_id AND a.crop = b.crop
                WHERE
                    a.family_sub_mst_id = $ID AND a.production_type = 'Horticultural'
                UNION
                SELECT
                    crop,
                    production_quantity_type,
                    no_of_season,
                    production_per_year,
                    '0' AS total_sale_value,
                    sold_in_year,
                    price_per_unit,
                    consumption,
                    price_per_unit,
                    total_sale_value AS total_next
                FROM
                    family_agriculture_production_next_year
                WHERE
                    family_sub_mst_id = $ID AND production_type = 'Horticultural' AND crop NOT IN(
                    SELECT
                        crop
                    FROM
                        family_agriculture_production_this_year
                    WHERE
                        family_sub_mst_id = $ID AND production_type = 'Horticultural'
                );";

        $data['horticultural'] = DB::select($query);

        $query = "SELECT
                    a.production_sub_type,
                    a.crop,
                    a.production_quantity_type,
                    a.no_of_season,
                    a.production_per_year,
                    a.total_sale_value,
                    a.sold_in_year,
                    a.price_per_unit,
                    a.consumption,
                    a.price_per_unit,
                    b.total_sale_value AS total_next
                FROM
                    family_agriculture_production_this_year a
                LEFT JOIN family_agriculture_production_next_year b ON
                    a.family_sub_mst_id = b.family_sub_mst_id AND a.crop = b.crop
                WHERE
                    a.family_sub_mst_id = $ID AND a.production_type = 'Live Stock'
                UNION
                SELECT
                    production_sub_type,
                    crop,
                    production_quantity_type,
                    no_of_season,
                    production_per_year,
                    '0' AS total_sale_value,
                    sold_in_year,
                    price_per_unit,
                    consumption,
                    price_per_unit,
                    total_sale_value AS total_next
                FROM
                    family_agriculture_production_next_year
                WHERE
                    family_sub_mst_id = $ID AND production_type = 'Live Stock' AND crop NOT IN(
                    SELECT
                        crop
                    FROM
                        family_agriculture_production_this_year
                    WHERE
                        family_sub_mst_id = $ID AND production_type = 'Live Stock'
                );";

        $data['live'] = DB::select($query);


        $data['family_sub_mst'] = DB::table('family_sub_mst as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets'] = DB::table('family_assets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_gadgets'] = DB::table('family_assets_gadgets as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['assets_live_stock'] = DB::table('family_assets_live_stock as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupBy('a.animal_Types')
            ->get()->toArray();

        $data['assets_machinery'] = DB::table('family_assets_machinery as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupby('a.machinery_Types')
            ->get()->toArray();

        $data['assets_vehicle'] = DB::table('family_assets_vehicle as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->groupBy('a.vehicle_Types')
            ->get()->toArray();

        $data['business_investment_plan'] = DB::table('family_business_investment_plan as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_approvel'] = DB::table('family_loan_approvel as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['gov_program'] = DB::table('family_gov_liveilhood_program as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_disbursement'] = DB::table('family_loan_disbursement as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        $data['family_member_info'] = DB::table('family_member_information as a')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        // prd($data['loan_disbursement']);
        $challenge_type = array(
            // 'Describe Action to address the challenge',
            // 'Who would be responsible for action. Specify name',
            'When would action be completed (date)',
            // 'Is there any support from project office needed to complete action',
            // 'What kind of support is needed',
            // 'Was action completed by expected date (Y/N/NA)',
            // 'Has action been changed/revised during last visit (Y/N)',
            // 'Facilitator to fill which is the revised/changed action',
        );

        $data['challenges'] = DB::table('family_challenges as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        // prd($data['challenges']);
        foreach ($challenge_type as $key1 => $val) {
            $data['challenges_action'][$key1]['name'] = $val;
            foreach ($data['challenges'] as $key => $val1) {
                $temp = json_decode($val1->ch_actions);
                if (!empty($temp)) {

                    if ($key1 == 0) {
                        $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_action_completed != '' ? change_date_month_name_char(str_replace('/', '-', $temp[0]->sa_action_completed)) : 'N/A';
                        $data['challenges_action'][$key1]['action'][$key] = $temp[0]->sa_describe_action;
                        continue;
                    }
                    // if ($key1 == 2) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_action_completed;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                    // if ($key1 == 3) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_SHG_Cluster_complete;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                    // if ($key1 == 4) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_support_needed;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                    // if ($key1 == 5) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_expected_date;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                    // if ($key1 == 6) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_changed_rating;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                    // if ($key1 == 7) {
                    //     $data['challenges_action'][$key1]['ch_actions'][$key] = $temp[0]->sa_facilitator;
                    //     $data['challenges_action'][$key1]['action'][$key] = $val1->challenges;
                    //     continue;
                    // }
                }
            }
        }
        $actionArray = [];
        $dateArray   = [];
        if (!empty($data['challenges_action'][0]['action'])) {
            $actionArray = $data['challenges_action'][0]['action'];
        }
        if (!empty($data['challenges_action'][0]['ch_actions'])) {
            $dateArray = $data['challenges_action'][0]['ch_actions'];
        }

        $resultArray = [];

        foreach ($actionArray as $key => $action) {
            $object = new stdClass();
            $object->action = $action;
            $object->complete_date = $dateArray[$key];
            $resultArray[] = $object;
        }
        $data['actions'] = $resultArray;


        // prd($complete_date);
        $challenge_type = array(
            'Describe Action to address the challenge',
            'Who would be responsible for action. Specify name',
            'When would action be completed (date)',
            'Is there any support from project office needed to complete action',
            'What kind of support is needed',
            // 'Was action completed by expected date (Y/N/NA)',
            // 'Has action been changed/revised during last visit (Y/N)',
            // 'Facilitator to fill which is the revised/changed action',
        );

        $data['challenges'] = DB::table('family_challenges as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();
        foreach ($challenge_type as $key1 => $val) {
            $data['challenges_actions_new'][$key1]['name'] = $val;
            foreach ($data['challenges'] as $key => $val1) {
                $temp = json_decode($val1->ch_actions);
                if (!empty($temp)) {
                    if ($key1 == 0) {
                        $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_describe_action;
                        continue;
                    }
                    if ($key1 == 1) {
                        $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_responsible;
                        continue;
                    }
                    if ($key1 == 2) {
                        $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_action_completed;
                        continue;
                    }
                    if ($key1 == 3) {
                        $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_SHG_Cluster_complete;
                        continue;
                    }
                    if ($key1 == 4) {
                        $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_support_needed;
                        continue;
                    }
                    // if ($key1 == 5) {
                    //     $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_expected_date;
                    //     continue;
                    // }
                    // if ($key1 == 6) {
                    //     $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_changed_rating;
                    //     continue;
                    // }
                    // if ($key1 == 7) {
                    //     $data['challenges_actions_new'][$key1]['ch_actions'][$key] = $temp[0]->sa_facilitator;
                    //     continue;
                    // }
                }
            }
        }
        // prd($data['challenges_actions_new']);


        $data['concent'] = DB::table('family_concent as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        if (!empty($data['concent'][0]->signature_of_facilitatorPic)) {
            if ($data['concent'][0]->signature_of_facilitatorPic != '\"\"') {
                $raw_png1 = implode(array_map('chr', json_decode($data['concent'][0]->signature_of_facilitatorPic)));
                $name1 = 'fac_' . $result[0]->id . '.png';
                $fb1 = fopen('./signature/' . $name1, 'wb');
                fwrite($fb1, $raw_png1);
                $data['concent'][0]->signature_of_facilitatorPic = $name1;
            }

            if ($data['concent'][0]->signature_of_participantPic != '\"\"') {
                $raw_png2 = implode(array_map('chr', json_decode($data['concent'][0]->signature_of_participantPic)));
                $name2 = 'par_' . $result[0]->id . '.png';
                $fb2 = fopen('./signature/' . $name2, 'wb');
                fwrite($fb2, $raw_png2);
                $data['concent'][0]->signature_of_participantPic = $name2;
            }
        }

        // $data['concent'][0]->signature_of_participantPic = '';

        $query = "SELECT * FROM (SELECT
        '1' AS id,
        a.e_type,
        a.e_sub_type,
        a.e_spend_type,
        a.e_amount,
        a.e_total_amount AS total_current,
        b.e_total_amount AS total_next
            FROM
                family_expenditure_this_year a
            INNER JOIN family_expenditure_next_year b ON
                a.family_sub_mst_id = b.family_sub_mst_id AND a.e_type = b.e_type AND a.e_sub_type = b.e_sub_type
            WHERE
                a.family_sub_mst_id = $ID AND a.is_deleted = 0 AND a.e_cat = 'Normal Expenditure' AND(
                    a.e_sub_type != '' AND b.e_sub_type != ''
                )
            UNION
            SELECT
                '2' AS id,
                e_type,
                e_sub_type,
                e_spend_type,
                e_amount,
                e_total_amount AS total_current,
                '0' AS total_next
            FROM
                family_expenditure_this_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND e_sub_type NOT IN(
                SELECT
                    e_sub_type
                FROM
                    family_expenditure_next_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND is_deleted = 0 )
            UNION
            SELECT
                '3' AS id,
                e_type,
                e_sub_type,
                e_spend_type,
                e_amount,
                '0' AS total_current,
                e_total_amount AS total_next
            FROM
                family_expenditure_next_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND e_sub_type NOT IN(
                SELECT
                    e_sub_type
                FROM
                    family_expenditure_this_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND is_deleted = 0))a ORDER BY a.e_type";

        $data['normal_expenditure_first'] = DB::select($query);

        $query = "SELECT * FROM (SELECT
                '4' AS id,
                a.e_type,
                a.e_sub_type,
                a.e_spend_type,
                a.e_amount,
                a.e_total_amount AS total_current,
                b.e_total_amount AS total_next
            FROM
                family_expenditure_this_year a
            INNER JOIN family_expenditure_next_year b ON
                a.family_sub_mst_id = b.family_sub_mst_id AND a.e_type = b.e_type AND a.e_sub_type = b.e_sub_type
            WHERE
                a.family_sub_mst_id = $ID  AND a.e_cat = 'Normal Expenditure' AND a.is_deleted = 0 AND(
                    a.e_sub_type = '' AND b.e_sub_type = ''
                )
            UNION
            SELECT
                '5' AS id,
                e_type,
                e_sub_type,
                e_spend_type,
                e_amount,
                e_total_amount AS total_current,
                '0' AS total_next
            FROM
                family_expenditure_this_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_next_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND is_deleted = 0)
            UNION
            SELECT
                '6' AS id,
                e_type,
                e_sub_type,
                e_spend_type,
                e_amount,
                '0' AS total_current,
                e_total_amount AS total_next
            FROM
                family_expenditure_next_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_this_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Normal Expenditure' AND is_deleted = 0)) a ORDER BY a.e_type";

        $data['normal_expenditure_second'] = DB::select($query);

        $query = "SELECT
                '1' AS id,
                a.e_type,
                a.e_spend_type,
                a.e_amount,
                a.e_total_amount AS total_current,
                b.e_total_amount AS total_next
            FROM
                family_expenditure_this_year a
            INNER JOIN family_expenditure_next_year b ON
                a.family_sub_mst_id = b.family_sub_mst_id AND a.e_type = b.e_type
            WHERE
                a.family_sub_mst_id = $ID AND a.e_cat = 'Social Expenditure' AND a.is_deleted = 0
            UNION
            SELECT
                '2' AS id,
                e_type,

                e_spend_type,
                e_amount,
                e_total_amount AS total_current,
                '0' AS total_next
            FROM
                family_expenditure_this_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Social Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_next_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Social Expenditure' AND is_deleted = 0
            )
            UNION
            SELECT
                '3' AS id,
                e_type,

                e_spend_type,
                e_amount,
                '0' AS total_current,
                e_total_amount AS total_next
            FROM
                family_expenditure_next_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Social Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_this_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Social Expenditure' AND is_deleted = 0
            )";

        $data['social_expenditure'] = DB::select($query);

        $query = "SELECT
                '1' AS id,
                a.e_type,
                a.e_spend_type,
                a.e_amount,
                a.e_total_amount AS total_current,
                b.e_total_amount AS total_next
            FROM
                family_expenditure_this_year a
            INNER JOIN family_expenditure_next_year b ON
                a.family_sub_mst_id = b.family_sub_mst_id AND a.e_type = b.e_type
            WHERE
                a.family_sub_mst_id = $ID AND a.e_cat = 'Wasteful Expenditure' AND a.is_deleted = 0
            UNION
            SELECT
                '2' AS id,
                e_type,

                e_spend_type,
                e_amount,
                e_total_amount AS total_current,
                '0' AS total_next
            FROM
                family_expenditure_this_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Wasteful Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_next_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Wasteful Expenditure' AND is_deleted = 0
            )
            UNION
            SELECT
                '3' AS id,
                e_type,

                e_spend_type,
                e_amount,
                '0' AS total_current,
                e_total_amount AS total_next
            FROM
                family_expenditure_next_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Wasteful Expenditure' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_this_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Wasteful Expenditure' AND is_deleted = 0
            )";

        $data['wasteful_expenditure'] = DB::select($query);

        $query = "SELECT
                '1' AS id,
                a.e_type,
                a.e_spend_type,
                a.e_amount,
                a.e_total_amount AS total_current,
                b.e_total_amount AS total_next
            FROM
                family_expenditure_this_year a
            INNER JOIN family_expenditure_next_year b ON
                a.family_sub_mst_id = b.family_sub_mst_id AND a.e_type = b.e_type
            WHERE
                a.family_sub_mst_id = $ID AND a.e_cat = 'Production/Business Expenses' AND a.is_deleted = 0
            UNION
            SELECT
                '2' AS id,
                e_type,

                e_spend_type,
                e_amount,
                e_total_amount AS total_current,
                '0' AS total_next
            FROM
                family_expenditure_this_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Production/Business Expenses' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_next_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Production/Business Expenses' AND is_deleted = 0
            )
            UNION
            SELECT
                '3' AS id,
                e_type,

                e_spend_type,
                e_amount,
                '0' AS total_current,
                e_total_amount AS total_next
            FROM
                family_expenditure_next_year
            WHERE
                family_sub_mst_id = $ID AND e_cat = 'Production/Business Expenses' AND e_type NOT IN(
                SELECT
                    e_type
                FROM
                    family_expenditure_this_year
                WHERE
                    family_sub_mst_id = $ID AND e_cat = 'Production/Business Expenses' AND is_deleted = 0
            )";

        $data['production_expenditure'] = DB::select($query);

        $query = "SELECT
                a.s_type as type,
                a.s_last_saved_amt AS SUM
            FROM
                family_savings_source AS a
            WHERE
                a.family_sub_mst_id = $ID
            UNION ALL
        SELECT
            b.other_loan as type ,
            b.last_saved_amt AS SUM
        FROM
            family_savings_source_other AS b
        WHERE
            b.family_sub_mst_id = $ID";

        $data['saving_expenditure'] = DB::select($query);
        // prd($data['saving_expenditure']);


        $query = "SELECT *  FROM family_loan_outstanding WHERE is_deleted=0 AND family_sub_mst_id =$ID ORDER BY lo_no_of_tenure ";
        $data['loan_expenditure'] = DB::select($query);

        $data['fixed_investment'] = DB::table('family_fixed_investment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['goals'] = DB::table('family_goals as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_next_year'] = DB::table('family_income_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['income_this_year'] = DB::table('family_income_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_outstanding_budget'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.family_sub_mst_id as id', DB::raw('SUM(a.current_year_interest) AS cy_value'), DB::raw('SUM(a.lo_next_year) AS ny_value'))
            ->get()->toArray();

        $data['loan_outstanding'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $cols = ['lo_type', 'lo_principle_amount', 'lo_purpose', 'lo_interest_type', 'lo_interest_rate', 'lo_no_of_tenure', 'lo_start_date', 'lo_last_Repayment_to_paid', 'lo_data_collection_date', 'current_year_principal', 'current_year_interest', 'total_paid_principal', 'total_paid_interest', 'overdue', 'lo_next_year', 'lo_tenure_mode'];
        $indexArr = ['Money Lenders Loan', 'Bank Loan', 'SHG Loan', 'Cluster Loan', 'Federation Loan', 'Other Private Loan', 'VI Loan'];
        $col0 = '';
        $col1 = '';
        $col2 = '';
        $col3 = '';
        $col4 = '';
        $col5 = '';
        $col6 = '';
        $row = [];
        $checkColumns = array_column($data['loan_outstanding'], 'lo_type');

        $nokey = array_diff_key($indexArr, $checkColumns);
        $sum_a = 0;
        for ($colkey = 1; $colkey < count($cols); $colkey++) {
            $colval = array_column($data['loan_outstanding'], $cols[$colkey]);

            foreach ($indexArr as $key11 => $value11) {

                if (in_array($value11, $checkColumns)) {
                    $currentindex = array_search($value11, $checkColumns);
                    $row[$colkey - 1][] = '<td>' . $colval[$currentindex] . '</td>';
                } else {

                    $row[$colkey - 1][] = '<td>-</td>';
                }
            }
        }

        $sum = 0;
        foreach ($row[0] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum += (float) $a;
        }
        $data['sum_1'] = $sum;

        $sum1 = 0;
        foreach ($row[8] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum1 += (float) $a;
        }
        $data['sum_2'] = $sum1;

        $sum3 = 0;
        foreach ($row[9] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum3 += (float) $a;
        }
        $data['sum_3'] = $sum3;

        $sum10 = 0;
        foreach ($row[10] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum10 += (float) $a;
        }
        $data['sum_10'] = $sum10;

        $sum11 = 0;
        foreach ($row[11] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum11 += (float) $a;
        }
        $data['sum_11'] = $sum11;

        $sum12 = 0;
        foreach ($row[12] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum12 += (float) $a;
        }
        $data['sum_12'] = $sum12;

        $sum13 = 0;
        foreach ($row[13] as $value) {
            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $sum13 += (float) $a;
        }
        $data['sum_13'] = $sum13;

        foreach ($row[4] as $key => $value) {

            $a = str_replace('<td>', '', str_replace('</td>', '', $value));

            $arr14 = str_replace('<td>', '', str_replace('</td>', '', $row[14][$key]));
            $val = "";
            if ($arr14 == 0) {
                $val = "-Months";
            }
            if ($arr14 == 1) {
                $val = "-Year";
            }
            if ($arr14 == "-") {
                $val = "";
            }
            $res = $a . $val;
            $data['loan_mode'][] = $res;
        }

        $data['loan_outstanding_pivot'] = $row;

        $loan_id = $result[0]->id;
        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'SHG Loan' and family_sub_mst_id=$loan_id";
        $data['Shg_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Money Lenders Loan' and family_sub_mst_id=$loan_id";
        $data['money_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Bank Loan' and family_sub_mst_id=$loan_id";
        $data['Bank_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'MFI Loan' and family_sub_mst_id=$loan_id";
        $data['mfi_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'NBFC Loan' and family_sub_mst_id=$loan_id";
        $data['nbfc_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Cluster Loan' and family_sub_mst_id=$loan_id";
        $data['cluster_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Federation Loan' and family_sub_mst_id=$loan_id";
        $data['fed_loan'] = DB::select($query);

        $query = "SELECT * FROM family_loan_outstanding where lo_type = 'Other Private Loan' and family_sub_mst_id=$loan_id";
        $data['other_loan'] = DB::select($query);

        $data['loan_repayment'] = DB::table('family_loan_repayment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['observation_next_year'] = DB::table('family_observation_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['observation_this_year'] = DB::table('family_observation_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $query = "SELECT

            GROUP_CONCAT(
        CASE WHEN husband = 1 THEN 'Husband' ELSE ''
            END,
            IF(wife = 1, ',', ''),
            CASE WHEN wife = 1 THEN 'Wife' ELSE ''
        END,
        IF(son = 1, ',', ''),
        CASE WHEN son = 1 THEN 'Son' ELSE ''
        END,
        IF(daughter = 1, ',', ''),
        CASE WHEN daughter = 1 THEN 'Daughter' ELSE ''
        END,
        IF(other_family_member != '', ',', ''),
        other_family_member
        ) as participate_family
        FROM
            `family_observation_this_year_member`
         where family_sub_mst_id = " . $result[0]->id . " ";
        $data['observation_this_year_member'] = DB::select($query);

        $data['rating'] = DB::table('family_rating as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['savings'] = DB::table('family_savings as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['savings_source'] = DB::table('family_savings_source as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        if (count($data['savings_source']) == 0) {
            $arr = array(
                "0" => array('id' => 1, 'family_sub_mst_id' => 1, 's_type' => 'Compulsory', 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 'N/A', 's_last_saved_amt' => 'N/A', 's_total_saving' => 'N/A', 'is_deleted' => 'N/A', 'created_at' => 'N/A', 'updated_at' => 'N/A'),

                "1" => array('id' => 1, 'family_sub_mst_id' => 1, 's_type' => 'Voluntary', 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 'N/A', 's_last_saved_amt' => 'N/A', 's_total_saving' => 'N/A', 'is_deleted' => 'N/A', 'created_at' => 'N/A', 'updated_at' => 'N/A'),
            );
        }

        if (count($data['savings_source']) == 1) {
            $arr = array(
                "0" => array(
                    'id' => $data['savings_source'][0]->id,
                    'family_sub_mst_id' => $data['savings_source'][0]->family_sub_mst_id,
                    's_type' => ($data['savings_source'][0]->s_type == 'Compulsory' ? 'Compulsory' : 'Voluntary'),
                    's_contribute_regular' => ($data['savings_source'][0]->s_contribute_regular != '' ? $data['savings_source'][0]->s_contribute_regular : 'N/A'),
                    's_started_from' => ($data['savings_source'][0]->s_started_from != '' ? $data['savings_source'][0]->s_started_from : 'N/A'),
                    's_saving_per_month' => ($data['savings_source'][0]->s_saving_per_month != '' ? $data['savings_source'][0]->s_saving_per_month : 0),
                    's_last_saved_amt' => ($data['savings_source'][0]->s_last_saved_amt != '' ? $data['savings_source'][0]->s_last_saved_amt : 0),
                    's_total_saving' => ($data['savings_source'][0]->s_total_saving != '' ? $data['savings_source'][0]->s_total_saving : 0),
                    'is_deleted' => $data['savings_source'][0]->is_deleted,
                    'created_at' => $data['savings_source'][0]->created_at,
                    'updated_at' => $data['savings_source'][0]->updated_at,
                ),

                "1" => array('id' => 0, 'family_sub_mst_id' => 0, 's_type' => ($data['savings_source'][0]->s_type == 'Compulsory' ? 'Voluntary' : 'Compulsory'), 's_contribute_regular' => 'N/A', 's_started_from' => 'N/A', 's_saving_per_month' => 0, 's_last_saved_amt' => 0, 's_total_saving' => 0, 'is_deleted' => 'N/A', 'created_at' => 'N/A', 'updated_at' => 'N/A'),
            );
        }

        if (count($data['savings_source']) == 2) {
            $arr = array(
                "0" => array('id' => $data['savings_source'][0]->id, 'family_sub_mst_id' => $data['savings_source'][0]->family_sub_mst_id, 's_type' => $data['savings_source'][0]->s_type, 's_contribute_regular' => $data['savings_source'][0]->s_contribute_regular, 's_started_from' => $data['savings_source'][0]->s_started_from, 's_saving_per_month' => $data['savings_source'][0]->s_saving_per_month, 's_last_saved_amt' => $data['savings_source'][0]->s_last_saved_amt, 's_total_saving' => $data['savings_source'][0]->s_total_saving, 'is_deleted' => $data['savings_source'][0]->is_deleted, 'created_at' => $data['savings_source'][0]->created_at, 'updated_at' => $data['savings_source'][0]->updated_at),

                "1" => array('id' => $data['savings_source'][1]->id, 'family_sub_mst_id' => $data['savings_source'][1]->family_sub_mst_id, 's_type' => $data['savings_source'][1]->s_type, 's_contribute_regular' => $data['savings_source'][1]->s_contribute_regular, 's_started_from' => $data['savings_source'][1]->s_started_from, 's_saving_per_month' => $data['savings_source'][1]->s_saving_per_month, 's_last_saved_amt' => $data['savings_source'][1]->s_last_saved_amt, 's_total_saving' => $data['savings_source'][1]->s_total_saving, 'is_deleted' => $data['savings_source'][1]->is_deleted, 'created_at' => $data['savings_source'][1]->created_at, 'updated_at' => $data['savings_source'][1]->updated_at),
            );
        }

        $data['savings_source'] = $arr;

        $data['savings_source_other'] = DB::table('family_savings_source_other as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['shgmember_commitment'] = DB::table('family_shgmember_commitment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_approvel'] = DB::table('family_loan_approvel as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['loan_disbursement'] = DB::table('family_loan_disbursement as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['yearly_operational_expenses'] = DB::table('family_yearly_operational_expenses as a')
            ->groupBy('a.expenses_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.expenses_type', DB::raw('SUM(a.totalamount) AS YearExpense'), DB::raw('group_concat(a.id) AS id'))
            ->orderBy('a.expenses_type', 'ASC')->get()->toArray();

        $data['income_from_business'] = DB::table('family_income_from_business as a')
            ->groupBy('a.income_type')
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->select('a.income_type', DB::raw('SUM(a.totalamount) AS YearIncome'), DB::raw('group_concat(a.id) AS id'))
            ->orderBy('a.income_type', 'ASC')->get()->toArray();

        $data['analysis_next_year'] = DB::table('family_analysis_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();

        $data['analysis_this_year'] = DB::table('family_analysis_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $result[0]->id)
            ->get()->toArray();



        //Fixed Assests
        //1st Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='1st year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $first_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['first_year_total_salesamts'] = $first_year_total_salesamts;

        //1st year Loan Repayment And 1st Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //1st Year Interest Amount  ---- Interest Repayment
        $first_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_fyear;
        $data['first_year_total_interestamts_fyear'] = $first_year_total_interestamts_fyear;
        //1st Year Loan Amount --- Loan Repayment
        $first_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_fyear;
        $data['first_year_total_loanamts_fyear'] = $first_year_total_loanamts_fyear;

        //1st Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='1st year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $first_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //1st Year payable amount= 1st year total loan amount + 1st year total interest amount
        $first_year_payableamt = (float) $first_year_total_interestamts_fyear + (float) $first_year_total_loanamts_fyear;
        $data['first_year_total_incomeamts'] = $first_year_total_incomeamts;

        //1st Year expense amount= total sales amount + total payable amount
        //Profit and Loss 1st Year
        $first_year_expansesamt = $first_year_total_salesamts + $first_year_payableamt; // Total
        $data['first_year_expansesamt'] = $first_year_expansesamt;
        $tv_1profit = $first_year_total_incomeamts - $first_year_expansesamt;
        $data['tv_1profit'] = $tv_1profit;
        if ($tv_1profit > 0) {
            $data['show1'] = 'green';
        } else {
            $data['show1'] = 'red';
        }

        //2nd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='2nd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $scnd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['scnd_year_total_salesamts'] = $scnd_year_total_salesamts;

        //2nd year Loan Repayment And 2nd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //2nd Year Interest Amount  ---- Interest Repayment
        $scnd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_syear;
        $data['scnd_year_total_interestamts_fyear'] = $scnd_year_total_interestamts_fyear;
        //2nd Year Loan Amount --- Loan Repayment
        $scnd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_syear;
        $data['scnd_year_total_loanamts_fyear'] = $scnd_year_total_loanamts_fyear;

        //2nd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='2nd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $scnd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //2nd Year payable amount= 2nd year total loan amount + 2nd year total interest amount
        $scnd_year_payableamt = (float) $scnd_year_total_interestamts_fyear + (float) $scnd_year_total_loanamts_fyear;
        $data['scnd_year_total_incomeamts'] = $scnd_year_total_incomeamts;

        //2nd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 2nd Year
        $scnd_year_expansesamt = $scnd_year_total_salesamts + $scnd_year_payableamt; // Total
        $data['scnd_year_expansesamt'] = $scnd_year_expansesamt;
        $tv_2profit = $scnd_year_total_incomeamts - $scnd_year_expansesamt;
        $data['tv_2profit'] = $tv_2profit;
        if ($tv_2profit > 0) {
            $data['show2'] = 'green';
        } else {
            $data['show2'] = 'red';
        }

        //3rd Year Sales Amount
        $query_yearly_expenses = "select sum(totalamount) as total_yearly_expenses from family_yearly_operational_expenses Where expenses_type='3rd year expenses' AND family_sub_mst_id=$ID ";
        $result_yearly_expenses = DB::select($query_yearly_expenses);
        //operational cost
        $trd_year_total_salesamts = $result_yearly_expenses[0]->total_yearly_expenses;
        $data['trd_year_total_salesamts'] = $trd_year_total_salesamts;

        //3rd year Loan Repayment And 3rd Year Interest
        $query_Loan_Repayment = "select * from family_loan_repayment  Where family_sub_mst_id=$ID ";
        $result_Loan_Repayment = DB::select($query_Loan_Repayment);
        //3rd Year Interest Amount  ---- Interest Repayment
        $trd_year_total_interestamts_fyear = $result_Loan_Repayment[0]->total_interest_thyear;
        $data['trd_year_total_interestamts_fyear'] = $trd_year_total_interestamts_fyear;
        //3rd Year Loan Amount --- Loan Repayment
        $trd_year_total_loanamts_fyear = $result_Loan_Repayment[0]->total_loan_thyear;
        $data['trd_year_total_loanamts_fyear'] = $trd_year_total_loanamts_fyear;

        //3rd Year Income --- Income
        $query_Income_From_Business = "select sum(totalamount) as total_Income_From_Business from family_income_from_business Where income_type='3rd year income' AND family_sub_mst_id=$ID ";
        $result_Income_From_Business = DB::select($query_Income_From_Business);
        $trd_year_total_incomeamts = $result_Income_From_Business[0]->total_Income_From_Business;
        //3rd Year payable amount= 3rd year total loan amount + 3rd year total interest amount
        $trd_year_payableamt = (float) $trd_year_total_interestamts_fyear + (float) $trd_year_total_loanamts_fyear;
        $data['trd_year_total_incomeamts'] = $trd_year_total_incomeamts;

        //3rd Year expense amount= total sales amount + total payable amount
        //Profit and Loss 3rd Year
        $trd_year_expansesamt = $trd_year_total_salesamts + $trd_year_payableamt; // Total
        $data['trd_year_expansesamt'] = $trd_year_expansesamt;
        $tv_3profit = $trd_year_total_incomeamts - $trd_year_expansesamt;
        $data['tv_3profit'] = $tv_3profit;
        if ($tv_3profit > 0) {
            $data['show3'] = 'green';
        } else {
            $data['show3'] = 'red';
        }
        $query = "Select * from family_expenditure_this_year where is_deleted=0 and family_sub_mst_id =$ID";
        $data['expenditure_this_year'] = DB::select($query);

        $query = "Select * from family_expenditure_next_year where is_deleted=0 and family_sub_mst_id =$ID";
        $data['expenditure_next_year'] = DB::select($query);

        $query = "Select * from family_loan_outstanding where is_deleted=0 and family_sub_mst_id =$ID";
        $data['family_loan_outstanding'] = DB::select($query);

        $query = "Select * from family_yearly_operational_expenses where is_deleted=0 and family_sub_mst_id = $ID ORDER BY expenses_type";
        $data['yearly_operational_expenses'] = DB::select($query);

        $query = "Select * from family_income_from_business where is_deleted=0 and family_sub_mst_id =$ID ";
        $data['income_from_business'] = DB::select($query);

        $data['t_q_a'] = DB::table('task_qa_assignment as y')
            ->select('qa_status', 'remark', 'created_at')
            ->where('y.assignment_id', '=', $family->id)
            ->where('y.assignment_type', '=', 'FM')
            ->orderBy('id', 'DESC')
            ->get()->toArray();

        $query = "SELECT
                    name_of_item,
                    GROUP_CONCAT(trim(expenses_type) ORDER BY expenses_type) as expenses_type,
                    GROUP_CONCAT(total ORDER BY expenses_type) AS expenses
                FROM
                    (
                    SELECT
                        name_of_item,
                        expenses_type,
                        SUM(totalamount) AS total
                    FROM
                    family_yearly_operational_expenses
                    WHERE
                        family_sub_mst_id = $ID
                    GROUP BY
                        name_of_item,
                        expenses_type
                    ORDER BY
                        expenses_type
                )a
                GROUP BY
                    name_of_item";
        $data['yearly_expenses'] = DB::select($query);

        $query = "SELECT SUM(totalamount) as total_1st FROM family_yearly_operational_expenses WHERE family_sub_mst_id = $ID AND expenses_type = '1st year expenses'";
        $data['total_1st_year_expenses'] = DB::select($query)[0]->total_1st;

        $query = "SELECT SUM(totalamount) as total_2nd FROM family_yearly_operational_expenses WHERE family_sub_mst_id = $ID AND expenses_type = '2nd year expenses'";
        $data['total_2nd_year_expenses'] = DB::select($query)[0]->total_2nd;

        $query = "SELECT SUM(totalamount) as total_3rd FROM family_yearly_operational_expenses WHERE family_sub_mst_id = $ID AND expenses_type = '3rd year expenses'";
        $data['total_3rd_year_expenses'] = DB::select($query)[0]->total_3rd;

        $query = "SELECT
                name_of_item,
                GROUP_CONCAT(trim(income_type) ORDER BY income_type) as income_type,
                GROUP_CONCAT(total ORDER BY income_type) AS income
            FROM
                (
                SELECT
                    name_of_item,
                    income_type,
                    SUM(totalamount) AS total
                FROM
                    family_income_from_business
                WHERE
                    family_sub_mst_id = $ID
                GROUP BY
                    name_of_item,
                    income_type
                ORDER BY
                    income_type
            )a
            GROUP BY
                name_of_item";
        $data['income_business'] = DB::select($query);

        $query = "SELECT SUM(totalamount) as total_1st FROM family_income_from_business WHERE family_sub_mst_id = $ID AND income_type = '1st year income'";
        $data['total_1st_year_income'] = DB::select($query)[0]->total_1st;

        $query = "SELECT SUM(totalamount) as total_2nd FROM family_income_from_business WHERE family_sub_mst_id = $ID AND income_type = '2nd year income'";
        $data['total_2nd_year_income'] = DB::select($query)[0]->total_2nd;

        $query = "SELECT SUM(totalamount) as total_3rd FROM family_income_from_business WHERE family_sub_mst_id = $ID AND income_type = '3rd year income'";
        $data['total_3rd_year_income'] = DB::select($query)[0]->total_3rd;

        $file_name = $data['family_profile'][0]->fp_member_name;


        // normal expenditure total
        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_this_year WHERE family_sub_mst_id = $ID and  e_cat = 'Normal Expenditure'";
        $data['this_year_normal'] = DB::select($query);

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_next_year WHERE family_sub_mst_id = $ID and  e_cat = 'Normal Expenditure'";
        $data['next_year_normal'] = DB::select($query);

        // social expenditure total

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_this_year WHERE family_sub_mst_id = $ID and  e_cat = 'Social Expenditure'";
        $data['this_year_Social'] = DB::select($query);

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_next_year WHERE family_sub_mst_id = $ID and  e_cat = 'Social Expenditure'";
        $data['next_year_Social'] = DB::select($query);

        // wasteful expenditure total

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_this_year WHERE family_sub_mst_id = $ID and  e_cat = 'Wasteful Expenditure'";
        $data['this_year_wasteful'] = DB::select($query);

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_next_year WHERE family_sub_mst_id = $ID and  e_cat = 'Wasteful Expenditure'";
        $data['next_year_wasteful'] = DB::select($query);

        // loan expenditure total

        $query = "SELECT sum(current_year_interest) as loan_this_year , sum(lo_next_year) as loan_next_year FROM family_loan_outstanding where family_sub_mst_id = $ID";

        $data['loan_expensture_total'] = DB::select($query);

        // production expenditure

        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_this_year WHERE family_sub_mst_id = $ID and  e_cat = 'Production/Business Expenses'";
        $data['this_year_production'] = DB::select($query);


        $query = "SELECT sum(e_total_amount) as total FROM family_expenditure_next_year WHERE family_sub_mst_id = $ID and  e_cat = 'Production/Business Expenses'";
        $data['next_year_production'] = DB::select($query);

        // saving expenditure total
        $query = "SELECT SUM(SUM) AS total FROM (SELECT
        a.s_type as type,
        a.s_last_saved_amt AS SUM
        FROM
            family_savings_source AS a
        WHERE
            a.family_sub_mst_id = $ID
        UNION ALL
        SELECT
            b.other_loan as type ,
            b.last_saved_amt AS SUM
        FROM
            family_savings_source_other AS b
        WHERE
            b.family_sub_mst_id = $ID) AS a";

            $data['savings_totals'] = DB::select($query);







        return $data;
    }

    public function export_familyPDF($family_id)
    {

        $data['pre_url'] = (url()->previous());
        $user = Auth::user();

        $data =  $this->export_mainPDF($family_id);
        $file_name = $data['family_profile'][0]->fp_member_name;
        $analysis = analysis($family_id);

        $viewData = array_merge($data, $analysis);

        view()->share('viewdata', $viewData);
        $pdf_doc = PDF::loadView('pdf.familyPdf', $viewData)->setPaper('a3', 'landscape');

        return $pdf_doc->stream($file_name . '_' . $data['uin'] . '_' . pdf_date() . '.pdf');
    }

    public function export_familyDetailCardPDF($family_id)
    {
        $data['pre_url'] = (url()->previous());
        $user = Auth::user();
        $data = $this->export_mainPDF($family_id);
        $analysis = analysis($family_id);

        // $file_name = $data['family_profile'][0]->fp_member_name;
        // view()->share('data', $data);
        // $pdf_doc = PDF::loadView('pdf.familyDetailCardPdf', $data)->setPaper('a3', 'landscape');
        // return $pdf_doc->stream($file_name . '_' . $data['uin'] . '_' . pdf_date() . '.pdf');
        return view('pdf.FamilyDetailsCardsPDF')->with($data)->with($analysis);
    }
    public function export_familyCardPDF($family_id)
    {

        $data['pre_url'] = (url()->previous());
        $user = Auth::user();
        $data = $data = $this->export_mainPDF($family_id);
        $analysis = analysis($family_id);
        $viewData = array_merge($data, $analysis);
        view()->share('viewData', $viewData);
        $pdf_doc = PDF::loadView('pdf.familycardPdf', $viewData)->setPaper('a4', 'landscape');
        return $pdf_doc->stream('Family_Development_Card_' . $data['uin'] . '_' . pdf_date() . '.pdf');
    }



    public function analysis($family_id)
    {

        $data['analysis_this_year'] = DB::table('family_analysis_this_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $family_id)
            ->get()->toArray();

        $data['analysis_next_year'] = DB::table('family_analysis_next_year as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $family_id)
            ->get()->toArray();
        //analysis 1 current year
        $query = "SELECT
                COALESCE(SUM(a.sum),
                0) AS expenditure_this_total
            FROM
                (
                SELECT
                    a.s_type AS TYPE,
                    a.s_last_saved_amt AS SUM
                FROM
                    family_savings_source AS a
                WHERE
                    a.family_sub_mst_id = $family_id
                UNION ALL
            SELECT
                b.other_loan AS TYPE,
                b.last_saved_amt AS SUM
            FROM
                family_savings_source_other AS b
            WHERE
                b.family_sub_mst_id = $family_id
            UNION ALL
            SELECT
                c.e_cat AS TYPE,
                c.e_total_amount AS SUM
            FROM
                family_expenditure_this_year c
            WHERE
                c.family_sub_mst_id = $family_id
            UNION ALL
            SELECT
                d.lo_type AS TYPE,
                d.current_year_interest AS SUM
            FROM
                family_loan_outstanding d
            WHERE
                d.family_sub_mst_id = $family_id
            ) a";
        $data['total_expenditure_this'] = DB::select($query);

        $query = "SELECT
        COALESCE(e_total_amount, 0) AS income
        FROM
            family_income_this_year
        WHERE
            family_sub_mst_id = $family_id";
        $data['total_income_this'] = DB::select($query);



        $total_expenditure = $data['total_expenditure_this'][0]->expenditure_this_total;
        $total_income_this =  $data['total_income_this'][0]->income;





        $count1_cy = '';
        $data['show1_cy'] = '';
        $data['analysis_1_cy'] = '';
        // $ana_this = $data['analysis_this_year'][0]->a_i_e_gap;
        if ($total_income_this > 0 || $total_expenditure > 0) {
            if ($total_income_this > $total_expenditure) {
                $data['analysis_1_cy'] = 5;
                $data['show1_cy'] = 'green';
            } elseif ($total_income_this == $total_expenditure) {
                $data['analysis_1_cy'] = 3;
                $data['show1_cy'] = 'yellow';
            } elseif ($total_income_this < $total_expenditure) {
                $data['analysis_1_cy'] = 0;
                $data['show1_cy'] = 'red';
            }
        }



        $query = "SELECT
            COALESCE(SUM(a.sum),
            0) AS expenditure_next_total
        FROM
            (

        SELECT
            c.e_cat AS TYPE,
            c.e_total_amount AS SUM
        FROM
            family_expenditure_next_year c
        WHERE
            c.family_sub_mst_id = $family_id
        UNION ALL
        SELECT
            d.lo_type AS TYPE,
            d.lo_next_year AS SUM
        FROM
            family_loan_outstanding d
        WHERE
            d.family_sub_mst_id = $family_id
        ) a";
        $data['total_expenditure_next'] = DB::select($query);

        $query = "SELECT
        COALESCE(e_total_amount, 0) AS income
        FROM
            family_income_this_year
        WHERE
            family_sub_mst_id = $family_id";
        $data['total_income_next'] = DB::select($query);

        $total_expenditure_next = $data['total_expenditure_next'][0]->expenditure_next_total;
        $total_income_next =  $data['total_income_next'][0]->income;






        //analysis 1 next year
        $count1_cy = '';
        $data['show1_ny'] = '';
        $data['analysis_1_ny'] = '';
        // $ana_ny = $data['analysis_next_year'][0]->a_i_e_gap;
        if ($total_income_next > 0 || $total_expenditure_next > 0) {
            if ($total_income_next > $total_expenditure_next) {
                $data['analysis_1_ny'] = 5;
                $data['show1_ny'] = 'green';
            } elseif ($total_income_next == $total_expenditure_next) {
                $data['analysis_1_ny'] = 3;
                $data['show1_ny'] = 'yellow';
            } elseif ($total_income_next < $total_expenditure_next) {
                $data['analysis_1_ny'] = 0;
                $data['show1_ny'] = 'red';
            }
        }


        //analysis 2 current year
        $count2_cy = '';
        $data['show2_cy'] = '';
        $data['analysis_2_cy'] = 0;
        $average_2_cy = (float) $data['analysis_this_year'][0]->a_i_e_ratio;

        if ($average_2_cy != 0) {
            $count2_cy = (($average_2_cy <= 80 ? 10 : ($average_2_cy <= 90 ? 7 : ($average_2_cy <= 100 ? 5 : 1))));
            $data['analysis_2_cy'] = $count2_cy;
            $data['show2_cy'] = $average_2_cy <= 80 ? 'green' : ($average_2_cy <= 90 ? 'yellow' : ($average_2_cy <= 100 ? 'grey' : 'red'));
        }

        //analysis 2 next year
        $count2_ny = '';
        $data['show2_ny'] = 0;
        $data['analysis_2_ny'] = '';
        $average_2_ny = (float) $data['analysis_next_year'][0]->a_i_e_ratio;
        if ($average_2_ny != 0) {
            $count2_ny = (($average_2_ny <= 80 ? 10 : ($average_2_ny <= 90 ? 7 : ($average_2_ny <= 100 ? 5 : 1))));
            $data['analysis_2_ny'] = $count2_ny;
            $data['show2_ny'] = $average_2_ny <= 80 ? 'green' : ($average_2_ny <= 90 ? 'yellow' : ($average_2_ny <= 100 ? 'grey' : 'red'));
        }

        //analysis 3 current year
        $count3_cy = '';
        $data['show3_cy'] = '';
        $data['analysis_3_cy'] = '';
        $query = "SELECT * FROM family_savings_source where family_sub_mst_id=$family_id and s_type = 'Compulsory' ";
        $compulsory = DB::select($query);
        if (!empty($compulsory)) {
            if ($compulsory[0]->s_contribute_regular == 'Yes') {
                $save_per_month = $compulsory[0]->s_saving_per_month;
                $expected_amt = $save_per_month * 12;
                $s_last_saved_amt = $compulsory[0]->s_last_saved_amt;
                $average_3_cy = (($s_last_saved_amt / $expected_amt) * 100);
                $data['analysis_3_cy'] = $average_3_cy > 99 ? 10 : ($average_3_cy >= 85 ? 8 : ($average_3_cy >= 75 ? 6 : 2));
                $data['show3_cy'] = $average_3_cy > 99 ? 'green' : ($average_3_cy >= 85 ? 'yellow' : ($average_3_cy >= 75 ? 'grey' : 'red'));
            }
        }





        //analysis 34current year
        $count4_cy = '';
        $data['show4_cy'] = '';
        $data['analysis_4_cy'] = '';
        $quer4 = "SELECT s_contribute_regular FROM family_savings_source where family_sub_mst_id=$family_id and s_type = 'Voluntary' ";
        $average_4_cy = DB::select($quer4);

        if (!empty($average_4_cy)) {
            if ($average_4_cy[0]->s_contribute_regular == 'Yes') {
                $data['analysis_4_cy'] = 2;
                $data['show4_cy'] = 'green';
            } else {
                $data['analysis_4_cy'] = 0;
                $data['show4_cy'] = 'red';
            }
        }

        //analysis 35current year
        $count_other = '';
        $data['show_other'] = '';
        $data['analysis_other'] = 0;
        $query = "SELECT other_amount FROM family_savings_source_other where family_sub_mst_id=$family_id  ";
        $average_other = DB::select($query);

        if (!empty($average_other)) {
            $count_other = $average_other[0]->other_amount != '' ? 5 : 0;
            if ($average_other[0]->other_amount != '') {
                $data['analysis_other'] = 2;
                $data['show_other'] = 'green';
            } else {
                $data['analysis_other'] = 0;
                $data['show_other'] = 'red';
            }
        }

        $query = "SELECT
                COALESCE(SUM(a.sum), 0) AS saving_total
            FROM
                (
                SELECT
                    a.s_last_saved_amt AS SUM
                FROM
                    family_savings_source AS a
                WHERE
                    a.family_sub_mst_id = $family_id
                UNION ALL
            SELECT
                b.last_saved_amt AS SUM
            FROM
                family_savings_source_other AS b
            WHERE
                b.family_sub_mst_id = $family_id
            ) a";

        $data['saving_total'] = DB::select($query);

        //analysis 5 current year

        $saving_total = $data['saving_total'][0]->saving_total;


        $count5_cy = '';
        $data['show5_cy'] = '';
        $data['analysis_5_cy'] = '';
        $average_5_cy = '';
        if ($saving_total > 0 && $total_income_this > 0) {
            $average_5_cy = (float) (($saving_total / $total_income_this) * 100);
        }


        if ($average_5_cy != '') {
            $data['analysis_5_cy'] = (($average_5_cy >= 10 ? 8 : ($average_5_cy >= 5 ? 7 : ($average_5_cy >= 2 ? 5 : 2))));

            $data['show5_cy'] = (($average_5_cy >= 10 ? 'green' : ($average_5_cy >= 5 ? 'yellow' : ($average_5_cy >= 2 ? 'grey' : 'red'))));
        }


        //analysis 5 next year
        $count5_ny = '';
        $data['show5_ny'] = '';
        $data['analysis_5_ny'] = '';
        $average_5_ny = '';
        if ($saving_total > 0 && $total_income_next > 0) {
            $average_5_ny = (float) (($saving_total / $total_income_next) * 100);
        }
        if ($average_5_ny != '') {
            $data['analysis_5_ny'] = (($average_5_ny >= 10 ? 8 : ($average_5_ny >= 5 ? 7 : ($average_5_ny >= 2 ? 5 : 2))));

            $data['show5_ny'] = (($average_5_ny >= 10 ? 'green' : ($average_5_ny >= 5 ? 'yellow' : ($average_5_ny >= 2 ? 'grey' : 'red'))));
        }


        //analysis 6 current year
        $data['savings'] = DB::table('family_savings as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $family_id)
            ->get()->toArray();
        $count6_cy = '';
        $data['show6_cy'] = '';
        $data['analysis_6_cy'] = '';
        $average_6_cy = $data['savings'][0]->s_passbook_physically;
        if ($average_6_cy != '') {
            if ($average_6_cy == 1) {
                $data['analysis_6_cy'] = 1;
                $data['show6_cy'] = 'green';
            } else {
                $data['analysis_6_cy'] = 0;
                $data['show6_cy'] = 'red';
            }
        }

        //analysis 7 current year
        $count7_cy = '';
        $data['show7_cy'] = '';
        $data['analysis_7_cy'] = '';
        $average_7_cy = $data['analysis_this_year'][0]->a_alr_i_ratio;

        if ($average_7_cy != '') {
            $count7_cy = (($average_7_cy <= 25 ? 10 : ($average_7_cy <= 35 ? 7 : ($average_7_cy <= 50 ? 5 : ($average_7_cy > 50 ? 2 : 0)))));

            $data['analysis_7_cy'] = $count7_cy;
            if ($average_7_cy <= 25) {
                $data['show7_cy'] = 'green';
            } else if ($average_7_cy >= 26 && $average_7_cy <= 35) {
                $data['show7_cy'] = 'yellow';
            } else if ($average_7_cy >= 36 && $average_7_cy <= 50) {
                $data['show7_cy'] = 'grey';
            } else if ($average_7_cy > 50) {
                $data['show7_cy'] = 'red';
            }
        }
        //analysis 7 next year
        $count7_ny = '';
        $data['show7_ny'] = '';
        $data['analysis_7_ny'] = '';
        $average_7_ny = $data['analysis_next_year'][0]->a_alr_i_ratio;
        if ($average_7_ny != '') {
            $count7_ny = (($average_7_ny <= 25 ? 10 : ($average_7_ny <= 35 ? 7 : ($average_7_ny <= 50 ? 5 : ($average_7_ny > 50 ? 2 : 0)))));
            $data['analysis_7_ny'] = $count7_ny;
            if ($average_7_ny <= 30) {
                $data['show7_ny'] = 'green';
            } else if ($average_7_ny >= 31 && $average_7_ny <= 40) {
                $data['show7_ny'] = 'yellow';
            } else if ($average_7_ny >= 41 && $average_7_ny <= 50) {
                $data['show7_ny'] = 'grey';
            } else if ($average_7_ny > 50) {
                $data['show7_ny'] = 'red';
            }
        }

        //analysis 8 current year
        $count8_cy = '';
        $data['show8_cy'] = '';
        $data['analysis_8_cy'] = '';
        $average_8_cy = (float) $data['analysis_this_year'][0]->a_debit_ratio;
        if ($average_8_cy != '') {
            $count8_cy = (($average_8_cy >= 1.25 ? 10 : ($average_8_cy >= 1.00 ? 7 : ($average_8_cy >= 0.5 ? 3 : 0))));
            $data['analysis_8_cy'] = $count8_cy;

            if ($average_8_cy >= 1.25) {
                $data['show8_cy'] = 'green';
            } else if ($average_8_cy >= 1 && $average_8_cy < 1.25) {
                $data['show8_cy'] = 'yellow';
            } else if ($average_8_cy >= 0.5 && $average_8_cy <= 0.99) {
                $data['show8_cy'] = 'grey';
            } else if ($average_8_cy < 0.5) {
                $data['show8_cy'] = 'red';
            }
        }
        //analysis 8 next year
        $count8_ny = '';
        $data['show8_ny'] = '';
        $data['analysis_8_ny'] = '';
        $average_8_ny = (float) $data['analysis_next_year'][0]->a_debit_ratio;

        if ($average_8_ny != '') {
            $count8_ny = (($average_8_ny >= 1.25 ? 10 : ($average_8_ny >= 1.00 ? 7 : ($average_8_ny >= 0.5 ? 3 : 0))));

            $data['analysis_8_ny'] = $count8_ny;

            if ($average_8_ny >= 1.25) {
                $data['show8_ny'] = 'green';
            } else if ($average_8_ny >= 1 && $average_8_ny <= 1.24) {
                $data['show8_ny'] = 'yellow';
            } else if ($average_8_ny >= 0.5 && $average_8_ny <= 0.99) {
                $data['show8_ny'] = 'grey';
            } else if ($average_8_ny < 0.5) {
                $data['show8_ny'] = 'red';
            }
        }

        //analysis 9 current year
        $data['loan_outstanding'] = DB::table('family_loan_outstanding as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $family_id)
            ->get()->toArray();
        $count9_cy = '';
        $data['show9_cy'] = '';
        $data['analysis_9_cy'] = 0;
        $sum_overdue_cy = 0;
        $sum_emi_cy = 0;
        foreach ($data['loan_outstanding'] as $row) {

            if ($row->lo_type == 'SHG Loan' && $row->overdue != '') {

                $sum_overdue_cy = $sum_overdue_cy + $row->overdue;
                $sum_emi_cy = $sum_emi_cy + $row->monthly_emi;
            }
            if ($row->lo_type == '' && $row->overdue == '') {
                $sum_overdue_cy = '';
                $sum_emi_cy = '';
            }
        }

        if ($sum_overdue_cy != '' || $sum_emi_cy != '') {
            if ($sum_emi_cy > 0) {
                $average_9_cy = round(($sum_overdue_cy / $sum_emi_cy), 2);

                $count9_cy = (($average_9_cy < 1 ? 5 : ($average_9_cy < 2 ? 3 : ($average_9_cy <= 4 ? 1 : 0))));

                $data['show9_cy'] = (($count9_cy == 5 ? 'green' : ($count9_cy == 3 ? 'yellow' : ($count9_cy == 1 ? 'grey' : 'red'))));
                $data['analysis_9_cy'] = $count9_cy;
            } else {
                $data['analysis_9_cy'] = 5;
                $data['show9_cy'] = 'green';
            }
        } else {
            $data['analysis_9_cy'] = 5;
            $data['show9_cy'] = 'green';
        }

        $query = "SELECT fp_wealth_rank FROM family_profile where family_sub_mst_id = $family_id";
        $wealth_rank = DB::select($query)[0]->fp_wealth_rank;

        //analysis 10 current year
        $count10_cy = '';
        $data['show10_cy'] = '';
        $data['analysis_10_cy'] = '';
        // if (!empty($wealth_rank)) {
        //     $data['analysis_10_cy'] = 10;
        // }
        $sum_emi_money = 0;
        $sum_overdue_money = 0;
        $num = 0;
        $no_of_days = 0;

        if (!empty($data['loan_outstanding'])) {



            foreach ($data['loan_outstanding'] as $row) {
                if ($row->lo_type == 'SHG Loan') {

                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }

                if ($row->lo_type == 'Money Lenders Loan') {
                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }
                if ($row->lo_type == 'Bank Loan') {
                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }
                if ($row->lo_type == 'Federation Loan') {
                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }
                if ($row->lo_type == 'Cluster Loan') {
                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }
                if ($row->lo_type == 'Other Private Loan') {
                    $num = $num + 1;
                    $sum_overdue_money = $sum_overdue_money + ($row->overdue != '' ? $row->overdue : 0);
                    $sum_emi_money = $sum_emi_money + $row->monthly_emi;
                    $no_of_days =    $no_of_days + ($row->overdue / $row->monthly_emi);
                }
            }
            if (!empty($no_of_days)) {
                $average_10_cy = $no_of_days * 30;
                $data['analysis_10_cy'] = (($average_10_cy <= 30 ? 20 : ($average_10_cy <= 60 ? 12 : ($average_10_cy <= 120 ? 6 : 2))));
                $data['show10_cy'] = (($average_10_cy <= 30 ? 'green' : ($average_10_cy <= 60 ? 'yellow' : ($average_10_cy <= 120 ? 'grey' : 'red'))));
            }
        }








        //analysis 11 current year
        $count11_cy = '';
        $data['show11_cy'] = '';
        $data['analysis_11_cy'] = '';
        $average_11_cy = $data['analysis_this_year'][0]->family_indebtedness;
        if ($average_11_cy != '') {
            $count11_cy = (($average_11_cy < 20 ? 10 : ($average_11_cy <= 40 ? 7 : ($average_11_cy <= 50 ? 3 : 0))));
            $data['analysis_11_cy'] = $count11_cy;
            if ($average_11_cy < 20) {
                $data['show11_cy'] = 'green';
            } else if ($average_11_cy >= 20 && $average_11_cy <= 40) {
                $data['show11_cy'] = 'yellow';
            } else if ($average_11_cy >= 41 && $average_11_cy <= 50) {
                $data['show11_cy'] = 'grey';
            } else if ($average_11_cy > 50) {
                $data['show11_cy'] = 'red';
            }
        }

        //analysis 12 current year
        $data['shgmember_commitment'] = DB::table('family_shgmember_commitment as a')
            ->where('is_deleted', '=', 0)
            ->where('a.family_sub_mst_id', '=', $family_id)
            ->get()->toArray();
        $count12_ny = '';
        $data['show12_ny'] = '';
        $data['analysis_12_ny'] = '';
        $average_12_ny = $data['shgmember_commitment'][0]->yo_meeting_yes_no;
        if ($average_12_ny != '') {
            $count12_ny = ($average_12_ny == 'Yes' ? 10 : 0);
            $data['analysis_12_ny'] = $count12_ny;
            $x12_ny = ($data['analysis_12_ny'] * 100) / 10;
            $data['show12_ny'] = $x12_ny >= 90 ? 'green' : ($x12_ny >= 75 ? 'yellow' : ($x12_ny >= 60 ? 'grey' : 'red'));
        }

        //analysis 13 next year
        $count13_ny = '';
        $data['show13_ny'] = '';
        $data['analysis_13_ny'] = '';
        $average_13_ny = $data['shgmember_commitment'][0]->yo_member_aware_categories;
        if ($average_13_ny != '') {
            $count13_ny = $average_13_ny == "Strong" ? 2 : ($average_13_ny == "Average" ? 1 : ($average_13_ny == "Weak" ? 0 : 0));
            $data['analysis_13_ny'] = $count13_ny;
            $x13_ny = ((int) $data['analysis_13_ny'] * 100) / 2;
            $data['show13_ny'] = $x13_ny >= 90 ? 'green' : ($x13_ny >= 75 ? 'yellow' : ($x13_ny >= 60 ? 'grey' : 'red'));
        }

        //total 4th
        $data['total_ny4'] = (float) $data['analysis_12_ny'] + (float) $data['analysis_13_ny'];
        $x2_ny = ((int) $data['total_ny4'] * 100) / 12;
        $data['score3'] = $x2_ny;
        $data['show_ny4'] = $x2_ny >= 90 ? 'green' : ($x2_ny >= 75 ? 'yellow' : ($x2_ny >= 60 ? 'grey' : 'red'));

        $data['total_cy1'] = (float) $data['analysis_1_cy'] + (float) $data['analysis_2_cy'];
        $data['score'] = ((int) $data['total_cy1'] * 100) / 15;

        $data['total_cy2'] = (int)$data['analysis_3_cy'] + (int)$data['analysis_4_cy'] + (int)$data['analysis_other'] + (int)$data['analysis_5_cy'] + (int)$data['analysis_6_cy'];
        $data['score1'] = ((int) $data['total_cy2'] * 100) / 23;

        $data['total_cy3'] = (int)$data['analysis_7_cy'] + (int)$data['analysis_8_cy']  + (int)$data['analysis_10_cy'] + (int)$data['analysis_11_cy'];
        $data['score2'] = ((int) $data['total_cy3'] * 100) / 50;

        $data['total_cy4'] = (int) $data['analysis_12_ny'] + (float) $data['analysis_13_ny'];
        $data['score3'] = ((int) $data['total_cy4'] * 100) / 12;

        $data['grand_total_cy'] =
            (float) $data['analysis_1_cy']
            + (float) $data['analysis_2_cy']
            + (int) $data['analysis_3_cy']
            + (int) $data['analysis_4_cy']
            + (int) $data['analysis_other']
            + (int) $data['analysis_5_cy']
            + (int) $data['analysis_6_cy']
            + (int) $data['analysis_7_cy']
            + (int) $data['analysis_8_cy']
            + (int) $data['analysis_10_cy']
            + (int) $data['analysis_11_cy']
            + (int) $data['analysis_12_ny']
            + (float) $data['analysis_13_ny'];

        $data['grand_total_ny'] =
            (float) $data['analysis_1_ny']
            + (float) $data['analysis_2_ny']
            + (int) $data['analysis_5_ny']
            + (int)$data['analysis_7_ny']
            + (int)$data['analysis_8_ny']
            + (int)$data['analysis_12_ny'];

        $total_grd = ($data['grand_total_cy'] * 100) / 100;

        $data['grdcolor'] = $total_grd >= 90 ? 'green' : ($total_grd >= 75 ? 'yellow' : ($total_grd >= 60 ? 'grey' : 'red'));

        // $data['show_final_status'] = $grdcolor == 'green' ? 'Minimal Risk' : ($grdcolor == 'yellow' ? ' Low Risk' : ($grdcolor == 'grey' ? 'Moderate Risk' : 'High Risk'));

        $data['show_final_status'] = $data['grdcolor'] == 'green' ? 'Minimal Risk' : ($data['grdcolor'] == 'yellow' ? ' Low Risk' : ($data['grdcolor'] == 'grey' ? 'Moderate Risk' : 'High Risk'));

        return $data;
    }

    public function check_family_member(Request $request){
        $name = $request->get('inputValue');
        // $fed_id = $request->get('fed_id');
        $res = DB::table('family_profile')
        ->where('fp_member_name', $name)
        ->where('is_deleted', 0)
        ->get();
        $total = $res->count();
        echo $total;

    }

    public function check_family_spouse(Request $request){
        $name = $request->get('inputValue');
        // $fed_id = $request->get('fed_id');
        // $res = DB::table('family_profile')
        // ->where('fp_contact_no', $name)
        // ->where('is_deleted', 0)
        // ->get();
        $res = DB::table('family_mst as a')
        ->join('family_sub_mst as b','a.id','=','b.family_mst_id')
        ->join('family_profile as c','b.family_mst_id','=','c.family_sub_mst_id')
        ->where('c.fp_contact_no', $name)
        ->where('a.is_deleted', 0)
        ->get();

        $total = $res->count();
        echo $total;

    }

    public function getLatLongFamily(Request $request)
    {

        $data = [];
        if ($request->post('filter') == 'Search') {
            $federation = $request->input('federation');
            // prd($federation);
            $dateArr = array('federation' => $federation);
            Session::put('family_session', $request->all());
        }
        if (!empty($request->post('filter') == 'clear')) {
            $request->session()->forget('family_session');
        }


        if ($request->ajax()) {
            $session_data = Session::get('family_session');


            $query = " SELECT
            z.latitude,
            z.longitude,
            z.location_name,
            z.lat_long_date_time,
            z.fp_member_name,
            z.fp_village,
            j.shgName,
            ur.name,
            d.agency_name

        FROM
            family_mst AS Y
        INNER JOIN family_sub_mst AS X
        ON
            Y.id = X.family_mst_id
        INNER JOIN family_profile AS z
        ON
            X.id = z.family_sub_mst_id
        INNER JOIN shg_mst AS i
        ON
            i.uin = Y.shg_uin
        INNER JOIN shg_sub_mst AS w
        ON
            i.id = w.shg_mst_id
        INNER JOIN shg_profile AS j
        ON
            j.shg_sub_mst_id = w.id
        LEFT JOIN cluster_mst AS a
        ON
            i.cluster_uin = a.uin
        LEFT JOIN cluster_sub_mst AS v
        ON
            a.id = v.cluster_mst_id
        LEFT JOIN cluster_profile AS b
        ON
            b.cluster_sub_mst_id = v.id
        INNER JOIN federation_mst AS c
        ON
            i.federation_uin = c.uin
        INNER JOIN federation_sub_mst AS u
        ON
            c.id = u.federation_mst_id
        INNER JOIN federation_profile AS h
        ON
            h.federation_sub_mst_id = u.id
        INNER JOIN agency AS d
        ON
            Y.agency_id = d.agency_id
        LEFT JOIN countries AS e
        ON
            z.fp_country_id = e.id
        LEFT JOIN states AS f
        ON
            z.fp_state_id = f.id
        LEFT JOIN district AS g
        ON
            z.fp_district_id = g.id

         INNER JOIN (SELECT a.*
                FROM task_assignment AS a
                JOIN (
                    SELECT assignment_id, MAX(updated_at) AS max_updated_at
                    FROM task_assignment
                    WHERE assignment_type = 'FM' AND `status` = 'D'
                    GROUP BY assignment_id
                ) AS b ON a.assignment_id = b.assignment_id AND a.updated_at = b.max_updated_at
                ORDER BY a.updated_at DESC) as ta ON Y.id = ta.assignment_id
                LEFT JOIN users as ur
                ON ur.id = ta.user_id
         where Y.is_deleted = 0  AND z.longitude != '' AND z.latitude != '' ";

            if (!empty($session_data['state'])) {
                if ($session_data['state'] != '' && $session_data['state'] > 0) {
                    $query .= " AND z.fp_state_id = '" . $session_data['state'] . "' ";
                }
            }
            if (!empty($session_data['district'])) {
                if ($session_data['district'] != '' && $session_data['district'] > 0) {
                    $query .= " AND z.fp_district_id = '" . $session_data['district'] . "' ";
                }
            }
            if (!empty($session_data['country'])) {
                if ($session_data['country'] != '' && $session_data['country'] > 0) {
                    $query .= " AND z.fp_country_id = '" . $session_data['country'] . "' ";
                }
            }
            if(empty($session_data['Fac_id'])){
                if (!empty($session_data['agency_id'])) {
                    $text_search = $session_data['agency_id'];
                    $query .= " AND Y.agency_id ='" . $session_data['agency_id'] . "' ";
                }
            }
            if (!empty($session_data['Fac_id'])) {
                $text_search = $session_data['Fac_id'];
                $query .= " AND ta.user_id ='" . $session_data['Fac_id'] . "' ";
            }




            $result = DB::select(DB::raw($query));
            return json_encode($result);
            // exit;
        }
        $query = "SELECT * from agency WHERE is_deleted = 0";
        $data['agency'] = DB::select($query);

        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();

        return view('family.map')->with($data);
    }

    public function mapDatatableFamily(Request $request)
    {

        $user = Auth::User();

        if($user->u_type == 'M' || $user->u_type == 'QA'){
            return redirect('qualitycheck')->with('error', 'You do not have access to this page.');
        }
        $data = [];

        if ($request->ajax()) {
            $session_data = Session::get('family_session');


            $start = (int) $request->post('start');
            $limit = (int) $request->post('length');
            $txt_search = $request->post('search')['value'];




            $query = " SELECT
                    z.*,
                    d.agency_name,
                    e.name AS country_name,
                    f.name AS state_name,
                    g.name AS district_name,
                    Y.uin,
                    Y.id AS ids,
                    Y.status,
                    Y.created_at as created,
                    Y.cluster_uin,
                    h.name_of_federation,
                    b.name_of_cluster,
                    j.shgName,
                    X.status AS family_status,
                    X.analytics,
                    X.rating,
                    X.locked,
                    X.flag,
                    X.dm_p1,
                    X.dm_p2,
                    X.qa_p1,
                    X.qa_p2,
                    X.qa_r,
                    X.dm_r,
                    X.locked,
                    X.updated_at,
                    X.status_flag
                FROM
                    family_mst AS Y
                INNER JOIN family_sub_mst AS X
                ON
                    Y.id = X.family_mst_id
                INNER JOIN family_profile AS z
                ON
                    X.id = z.family_sub_mst_id
                INNER JOIN shg_mst AS i
                ON
                    i.uin = Y.shg_uin
                INNER JOIN shg_sub_mst AS w
                ON
                    i.id = w.shg_mst_id
                INNER JOIN shg_profile AS j
                ON
                    j.shg_sub_mst_id = w.id
                LEFT JOIN cluster_mst AS a
                ON
                    i.cluster_uin = a.uin
                LEFT JOIN cluster_sub_mst AS v
                ON
                    a.id = v.cluster_mst_id
                LEFT JOIN cluster_profile AS b
                ON
                    b.cluster_sub_mst_id = v.id
                INNER JOIN federation_mst AS c
                ON
                    i.federation_uin = c.uin
                INNER JOIN federation_sub_mst AS u
                ON
                    c.id = u.federation_mst_id
                INNER JOIN federation_profile AS h
                ON
                    h.federation_sub_mst_id = u.id
                INNER JOIN agency AS d
                ON
                    Y.agency_id = d.agency_id
                LEFT JOIN countries AS e
                ON
                    z.fp_country_id = e.id
                LEFT JOIN states AS f
                ON
                    z.fp_state_id = f.id
                LEFT JOIN district AS g

                ON
                    z.fp_district_id = g.id";
                    if (!empty($session_data['Fac_id'])) {
            if ($session_data['Fac_id'] != '' && $session_data['Fac_id'] > 0) {
                $query .= " INNER JOIN (SELECT a.*
                FROM task_assignment AS a
                JOIN (
                    SELECT assignment_id, MAX(updated_at) AS max_updated_at
                    FROM task_assignment
                    WHERE assignment_type = 'FM' AND `status` = 'D'
                    GROUP BY assignment_id
                ) AS b ON a.assignment_id = b.assignment_id AND a.updated_at = b.max_updated_at
                ORDER BY a.updated_at DESC) as ta ON Y.id = ta.assignment_id ";
            }
        }
        $query .= " where Y.is_deleted = 0  AND z.longitude != '' AND z.latitude != '' ";


            if (!empty($session_data['state'])) {
                if ($session_data['state'] != '' && $session_data['state'] > 0) {
                    $query .= " AND z.fp_state_id = '" . $session_data['state'] . "' ";
                }
            }
            if (!empty($session_data['district'])) {
                if ($session_data['district'] != '' && $session_data['district'] > 0) {
                    $query .= " AND z.fp_district_id = '" . $session_data['district'] . "' ";
                }
            }
            if (!empty($session_data['country'])) {
                if ($session_data['country'] != '' && $session_data['country'] > 0) {
                    $query .= " AND z.fp_country_id = '" . $session_data['country'] . "' ";
                }
            }
            if(empty($session_data['Fac_id'])){
                if (!empty($session_data['agency_id'])) {
                    $text_search = $session_data['agency_id'];
                    $query .= " AND Y.agency_id ='" . $session_data['agency_id'] . "' ";
                }
            }
            if (!empty($session_data['Fac_id'])) {
                $text_search = $session_data['Fac_id'];
                $query .= " AND ta.user_id ='" . $session_data['Fac_id'] . "' ";
            }



            // prd($query);
            if ($txt_search != '') {
                $query .= " AND (z.fp_member_name like '%$txt_search%' ";
                $query .= " or j.shgName like '%$txt_search%' ";
                $query .= " or b.name_of_cluster like '%$txt_search%' ";
                $query .= " or h.name_of_federation like '%$txt_search%' ";
                $query .= " or SUBSTRING(Y.uin, LENGTH(Y.uin) - 3) LIKE '%$txt_search%' )";
            }
            $familys = DB::select($query);
            $total = count($familys);

            $query .= " ORDER BY
                    X.updated_at
                DESC,Y.id DESC
                LIMIT $limit OFFSET $start";
            $familys = DB::select($query);

            foreach ($familys as $family) {
                if ($family->dm_p1 == 'V' && $family->qa_p1 == 'V' && $family->dm_p2 == 'V' && $family->qa_p2 == 'V' && $family->locked == 1) {
                    $visit = 'Locked';
                } elseif ($family->dm_p1 == 'V' && $family->dm_p2 == 'V' && $family->qa_p1 == 'V' && $family->qa_p2 == 'V') {
                    $visit = 'Initial Rating';
                } elseif ($family->dm_p1 == 'V' && $family->dm_p2 == 'V') {
                    $visit = 'Analytics Complete';
                } else if (($family->dm_p2 == 'P' || $family->dm_p2 == 'V') && ($family->dm_p1 == 'V' || $family->dm_p1 == 'P' || $family->dm_p1 == 'R')) {
                    $visit = 'Second Visit';
                } else if ($family->dm_p2 == 'R' && $family->flag == 1) {
                    $visit = 'Second Visit Reassigned';
                } else if ($family->dm_p1 == 'P' || $family->dm_p1 == 'V') {
                    $visit = 'First Visit';
                } else if ($family->dm_p1 == 'R' && $family->flag == 1) {
                    $visit = 'First Visit Reassigned';
                } elseif ($family->dm_p1 == 'N') {
                    $visit = 'First Visit Pending';
                } else {
                    $visit = 'Created';
                }
                $row = [];
                $row[] = ++$start;
                $row[] = $family->uin;
                $row[] = $family->fp_member_name;
                $row[] = $family->shgName;
                $row[] = ($family->name_of_cluster != '' or $family->name_of_cluster == 'NULL') ? $family->name_of_cluster : '-';
                $row[] = $family->name_of_federation;
                $row[] = $visit;
                $row[] = change_date_month_name_char($family->created);
                $row[] = change_date_month_name_char($family->updated_at);
                $row[] = $family->locked == 1 ? 'Yes' : 'No';
                $data[] = $row;
            }

            $output = array(
                "draw" => $request->post('draw'),
                "recordsTotal" => $total,
                "recordsFiltered" => $total,
                "data" => $data,
            );
            echo json_encode($output);
            exit;
        }

        $query = "SELECT * from agency WHERE is_deleted = 0";
        $data['agency'] = DB::select($query);

        $data['countries'] = DB::table('countries')
            ->where('is_deleted', '=', 0)
            ->get()->toArray();

        return view('family.map')->with($data);
    }
}
